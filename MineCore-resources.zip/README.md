# MineCore — Minecraft Java Launcher
Запуск для разработки: `npm install` → `npm start`.
Сборка exe: `npm run dist` (или через GitHub Actions, файл build.yml).
Ключ CurseForge: секрет репозитория CURSEFORGE_API_KEY (или вводится в Настройках лаунчера).
