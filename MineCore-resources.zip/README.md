# MineCore — Minecraft Java Launcher
Запуск для разработки: `npm install` → `npm start`.
Сборка exe: `npm run dist` или через GitHub Actions (build.yml).
Моды: Modrinth.
