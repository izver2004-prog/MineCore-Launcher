'use strict';
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const S = { cfg: null, page: 'home', arg: null, insts: [], vers: null, installed: [], tasks: {}, running: {}, setTab: 'game', vf: 'release', vq: '', busy: {}, fresh: true, sys: null, javas: null,
  cr: { name: '', mc: '', snap: false, loader: 'fabric', lv: '', lvs: [] }, it: 'installed', src: 'modrinth', mq: '', mres: [], mof: 0, mv: {}, mods: [], con: null, modal: null, lastRes: {} };

const IC = { home: 'M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10', layers: 'M12 3l9 5-9 5-9-5 9-5zM3 13l9 5 9-5M3 17l9 5 9-5', gear: 'M12 15a3 3 0 100-6 3 3 0 000 6zM19.4 15a1.7 1.7 0 00.3 1.9l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.9-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 01-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.9.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.9 1.7 1.7 0 00-1.5-1H3a2 2 0 010-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.9l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.9.3H9a1.7 1.7 0 001-1.5V3a2 2 0 014 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.9-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.9V9a1.7 1.7 0 001.5 1H21a2 2 0 010 4h-.1a1.7 1.7 0 00-1.5 1z', play: 'M6 4l14 8-14 8z', plus: 'M12 5v14M5 12h14', folder: 'M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2z', trash: 'M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14', edit: 'M12 20h9M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z', term: 'M4 17l6-6-6-6M12 19h8', check: 'M20 6L9 17l-5-5', x: 'M18 6L6 18M6 6l12 12', search: 'M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.3-4.3', copy: 'M9 9h11v11H9zM5 15H4V4h11v1', dots: 'M12 5h.01M12 12h.01M12 19h.01', stop: 'M6 6h12v12H6z', box: 'M21 8l-9-5-9 5v8l9 5 9-5zM3 8l9 5 9-5M12 13v8', logout: 'M9 21H5V3h4M16 17l5-5-5-5M21 12H9', down: 'M12 3v12m0 0l-5-5m5 5l5-5M5 21h14', min: 'M5 12h14', max: 'M5 5h14v14H5z', back: 'M15 18l-6-6 6-6' };
const ic = (n, c = '') => `<svg class="ic ${c}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${IC[n]}"/></svg>`;
const t = s => S.cfg && S.cfg.lang === 'en' ? (EN[s] || s) : s;
const call = async (c, ...a) => { try { return await mc.call(c, ...a); } catch (e) { toast(String(e.message).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'err'); throw e; } };
const toast = (m, k) => { const d = document.createElement('div'); d.className = 'toast ' + (k || ''); d.textContent = m; $('#toasts').append(d); setTimeout(() => d.remove(), k === 'err' ? 9000 : 3500); };
const hue = n => [...n].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7) % 360;
const LN = { vanilla: 'Vanilla', fabric: 'Fabric', quilt: 'Quilt', forge: 'Forge', neoforge: 'NeoForge' };
const fmtN = n => n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : n >= 1e3 ? Math.round(n / 1e3) + 'K' : n;
const javaMajor = v => { const m = String(v).match(/^1\.(\d+)|^(\d+)/); return m ? (m[1] || m[2]) : '?'; };

/* ---------- navigation ---------- */
function go(p, arg) { S.page = p; S.arg = arg ?? null; S.fresh = true; if (p === 'create') initCreate(); if (p === 'inst') openInst(arg); if (p === 'versions') loadVers(); if (p === 'settings') loadSettings(); render(); }
async function refresh() { S.insts = await call('inst:list'); S.installed = await call('mc:installed'); }
async function boot() {
  S.cfg = await mc.call('cfg:get'); await refresh();
  mc.on('task', d => { if (d.done) delete S.tasks[d.id]; else S.tasks[d.id] = d; drawTasks(); });
  mc.on('log', ({ key, line }) => { if (S.con && S.con.key === key) { S.con.lines.push(line); const p = $('#log'); if (p) { const b = p.scrollTop + p.clientHeight >= p.scrollHeight - 30; p.append(line + '\n'); if (b) p.scrollTop = p.scrollHeight; } } });
  mc.on('game-state', ({ key, running }) => { if (running) S.running[key] = 1; else delete S.running[key]; if (S.con && S.con.key === key) S.con.running = !!running; if (['home', 'versions', 'inst'].includes(S.page)) { S.fresh = false; render(); } });
  mc.on('game-exit', async r => {
    S.lastRes[r.key] = r; await refresh();
    if (r.test || !r.ok) openConsole(r.key, r); else if (S.page === 'home') render();
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeMenu(); if (S.modal === 'con') closeModal(); } });
  render();
}

/* ---------- shell ---------- */
function render() {
  const c = S.cfg, root = document.documentElement;
  document.body.dataset.theme = c.theme; document.body.classList.toggle('noanim', !c.anim); root.style.setProperty('--acc', c.accent);
  document.documentElement.lang = c.lang;
  const a = c.account, nav = [['home', 'home', 'Главная'], ['versions', 'layers', 'Версии'], ['settings', 'gear', 'Настройки']];
  $('#app').innerHTML = `<aside id="side"><div class="brand"><img src="../assets/icon.png" alt=""><div><b>MineCore</b><span>Minecraft Java Launcher</span></div></div>
  <nav class="nav">${nav.map(([p, i, l]) => `<button class="${(S.page === p || (p === 'home' && ['create', 'inst'].includes(S.page))) ? 'on' : ''}" data-act="go" data-p="${p}">${ic(i)}${t(l)}</button>`).join('')}</nav><div class="sp"></div>
  ${a ? `<div class="me"><div class="av">${esc(a.name[0].toUpperCase())}</div><div><b>${esc(a.name)}</b><small>${a.type === 'ms' ? 'Microsoft' : t('Офлайн')}</small></div><button class="icon" data-act="logout" title="${t('Сменить аккаунт')}">${ic('logout')}</button></div>` : ''}</aside>
  <div id="main"><div id="bar"><button data-act="wmin">${ic('min')}</button><button data-act="wmax">${ic('max')}</button><button class="x" data-act="wclose">${ic('x')}</button></div>
  <div id="view" class="${S.fresh ? 'page' : ''}">${a ? view() : ''}</div></div>`;
  S.fresh = false; drawTasks();
  if (!a && S.modal !== 'welcome') { S.modal = 'welcome'; drawModal(); }
}
function view() { return ({ home, versions, settings, create, inst })[S.page](); }
function drawTasks() {
  $('#tasks').innerHTML = Object.values(S.tasks).map(k => `<div class="task"><div class="rowh"><b>${esc(k.label)}</b><span class="muted">${k.pct}%</span></div><small class="muted">${esc(k.sub || '')}</small><div class="bar"><i style="width:${k.pct}%"></i></div></div>`).join('');
}

/* ---------- home ---------- */
function status(i) {
  if (!i.tested) return `<span class="chip cl" data-act="test" data-id="${esc(i.name)}">${t('Не проверена')} · ${t('проверить')}</span>`;
  return i.tested.ok ? `<span class="chip ok cl" data-act="test" data-id="${esc(i.name)}">${ic('check')} ${t('Проверена')} · ${Math.round(i.tested.ms / 1000)} ${t('с')}</span>` : `<span class="chip bad cl" data-act="test" data-id="${esc(i.name)}">${t('Ошибка проверки')}</span>`;
}
function playBtn(kind, id, big) {
  const key = kind + ':' + id;
  if (S.running[key]) return `<button class="btn danger ${big ? 'big' : ''}" data-act="stop" data-key="${esc(key)}">${ic('stop')} ${t('Остановить')}</button>`;
  if (kind === 'ver' && !S.installed.includes(id)) return `<button class="btn ${S.busy[key] ? 'busy' : ''}" data-act="verInstall" data-id="${esc(id)}">${ic('down')} ${t('Установить')}</button>`;
  return `<button class="btn ${big ? 'big' : ''} ${S.busy[key] ? 'busy' : ''}" data-act="play" data-kind="${kind}" data-id="${esc(id)}">${ic('play')} ${S.busy[key] ? t('Подготовка…') : t('Играть')}</button>`;
}
function instCard(i, n) {
  return `<div class="card" data-inst="${esc(i.name)}" style="animation-delay:${n * 40}ms"><div class="thumb" style="--h:${hue(i.name)}"></div><div class="body"><b>${esc(i.name)}</b>
  <span class="muted">${esc(i.mc)} · ${LN[i.loader]}${i.loader !== 'vanilla' ? ' · ' + i.modCount + ' ' + t('модов') : ''}</span><div>${status(i)}</div>
  <div class="row">${playBtn('inst', i.name)}<button class="icon" data-act="menu" data-id="${esc(i.name)}">${ic('dots')}</button></div></div></div>`;
}
function home() {
  const a = S.cfg.account, last = S.insts.find(i => i.name === S.cfg.last) || S.insts[0];
  return `<section class="hero"><div class="hero-in"><h1>${t('Привет')}, ${esc(a.name)}!</h1><p>${t('Готов к новым приключениям?')}</p>
  <div class="row">${last ? playBtn('inst', last.name, true) + `<span class="muted">${esc(last.name)}</span>` : `<button class="btn big" data-act="go" data-p="create">${ic('plus')} ${t('Создать сборку')}</button>`}</div></div></section>
  <div class="cards2"><div class="q" data-act="go" data-p="create"><div class="ib">${ic('plus')}</div><div><b>${t('Создать сборку')}</b><br><span class="muted">${t('Версия, загрузчик и моды из Modrinth и CurseForge')}</span></div></div>
  <div class="q" data-act="go" data-p="versions"><div class="ib">${ic('layers')}</div><div><b>${t('Выбор версии')}</b><br><span class="muted">${t('Играть в обычный Minecraft без модов')}</span></div></div></div>
  <h2>${ic('box')} ${t('Мои сборки')}</h2>
  <div class="grid">${S.insts.map(instCard).join('')}<button class="card new" data-act="go" data-p="create">${ic('plus')}<span>${t('Новая сборка')}</span></button></div>
  ${S.installed.length ? `<h2>${ic('layers')} ${t('Установленные версии')}</h2><div class="grid">${S.installed.slice(0, 8).map(v => `<div class="item"><div class="t"><b>${esc(v)}</b><small>Vanilla</small></div>${playBtn('ver', v)}</div>`).join('')}</div>` : ''}`;
}

/* ---------- versions ---------- */
async function loadVers() { if (!S.vers) { try { S.vers = await call('mc:versions'); } catch { S.vers = { versions: [] }; } } S.fresh = false; render(); }
function versions() {
  if (!S.vers) return `<h1>${t('Версии')}</h1><p class="muted">${t('Загрузка…')}</p>`;
  const f = S.vf, q = S.vq.toLowerCase();
  let list = S.vers.versions.filter(v => (f === 'release' ? v.type === 'release' : f === 'snapshot' ? v.type !== 'release' : S.installed.includes(v.id)) && v.id.toLowerCase().includes(q));
  const more = list.length > 60; list = list.slice(0, 60);
  return `<h1>${t('Версии')}</h1><p class="muted">${t('Скачайте версию и играйте — без модов')}</p>
  <div class="row" style="margin:16px 0"><div class="tabs" style="margin:0">${[['release', 'Релизы'], ['snapshot', 'Снапшоты'], ['inst', 'Установленные']].map(([k, l]) => `<button class="${f === k ? 'on' : ''}" data-act="vf" data-v="${k}">${t(l)}</button>`).join('')}</div>
  <input type="search" placeholder="${t('Поиск версии…')}" value="${esc(S.vq)}" data-bind="vq" style="width:220px"></div>
  <div class="list" id="vlist">${list.map(v => `<div class="item" data-ver="${esc(v.id)}"><div class="t"><b>${esc(v.id)}</b><small>${v.type} · ${(v.date || '').slice(0, 10)}</small></div>${S.installed.includes(v.id) ? `<span class="chip ok">${t('Установлена')}</span>` : ''}${playBtn('ver', v.id)}<button class="icon" data-act="menuVer" data-id="${esc(v.id)}">${ic('dots')}</button></div>`).join('') || `<p class="muted">${t('Ничего не найдено')}</p>`}${more ? `<p class="muted">${t('Показаны первые 60 — уточните поиск')}</p>` : ''}</div>`;
}

/* ---------- create ---------- */
async function initCreate() {
  if (!S.vers) { try { S.vers = await call('mc:versions'); } catch { return; } }
  const c = S.cr; c.name = ''; if (!c.mc) c.mc = S.vers.latest.release;
  await loadLV(); S.fresh = false; render();
}
async function loadLV() {
  const c = S.cr; c.lvs = []; c.lv = '';
  if (c.loader !== 'vanilla') { try { c.lvs = await mc.call('loader:versions', { mc: c.mc, loader: c.loader }); } catch (e) { c.lvs = []; } c.lv = c.lvs[0] || ''; }
}
function create() {
  const c = S.cr; if (!S.vers) return `<p class="muted">${t('Загрузка…')}</p>`;
  const vs = S.vers.versions.filter(v => c.snap || v.type === 'release');
  const busy = S.busy.create;
  return `<button class="back" data-act="go" data-p="home">${ic('back')} ${t('Назад')}</button><h1>${t('Создать сборку')}</h1><p class="muted">${t('Всё скачается автоматически')}</p>
  <div class="panel" style="margin-top:18px;max-width:640px">
  <div class="field"><label>${t('Название')}</label><input type="text" id="crname" maxlength="40" placeholder="${t('Моя сборка')}" value="${esc(c.name)}" data-bind="cr.name"></div>
  <div class="field"><label>${t('Версия Minecraft')}</label><div class="fr"><select data-bind="cr.mc">${vs.map(v => `<option ${v.id === c.mc ? 'selected' : ''}>${v.id}</option>`).join('')}</select>
  <label class="row" style="flex:none;color:var(--muted)"><span class="sw"><input type="checkbox" data-bind="cr.snap" ${c.snap ? 'checked' : ''}><i></i></span>${t('Снапшоты')}</label></div></div>
  <div class="field"><label>${t('Загрузчик')}</label><div class="loaders">${Object.entries(LN).map(([k, l]) => `<button class="${c.loader === k ? 'on' : ''}" data-act="loader" data-v="${k}">${l}</button>`).join('')}</div></div>
  ${c.loader !== 'vanilla' ? `<div class="field"><label>${t('Версия загрузчика')}</label>${c.lvs.length ? `<select data-bind="cr.lv">${c.lvs.slice(0, 60).map(v => `<option value="${esc(v)}" ${v === c.lv ? 'selected' : ''}>${esc(v.replace(c.mc + '-', ''))}</option>`).join('')}</select>` : `<p class="muted">${t('Для этой версии игры загрузчик недоступен — выберите другую версию или загрузчик')}</p>`}</div>` : ''}
  <button class="btn big ${busy ? 'busy' : ''}" data-act="doCreate" ${busy ? 'disabled' : ''}>${ic('check')} ${busy ? t('Создаём…') : t('Создать и скачать')}</button></div>`;
}

/* ---------- instance editor ---------- */
async function openInst(name) { S.it = 'installed'; S.mres = []; S.mq = ''; S.mv = {}; S.mof = 0; await loadMods(); S.fresh = false; render(); }
async function loadMods() { try { S.mods = await mc.call('mod:list', S.arg); } catch { S.mods = []; } }
function curInst() { return S.insts.find(i => i.name === S.arg); }
function inst() {
  const i = curInst(); if (!i) return `<button class="back" data-act="go" data-p="home">${ic('back')} ${t('Назад')}</button>`;
  const van = i.loader === 'vanilla';
  return `<button class="back" data-act="go" data-p="home">${ic('back')} ${t('Назад')}</button>
  <div class="rowh"><div><h1>${esc(i.name)}</h1><span class="muted">${esc(i.mc)} · ${LN[i.loader]} ${esc((i.loaderVer || '').replace(i.mc + '-', ''))}</span> ${status(i)}</div>
  <div class="row">${playBtn('inst', i.name, true)}<button class="btn ghost" data-act="test" data-id="${esc(i.name)}">${ic('check')} ${t('Проверить')}</button><button class="icon" data-act="console" data-key="inst:${esc(i.name)}" title="${t('Консоль')}">${ic('term')}</button><button class="icon" data-act="menu" data-id="${esc(i.name)}">${ic('dots')}</button></div></div>
  ${van ? `<div class="panel" style="margin-top:18px">${t('Это чистая сборка без загрузчика — моды недоступны. Создайте сборку с Fabric, Forge, Quilt или NeoForge, чтобы ставить моды.')}</div>` : `
  <div class="tabs"><button class="${S.it === 'installed' ? 'on' : ''}" data-act="itab" data-v="installed">${t('Установленные')} (${S.mods.length})</button><button class="${S.it === 'find' ? 'on' : ''}" data-act="itab" data-v="find">${t('Найти моды')}</button></div>
  ${S.it === 'installed' ? installedMods() : findMods()}`}`;
}
function installedMods() {
  if (!S.mods.length) return `<div class="panel muted">${t('Модов пока нет. Откройте вкладку «Найти моды».')}</div>`;
  return `<div class="list">${S.mods.map(m => `<div class="item">${m.icon ? `<img class="mi" src="${esc(m.icon)}">` : `<div class="mi">${esc(m.name[0] || '?').toUpperCase()}</div>`}<div class="t"><b>${esc(m.name)}</b><small>${esc(m.ver || m.file)}</small></div>
  <label class="sw"><input type="checkbox" ${m.enabled ? 'checked' : ''} data-act="modToggle" data-file="${esc(m.file)}"><i></i></label><button class="icon" data-act="modDel" data-file="${esc(m.file)}">${ic('trash')}</button></div>`).join('')}</div>
  <div class="row" style="margin-top:12px"><button class="btn ghost sm" data-act="folder" data-id="${esc(S.arg)}" data-sub="mods">${ic('folder')} ${t('Папка модов')}</button></div>`;
}
function findMods() {
  return `<div class="row" style="margin-bottom:14px"><div class="seg"><button class="${S.src === 'modrinth' ? 'on' : ''}" data-act="src" data-v="modrinth">Modrinth</button><button class="${S.src === 'curseforge' ? 'on' : ''}" data-act="src" data-v="curseforge">CurseForge</button></div>
  <input type="search" placeholder="${t('Поиск модов…')}" value="${esc(S.mq)}" data-bind="mq" style="flex:1;min-width:200px"></div><div class="list" id="mres">${resHtml()}</div>`;
}
function resHtml() {
  if (S.busy.search) return `<p class="muted">${t('Поиск…')}</p>`;
  const done = new Set(S.mods.filter(m => m.src === S.src).map(m => m.pid));
  return S.mres.map(m => `<div class="item" style="flex-wrap:wrap">${m.icon ? `<img class="mi" src="${esc(m.icon)}">` : `<div class="mi">${esc(m.title[0])}</div>`}<div class="t"><b>${esc(m.title)}</b><small>${esc(m.author || '')} · ${fmtN(m.dl || 0)} ${t('загрузок')} — ${esc(m.desc)}</small></div>
  ${done.has(m.id) ? `<span class="chip ok">${ic('check')} ${t('Установлен')}</span>` : `<button class="btn sm ${S.busy['m' + m.id] ? 'busy' : ''}" data-act="modInstall" data-id="${esc(m.id)}">${t('Установить')}</button><button class="btn ghost sm" data-act="modVers" data-id="${esc(m.id)}">${t('Версии')} ▾</button>`}
  ${S.mv[m.id] ? `<div style="width:100%;padding-left:54px" class="list">${S.mv[m.id].length ? S.mv[m.id].slice(0, 12).map(v => `<div class="row"><span style="flex:1">${esc(v.name)} <span class="chip ${v.type === 'release' ? 'ok' : 'warn'}">${v.type}</span> <small class="muted">${(v.date || '').slice(0, 10)}</small></span><button class="btn sm ghost" data-act="modInstall" data-id="${esc(m.id)}" data-vid="${esc(v.id)}">${t('Установить')}</button></div>`).join('') : `<span class="muted">${t('Нет версий для этой сборки')}</span>`}</div>` : ''}</div>`).join('') + (S.mres.length >= 20 ? `<button class="btn ghost" data-act="moreMods">${t('Показать ещё')}</button>` : '') || `<p class="muted">${t('Ничего не найдено')}</p>`;
}
let sTimer;
async function searchMods(append) {
  const i = curInst(); if (!i) return;
  S.busy.search = !append; if (!append) { S.mof = 0; $('#mres') && ($('#mres').innerHTML = resHtml()); }
  try { const r = await mc.call('mod:search', { src: S.src, q: S.mq, mc: i.mc, loader: i.loader, off: S.mof }); S.mres = append ? S.mres.concat(r) : r; }
  catch (e) { toast(String(e.message).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'err'); S.mres = append ? S.mres : []; }
  S.busy.search = false; $('#mres') && ($('#mres').innerHTML = resHtml());
}

/* ---------- settings ---------- */
async function loadSettings() { S.sys = await mc.call('sys:info'); S.fresh = false; render(); if (S.setTab === 'java') loadJava(); }
async function loadJava() { try { S.javas = (await mc.call('java:list')).sort((a, b) => javaMajor(b.ver) - javaMajor(a.ver)); } catch { S.javas = []; } if (S.page === 'settings' && S.setTab === 'java') { S.fresh = false; render(); } }
function tog(k, title, sub) { return `<div class="set"><div>${t(title)}${sub ? `<small>${t(sub)}</small>` : ''}</div><label class="sw"><input type="checkbox" data-cfg="${k}" ${S.cfg[k] ? 'checked' : ''}><i></i></label></div>`; }
function settings() {
  const c = S.cfg, tab = S.setTab, sys = S.sys || { totalMem: 8192, root: c.root };
  const max = Math.max(2048, Math.floor(sys.totalMem / 512) * 512), rec = sys.totalMem >= 16000 ? '6–8' : sys.totalMem >= 8000 ? '4–6' : '2–3';
  let body = '';
  if (tab === 'game') body = `<div class="panel"><h3>${t('Оперативная память (ОЗУ)')}</h3><input type="range" min="1024" max="${max}" step="512" value="${Math.min(c.ram, max)}" data-cfg="ram" data-live="ramv"><div class="rowh"><b id="ramv">${(c.ram / 1024).toFixed(1)} ${t('ГБ')}</b><span class="muted">${t('Рекомендуется')}: ${rec} ${t('ГБ')} · ${t('всего в ПК')}: ${(sys.totalMem / 1024).toFixed(0)} ${t('ГБ')}</span></div></div>
  <div class="panel"><h3>${t('Оптимизация')}</h3>${tog('g1', 'Оптимизированные параметры Java', 'Флаги G1GC — меньше фризов и рывков')}${tog('hideOnPlay', 'Сворачивать лаунчер при запуске', 'Окно вернётся, когда игра закроется')}${tog('fullscreen', 'Полноэкранный режим')}</div>
  <div class="panel"><h3>${t('Дополнительные аргументы JVM')}</h3><input type="text" style="width:100%" value="${esc(c.jvm)}" data-cfg="jvm" placeholder="-Dfile.encoding=UTF-8"></div>`;
  if (tab === 'java') {
    const javas = S.javas ? S.javas.map(j => `<div class="set"><div>Java ${javaMajor(j.ver)} <small>${esc(j.comp)} · ${esc(j.ver)}</small></div>${j.installed ? `<div class="row"><span class="chip ok">${t('Установлена')}</span><button class="icon" data-act="javaDel" data-v="${esc(j.comp)}">${ic('trash')}</button></div>` : `<button class="btn sm" data-act="javaGet" data-v="${esc(j.comp)}">${ic('down')} ${t('Скачать')}</button>`}</div>`).join('') : `<p class="muted">${t('Загрузка…')}</p>`;
    const dirs = [['', 'Корневая папка', 'Всё хранится здесь'], ['instances', 'Сборки', 'У каждой сборки своя папка: моды, миры, скриншоты'], ['versions', 'Версии игры', 'Скачанные версии Minecraft'], ['vanilla', 'Обычные версии', 'Миры и настройки игры без сборок'], ['runtime', 'Java', 'Скачанные версии Java'], ['logs', 'Журналы', 'Логи запусков']];
    body = `<div class="panel"><h3>Java</h3><p class="muted" style="margin-bottom:8px">${t('Нужная Java скачивается автоматически при запуске. Здесь можно скачать её заранее.')}</p>${javas}
    <div class="set"><div>${t('Своя Java')}<small>${esc(c.javaPath || t('Не выбрана — используется автоматическая'))}</small></div><div class="row"><button class="btn ghost sm" data-act="javaPick">${t('Выбрать')}</button>${c.javaPath ? `<button class="icon" data-act="javaClear">${ic('x')}</button>` : ''}</div></div></div>
    <div class="panel"><h3>${t('Лаунчер и папки')}</h3><div class="set"><div>${t('Корневая папка')}<small>${esc(c.root)}</small></div><button class="btn ghost sm" data-act="rootPick">${t('Изменить')}</button></div>
    <p class="muted" style="margin:6px 0">${t('При смене папки старые данные не переносятся автоматически.')}</p>
    ${dirs.map(([k, n, d]) => `<div class="set"><div>${t(n)}<small>${t(d)}</small></div><button class="icon" data-act="openRoot" data-v="${k}">${ic('folder')}</button></div>`).join('')}
    <div class="set"><div>${t('Ключ CurseForge API')}<small>${t('Бесплатно на console.curseforge.com. Для Modrinth не нужен.')}</small></div><input type="text" data-cfg="cfKey" placeholder="${c.hasCfKey ? '••••••••' : t('Вставьте ключ')}" style="width:220px"></div></div>`;
  }
  if (tab === 'look') body = `<div class="panel"><h3>${t('Язык')}</h3><div class="seg"><button class="${c.lang === 'ru' ? 'on' : ''}" data-act="lang" data-v="ru">Русский</button><button class="${c.lang === 'en' ? 'on' : ''}" data-act="lang" data-v="en">English</button></div></div>
  <div class="panel"><h3>${t('Тема')}</h3><div class="themes">${[['default', 'По умолчанию', '#0b1113,#2ecc9a'], ['dark', 'Тёмная', '#0d0d0f,#8d8d99'], ['light', 'Светлая', '#eef3f3,#5d7273'], ['cyber', 'Cyberpunk', '#0e0a1a,#b46cff']].map(([k, n, cl]) => `<div class="th ${c.theme === k ? 'on' : ''}" data-act="theme" data-v="${k}"><i style="background:linear-gradient(135deg,${cl.split(',')[0]} 60%,${cl.split(',')[1]})"></i>${t(n)}</div>`).join('')}</div></div>
  <div class="panel"><h3>${t('Цвет акцента')}</h3><div class="sw-c">${['#2ecc9a', '#27b5f0', '#5b7cfa', '#a56cff', '#ee5fa7', '#f5a345', '#ef6a4c'].map(x => `<b style="background:${x}" class="${c.accent === x ? 'on' : ''}" data-act="accent" data-v="${x}"></b>`).join('')}</div></div>
  <div class="panel">${tog('anim', 'Анимации интерфейса')}</div>`;
  if (tab === 'acc') body = `<div class="panel"><h3>${t('Аккаунт')}</h3><div class="set"><div><b>${esc(c.account.name)}</b><small>${c.account.type === 'ms' ? 'Microsoft' : t('Офлайн')}</small></div><button class="btn ghost sm" data-act="logout">${ic('logout')} ${t('Сменить аккаунт')}</button></div></div>`;
  return `<h1>${t('Настройки')}</h1><div class="tabs">${[['game', 'Игра'], ['java', 'Java и лаунчер'], ['look', 'Внешний вид'], ['acc', 'Аккаунт']].map(([k, l]) => `<button class="${tab === k ? 'on' : ''}" data-act="stab" data-v="${k}">${t(l)}</button>`).join('')}</div><div style="max-width:720px">${body}</div>`;
}

/* ---------- modals ---------- */
function closeModal() { S.modal = null; if (S.con) { mc.call('console:detach'); S.con = null; } $('#modal').innerHTML = ''; }
function drawModal() {
  const m = $('#modal');
  if (S.modal === 'welcome') {
    const ms = S.wtab === 'ms';
    m.innerHTML = `<div class="modal"><div class="dlg wide"><div class="row" style="margin-bottom:12px"><img src="../assets/icon.png" width="46" height="46" style="border-radius:12px"><div><h2>${t('Добро пожаловать в MineCore')}</h2><span class="muted">${t('Создайте аккаунт — это нужно только один раз')}</span></div></div>
    <div class="seg" style="margin:10px 0 16px"><button class="${!ms ? 'on' : ''}" data-act="wtab" data-v="off">${t('Офлайн')}</button><button class="${ms ? 'on' : ''}" data-act="wtab" data-v="ms">Microsoft</button></div>
    ${ms ? `<p class="muted" style="margin-bottom:16px">${t('Войдите в аккаунт Microsoft с купленным Minecraft Java Edition.')}</p><button class="btn big" data-act="msLogin" style="width:100%">${t('Войти через Microsoft')}</button>`
      : `<div class="field"><label>${t('Ник в игре')}</label><input type="text" id="nick" maxlength="16" placeholder="Player123" style="user-select:text"><small class="muted">${t('3–16 символов: латиница, цифры, _')}</small></div><button class="btn big" data-act="offLogin" style="width:100%">${t('Продолжить')}</button>`}</div></div>`;
  } else if (S.modal === 'con') {
    const c = S.con;
    m.innerHTML = `<div class="modal"><div class="dlg con"><div class="ch"><b>${t('Консоль')} · ${esc(c.title)}</b><span class="chip ${c.running ? 'ok' : ''}" style="margin:0">${c.running ? t('Работает') : t('Остановлена')}</span><span class="sp"></span><button class="icon" data-act="conCopy" title="${t('Копировать')}">${ic('copy')}</button>${c.running ? `<button class="btn sm danger" data-act="stop" data-key="${esc(c.key)}">${t('Остановить')}</button>` : ''}<button class="icon" data-act="closeModal">${ic('x')}</button></div>${ana(c.res)}<pre id="log">${esc(c.lines.join('\n'))}</pre></div></div>`;
    const p = $('#log'); if (p) p.scrollTop = p.scrollHeight;
  } else if (S.modal === 'ask') {
    const a = S.ask;
    m.innerHTML = `<div class="modal"><div class="dlg"><h2>${esc(a.title)}</h2>${a.input !== undefined ? `<input type="text" id="askin" value="${esc(a.input)}" maxlength="40" style="width:100%;margin:12px 0;user-select:text">` : `<p class="muted" style="margin:10px 0 14px">${esc(a.text || '')}</p>`}<div class="row" style="justify-content:flex-end"><button class="btn ghost" data-act="askNo">${t('Отмена')}</button><button class="btn ${a.danger ? 'danger' : ''}" data-act="askYes">${t('Ок')}</button></div></div></div>`;
    const i = $('#askin'); if (i) { i.focus(); i.select(); i.onkeydown = e => { if (e.key === 'Enter') acts.askYes(); }; }
  } else m.innerHTML = '';
}
function ask(title, o = {}) { return new Promise(res => { S.ask = { title, ...o, res }; S.modal = 'ask'; drawModal(); }); }
function ana(r) {
  if (!r) return '';
  let h = '';
  if (r.test && r.ok) h += `<div class="box ok"><b>✓ ${t('Сборка работает!')}</b><br><span class="muted">${t('Игра дошла до главного меню за')} ${Math.round(r.ms / 1000)} ${t('с')}.</span></div>`;
  else if (r.ok) return '';
  for (const w of r.warns || []) h += `<div class="box warn">⚠ ${esc(w)}</div>`;
  const a = r.analysis;
  if (a) {
    h += `<div class="box err"><b>${t('Что пошло не так')}</b></div>`;
    for (const it of a.items) h += `<div class="box err"><b>${esc(it.title)}</b><p>${esc(it.text)}</p>${it.fixes.length ? `<div class="muted" style="margin-top:6px">${t('Как починить')}:</div><ul>${it.fixes.map(f => `<li>${esc(f)}</li>`).join('')}</ul>` : ''}${it.details ? `<pre class="d">${esc(it.details)}</pre>` : ''}${it.hint ? `<div class="row" style="margin-top:8px"><button class="btn sm" data-act="goSet">${t('Открыть настройки')}</button></div>` : ''}</div>`;
    if (a.suspects.length) h += `<div class="box warn"><b>${t('Подозрительные моды')}</b>${a.suspects.map(f => `<div class="row" style="margin-top:6px"><span style="flex:1">${esc(f)}</span><button class="btn sm danger" data-act="susDel" data-file="${esc(f)}" data-key="${esc(r.key)}">${t('Удалить')}</button></div>`).join('')}</div>`;
    if (a.crash) h += `<div class="row" style="margin-bottom:8px"><button class="btn ghost sm" data-act="crash" data-f="${esc(a.crash)}">${t('Открыть отчёт о крэше')}</button></div>`;
  }
  return `<div class="ana scr">${h}</div>`;
}
async function openConsole(key, res) {
  const r = await mc.call('console:get', key); await mc.call('console:attach', key);
  const title = key.slice(key.indexOf(':') + 1);
  S.con = { key, title, lines: r.lines, running: r.running, res: res || r.result || null }; S.modal = 'con'; drawModal();
}

/* ---------- actions ---------- */
function showMenu(x, y, items) {
  closeMenu(); const m = document.createElement('div'); m.id = 'ctx';
  m.innerHTML = items.map(i => i === '-' ? '<hr>' : `<button class="${i.cls || ''}" data-act="${i.act}" ${Object.entries(i.d || {}).map(([k, v]) => `data-${k}="${esc(v)}"`).join(' ')}>${ic(i.ic)}${t(i.l)}</button>`).join('');
  document.body.append(m); const r = m.getBoundingClientRect();
  m.style.left = Math.min(x, innerWidth - r.width - 8) + 'px'; m.style.top = Math.min(y, innerHeight - r.height - 8) + 'px';
}
const closeMenu = () => { const m = $('#ctx'); if (m) m.remove(); };
function instMenu(name, x, y) {
  const key = 'inst:' + name;
  showMenu(x, y, [S.running[key] ? { l: 'Остановить', act: 'stop', ic: 'stop', d: { key } } : { l: 'Играть', act: 'play', ic: 'play', d: { kind: 'inst', id: name } }, { l: 'Проверить сборку', act: 'test', ic: 'check', d: { id: name } }, { l: 'Консоль', act: 'console', ic: 'term', d: { key } }, { l: 'Моды и настройки', act: 'openInst', ic: 'box', d: { id: name } }, '-',
    { l: 'Папка сборки', act: 'folder', ic: 'folder', d: { id: name, sub: '' } }, { l: 'Папка модов', act: 'folder', ic: 'folder', d: { id: name, sub: 'mods' } }, { l: 'Переименовать', act: 'rename', ic: 'edit', d: { id: name } }, { l: 'Дублировать', act: 'dup', ic: 'copy', d: { id: name } }, '-', { l: 'Удалить', act: 'delInst', ic: 'trash', cls: 'danger', d: { id: name } }]);
}
function verMenu(id, x, y) { showMenu(x, y, [{ l: 'Консоль', act: 'console', ic: 'term', d: { key: 'ver:' + id } }, { l: 'Открыть папку', act: 'folderVer', ic: 'folder', d: { id } }, ...(S.installed.includes(id) ? ['-', { l: 'Удалить версию', act: 'delVer', ic: 'trash', cls: 'danger', d: { id } }] : [])]); }
async function run(key, fn) { S.busy[key] = 1; rerender(); try { await fn(); } finally { delete S.busy[key]; await refresh(); rerender(); } }
function rerender() { S.fresh = false; const sc = $('#view') ? $('#view').scrollTop : 0; render(); if ($('#view')) $('#view').scrollTop = sc; }
const setCfg = async p => { S.cfg = await mc.call('cfg:set', p); };

const acts = {
  go: d => go(d.p), wmin: () => mc.call('win:min'), wmax: () => mc.call('win:max'), wclose: () => mc.call('win:close'),
  logout: async () => { S.cfg = await mc.call('acct:logout'); S.modal = null; S.wtab = 'off'; render(); },
  wtab: d => { S.wtab = d.v; drawModal(); },
  offLogin: async () => { try { S.cfg = await call('acct:offline', $('#nick').value); S.modal = null; closeModal(); S.fresh = true; render(); } catch {} },
  msLogin: async () => { try { toast(t('Откроется окно входа Microsoft…')); S.cfg = await call('acct:ms'); closeModal(); S.fresh = true; render(); } catch {} },
  play: d => { const key = d.kind + ':' + d.id; run(key, () => call('game:play', { kind: d.kind, id: d.id }).catch(() => {})); },
  test: d => { const key = 'inst:' + d.id; run(key, async () => { toast(t('Запускаем проверку — игра откроется и закроется сама')); await call('game:play', { kind: 'inst', id: d.id, test: true }).catch(() => {}); }); },
  stop: d => mc.call('game:stop', d.key),
  verInstall: d => run('ver:' + d.id, () => call('ver:install', d.id).then(() => toast(t('Версия установлена'))).catch(() => {})),
  menu: (d, e) => { const r = e.target.closest('[data-act]').getBoundingClientRect(); instMenu(d.id, r.left, r.bottom + 4); },
  menuVer: (d, e) => { const r = e.target.closest('[data-act]').getBoundingClientRect(); verMenu(d.id, r.left - 150, r.bottom + 4); },
  console: d => openConsole(d.key, S.lastRes[d.key]),
  openInst: d => go('inst', d.id),
  folder: d => mc.call('folder:open', { kind: 'inst', id: d.id, sub: d.sub }),
  folderVer: d => mc.call('folder:open', { kind: 'ver', id: d.id }),
  openRoot: d => mc.call('folder:open', { kind: 'root', sub: d.v }),
  rename: async d => { const to = await ask(t('Новое название'), { input: d.id }); if (to && to !== d.id) { try { const n = await call('inst:rename', { name: d.id, to }); if (S.page === 'inst') S.arg = n; await refresh(); S.cfg = await mc.call('cfg:get'); rerender(); } catch {} } },
  dup: async d => { try { await call('inst:dup', { name: d.id }); await refresh(); rerender(); toast(t('Сборка скопирована')); } catch {} },
  delInst: async d => { if (await ask(t('Удалить сборку?'), { text: d.id + ' — ' + t('все её моды и миры будут удалены.'), danger: true })) { try { await call('inst:delete', d.id); if (S.page === 'inst') S.page = 'home'; await refresh(); rerender(); } catch {} } },
  delVer: async d => { if (await ask(t('Удалить версию?'), { text: d.id, danger: true })) { await call('ver:delete', d.id); await refresh(); rerender(); } },
  vf: d => { S.vf = d.v; rerender(); },
  loader: async d => { S.cr.loader = d.v; await loadLV(); rerender(); },
  doCreate: () => { const c = S.cr; run('create', async () => { try { const n = await call('inst:create', { name: c.name || t('Моя сборка'), mc: c.mc, loader: c.loader, lv: c.lv }); await refresh(); S.cr.name = ''; go('inst', n); toast(t('Сборка создана')); } catch {} }); },
  itab: d => { S.it = d.v; rerender(); if (d.v === 'find' && !S.mres.length) searchMods(); },
  src: d => { S.src = d.v; S.mres = []; S.mv = {}; rerender(); searchMods(); },
  moreMods: () => { S.mof += 20; searchMods(true); },
  modVers: async d => { if (S.mv[d.id]) { delete S.mv[d.id]; } else { const i = curInst(); try { S.mv[d.id] = await call('mod:versions', { src: S.src, id: d.id, mc: i.mc, loader: i.loader }); } catch {} } $('#mres').innerHTML = resHtml(); },
  modInstall: async d => {
    const i = curInst(), m = S.mres.find(x => x.id === d.id); let vid = d.vid;
    S.busy['m' + d.id] = 1; $('#mres').innerHTML = resHtml();
    try {
      if (!vid) { const vs = S.mv[d.id] || await call('mod:versions', { src: S.src, id: d.id, mc: i.mc, loader: i.loader }); if (!vs.length) { toast(t('Нет версии для этой сборки'), 'err'); return; } vid = vs[0].id; }
      const done = await call('mod:install', { name: i.name, src: S.src, pid: d.id, vid, title: m && m.title, icon: m && m.icon });
      toast(t('Установлено') + ': ' + done.join(', ')); await loadMods(); await refresh();
    } catch {} finally { delete S.busy['m' + d.id]; delete S.mv[d.id]; if ($('#mres')) $('#mres').innerHTML = resHtml(); }
  },
  modToggle: async d => { try { await call('mod:toggle', { name: S.arg, file: d.file }); await loadMods(); await refresh(); rerender(); } catch {} },
  modDel: async d => { await call('mod:remove', { name: S.arg, file: d.file }); await loadMods(); await refresh(); rerender(); },
  susDel: async d => { const n = d.key.slice(5); await call('mod:remove', { name: n, file: d.file }); toast(t('Мод удалён. Запустите проверку снова.')); await refresh(); closeModal(); },
  crash: d => mc.call('path:open', d.f),
  goSet: () => { closeModal(); S.setTab = 'game'; go('settings'); },
  conCopy: () => { navigator.clipboard.writeText(S.con.lines.join('\n')).then(() => toast(t('Скопировано'))); },
  closeModal, askYes: () => { const a = S.ask, v = a.input !== undefined ? $('#askin').value.trim() : true; closeModal(); a.res(v); }, askNo: () => { const a = S.ask; closeModal(); a.res(null); },
  stab: d => { S.setTab = d.v; S.fresh = false; rerender(); if (d.v === 'java') loadJava(); },
  lang: async d => { await setCfg({ lang: d.v }); rerender(); }, theme: async d => { await setCfg({ theme: d.v }); rerender(); }, accent: async d => { await setCfg({ accent: d.v }); rerender(); },
  javaGet: d => run('j' + d.v, async () => { await call('java:install', d.v).catch(() => {}); await loadJava(); }),
  javaDel: async d => { await call('java:delete', d.v); loadJava(); },
  javaPick: async () => { S.cfg = await mc.call('sys:pickJava'); rerender(); }, javaClear: async () => { await setCfg({ javaPath: '' }); rerender(); },
  rootPick: async () => { S.cfg = await mc.call('sys:setRoot'); await refresh(); S.sys = await mc.call('sys:info'); rerender(); }
};
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  closeMenu();
  if (el && el.tagName === 'INPUT') return;
  if (el) { e.stopPropagation(); acts[el.dataset.act] && acts[el.dataset.act](el.dataset, e); }
});
document.addEventListener('contextmenu', e => {
  const c = e.target.closest('[data-inst]'), v = e.target.closest('[data-ver]');
  if (c) { e.preventDefault(); instMenu(c.dataset.inst, e.clientX, e.clientY); } else if (v) { e.preventDefault(); verMenu(v.dataset.ver, e.clientX, e.clientY); }
});
document.addEventListener('change', async e => {
  const el = e.target;
  if (el.dataset.act === 'modToggle') return acts.modToggle(el.dataset);
  if (el.dataset.cfg) { const k = el.dataset.cfg; let v = el.type === 'checkbox' ? el.checked : el.type === 'range' ? +el.value : el.value; if (k === 'cfKey' && !v) return; await setCfg({ [k]: v }); if (k === 'anim') rerender(); if (k === 'cfKey') toast(t('Ключ сохранён')); }
  if (el.dataset.bind) {
    const b = el.dataset.bind;
    if (b === 'cr.mc') { S.cr.mc = el.value; await loadLV(); rerender(); }
    else if (b === 'cr.snap') { S.cr.snap = el.checked; rerender(); }
    else if (b === 'cr.lv') S.cr.lv = el.value;
  }
});
document.addEventListener('input', e => {
  const el = e.target;
  if (el.dataset.live) { $('#' + el.dataset.live).textContent = (el.value / 1024).toFixed(1) + ' ' + t('ГБ'); }
  const b = el.dataset.bind; if (!b) return;
  if (b === 'cr.name') S.cr.name = el.value;
  if (b === 'mq') { S.mq = el.value; clearTimeout(sTimer); sTimer = setTimeout(() => searchMods(), 450); }
  if (b === 'vq') { S.vq = el.value; const p = el.selectionStart; rerender(); const n = $('[data-bind=vq]'); if (n) { n.focus(); n.setSelectionRange(p, p); } }
});
window.addEventListener('blur', closeMenu);

const EN = { 'Главная': 'Home', 'Версии': 'Versions', 'Настройки': 'Settings', 'Офлайн': 'Offline', 'Сменить аккаунт': 'Switch account', 'Не проверена': 'Not tested', 'проверить': 'test', 'Проверена': 'Tested', 'с': 's', 'Ошибка проверки': 'Test failed', 'модов': 'mods', 'Остановить': 'Stop', 'Установить': 'Install', 'Подготовка…': 'Preparing…', 'Играть': 'Play', 'Привет': 'Hello', 'Готов к новым приключениям?': 'Ready for new adventures?', 'Создать сборку': 'Create pack', 'Версия, загрузчик и моды из Modrinth и CurseForge': 'Version, loader and mods from Modrinth and CurseForge', 'Выбор версии': 'Choose version', 'Играть в обычный Minecraft без модов': 'Play vanilla Minecraft', 'Мои сборки': 'My packs', 'Новая сборка': 'New pack', 'Установленные версии': 'Installed versions', 'Загрузка…': 'Loading…', 'Скачайте версию и играйте — без модов': 'Download a version and play — no mods', 'Релизы': 'Releases', 'Снапшоты': 'Snapshots', 'Установленные': 'Installed', 'Поиск версии…': 'Search version…', 'Установлена': 'Installed', 'Ничего не найдено': 'Nothing found', 'Показаны первые 60 — уточните поиск': 'First 60 shown — refine your search', 'Всё скачается автоматически': 'Everything downloads automatically', 'Название': 'Name', 'Моя сборка': 'My pack', 'Версия Minecraft': 'Minecraft version', 'Загрузчик': 'Loader', 'Версия загрузчика': 'Loader version', 'Для этой версии игры загрузчик недоступен — выберите другую версию или загрузчик': 'No loader for this game version — pick another version or loader', 'Создаём…': 'Creating…', 'Создать и скачать': 'Create & download', 'Назад': 'Back', 'Проверить': 'Test', 'Консоль': 'Console', 'Это чистая сборка без загрузчика — моды недоступны. Создайте сборку с Fabric, Forge, Quilt или NeoForge, чтобы ставить моды.': 'Vanilla pack — no mods. Create a pack with Fabric, Forge, Quilt or NeoForge to use mods.', 'Найти моды': 'Find mods', 'Модов пока нет. Откройте вкладку «Найти моды».': 'No mods yet. Open "Find mods".', 'Папка модов': 'Mods folder', 'Поиск модов…': 'Search mods…', 'Поиск…': 'Searching…', 'загрузок': 'downloads', 'Установлен': 'Installed', 'Версии': 'Versions', 'Нет версий для этой сборки': 'No versions for this pack', 'Показать ещё': 'Show more', 'Оперативная память (ОЗУ)': 'Memory (RAM)', 'ГБ': 'GB', 'Рекомендуется': 'Recommended', 'всего в ПК': 'total in PC', 'Оптимизация': 'Optimization', 'Оптимизированные параметры Java': 'Optimized Java flags', 'Флаги G1GC — меньше фризов и рывков': 'G1GC flags — fewer stutters', 'Сворачивать лаунчер при запуске': 'Minimize launcher on play', 'Окно вернётся, когда игра закроется': 'Returns when the game closes', 'Полноэкранный режим': 'Fullscreen', 'Дополнительные аргументы JVM': 'Extra JVM arguments', 'Нужная Java скачивается автоматически при запуске. Здесь можно скачать её заранее.': 'The right Java downloads automatically on launch. You can pre-download it here.', 'Скачать': 'Download', 'Своя Java': 'Custom Java', 'Не выбрана — используется автоматическая': 'Not set — automatic', 'Выбрать': 'Choose', 'Лаунчер и папки': 'Launcher & folders', 'Корневая папка': 'Root folder', 'Изменить': 'Change', 'При смене папки старые данные не переносятся автоматически.': 'Old data is not moved automatically when changing the folder.', 'Всё хранится здесь': 'Everything is stored here', 'Сборки': 'Packs', 'У каждой сборки своя папка: моды, миры, скриншоты': 'Each pack has its own folder: mods, worlds, screenshots', 'Версии игры': 'Game versions', 'Скачанные версии Minecraft': 'Downloaded Minecraft versions', 'Обычные версии': 'Vanilla data', 'Миры и настройки игры без сборок': 'Worlds and settings of plain versions', 'Скачанные версии Java': 'Downloaded Java runtimes', 'Журналы': 'Logs', 'Логи запусков': 'Launch logs', 'Ключ CurseForge API': 'CurseForge API key', 'Бесплатно на console.curseforge.com. Для Modrinth не нужен.': 'Free at console.curseforge.com. Not needed for Modrinth.', 'Вставьте ключ': 'Paste key', 'Язык': 'Language', 'Тема': 'Theme', 'По умолчанию': 'Default', 'Тёмная': 'Dark', 'Светлая': 'Light', 'Цвет акцента': 'Accent color', 'Анимации интерфейса': 'UI animations', 'Аккаунт': 'Account', 'Игра': 'Game', 'Java и лаунчер': 'Java & launcher', 'Внешний вид': 'Appearance', 'Добро пожаловать в MineCore': 'Welcome to MineCore', 'Создайте аккаунт — это нужно только один раз': 'Create an account — only once', 'Войдите в аккаунт Microsoft с купленным Minecraft Java Edition.': 'Sign in with a Microsoft account that owns Minecraft Java Edition.', 'Войти через Microsoft': 'Sign in with Microsoft', 'Ник в игре': 'In-game nick', '3–16 символов: латиница, цифры, _': '3–16 chars: letters, digits, _', 'Продолжить': 'Continue', 'Работает': 'Running', 'Остановлена': 'Stopped', 'Копировать': 'Copy', 'Отмена': 'Cancel', 'Ок': 'OK', 'Сборка работает!': 'The pack works!', 'Игра дошла до главного меню за': 'The game reached the main menu in', 'Что пошло не так': 'What went wrong', 'Как починить': 'How to fix', 'Открыть настройки': 'Open settings', 'Подозрительные моды': 'Suspicious mods', 'Удалить': 'Delete', 'Открыть отчёт о крэше': 'Open crash report', 'Папка сборки': 'Pack folder', 'Переименовать': 'Rename', 'Дублировать': 'Duplicate', 'Моды и настройки': 'Mods & settings', 'Проверить сборку': 'Test pack', 'Открыть папку': 'Open folder', 'Удалить версию': 'Delete version', 'Новое название': 'New name', 'Удалить сборку?': 'Delete pack?', 'все её моды и миры будут удалены.': 'all its mods and worlds will be deleted.', 'Удалить версию?': 'Delete version?', 'Версия установлена': 'Version installed', 'Сборка создана': 'Pack created', 'Сборка скопирована': 'Pack copied', 'Установлено': 'Installed', 'Мод удалён. Запустите проверку снова.': 'Mod removed. Run the test again.', 'Скопировано': 'Copied', 'Ключ сохранён': 'Key saved', 'Откроется окно входа Microsoft…': 'Microsoft sign-in window opens…', 'Запускаем проверку — игра откроется и закроется сама': 'Starting test — the game opens and closes by itself' };
boot();
