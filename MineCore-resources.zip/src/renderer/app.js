'use strict';
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const S = { cfg: null, page: 'home', arg: null, insts: [], vers: null, installed: [], tasks: {}, running: {}, setTab: 'game', vf: 'release', vq: '', busy: {}, fresh: true, sys: null, javas: null,
  cr: { name: '', mc: '', snap: false, loader: 'fabric', lv: '', lvs: [] }, it: 'installed', src: 'modrinth', mq: '', mres: [], mof: 0, mv: {}, mods: [], hf: { q: '', ver: '', loader: '', st: '', tag: '', fav: false }, mf: { cat: '', env: '', sort: '', mcv: '' }, pf: { cat: '', sort: '', mcv: '', loader: '' }, cats: {}, sel: null, upd: null, sk: null, coverFor: null, ft: 'mod', pq: '', pres: [], pof: 0, pv: {}, con: null, modal: null, lastRes: {}, vlim: 60, swap: false, mk: null, bga: null };

const IC = { home: 'M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10', layers: 'M12 3l9 5-9 5-9-5 9-5zM3 13l9 5 9-5M3 17l9 5 9-5', gear: 'M12 15a3 3 0 100-6 3 3 0 000 6zM19.4 15a1.7 1.7 0 00.3 1.9l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.9-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 01-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.9.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.9 1.7 1.7 0 00-1.5-1H3a2 2 0 010-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.9l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.9.3H9a1.7 1.7 0 001-1.5V3a2 2 0 014 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.9-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.9V9a1.7 1.7 0 001.5 1H21a2 2 0 010 4h-.1a1.7 1.7 0 00-1.5 1z', play: 'M6 4l14 8-14 8z', plus: 'M12 5v14M5 12h14', folder: 'M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2z', trash: 'M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14', edit: 'M12 20h9M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z', term: 'M4 17l6-6-6-6M12 19h8', check: 'M20 6L9 17l-5-5', x: 'M18 6L6 18M6 6l12 12', search: 'M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.3-4.3', copy: 'M9 9h11v11H9zM5 15H4V4h11v1', dots: 'M12 5h.01M12 12h.01M12 19h.01', stop: 'M6 6h12v12H6z', box: 'M21 8l-9-5-9 5v8l9 5 9-5zM3 8l9 5 9-5M12 13v8', logout: 'M9 21H5V3h4M16 17l5-5-5-5M21 12H9', down: 'M12 3v12m0 0l-5-5m5 5l5-5M5 21h14', min: 'M5 12h14', max: 'M5 5h14v14H5z', back: 'M15 18l-6-6 6-6', star: 'M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.9L12 17.8 5.8 21.1 7 14.2 2 9.3l6.9-1z', user: 'M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2M12 11a4 4 0 100-8 4 4 0 000 8z', swap: 'M7 4L3 8l4 4M3 8h14M17 20l4-4-4-4M21 16H7', img: 'M3 5h18v14H3zM3 16l5-5 4 4 3-3 6 6M9 9h.01', tag: 'M20 12l-8 8-9-9V3h8zM7.5 7.5h.01' };
const ic = (n, c = '') => `<svg class="ic ${c}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${IC[n]}"/></svg>`;
const t = s => S.cfg && S.cfg.lang === 'en' ? (EN[s] || s) : s;
const call = async (c, ...a) => { try { return await mc.call(c, ...a); } catch (e) { toast(String(e.message).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'err'); throw e; } };
const toast = (m, k) => { const d = document.createElement('div'); d.className = 'toast ' + (k || ''); d.textContent = m; $('#toasts').append(d); setTimeout(() => { d.classList.add('out'); setTimeout(() => d.remove(), 260); }, k === 'err' ? 9000 : 3200); };
const hue = n => [...n].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7) % 360;
const LN = { vanilla: 'Vanilla', fabric: 'Fabric', quilt: 'Quilt', forge: 'Forge', neoforge: 'NeoForge' };
const fmtN = n => n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : n >= 1e3 ? Math.round(n / 1e3) + 'K' : n;
const javaMajor = v => { const m = String(v).match(/^1\.(\d+)|^(\d+)/); return m ? (m[1] || m[2]) : '?'; };

/* ---------- navigation ---------- */
async function go(p, arg) {
  closeMenu(); S.arg = arg ?? null;
  try { if (p === 'create') await initCreate(); if (p === 'inst') await openInst(arg); if (p === 'versions') await loadVers(); if (p === 'settings') await loadSettings(); if (p === 'packs') initPacks(); } catch {}
  S.page = p; S.fresh = true; render();
}
async function refresh() { S.insts = await call('inst:list'); S.installed = await call('mc:installed'); }
async function boot() {
  S.cfg = await mc.call('cfg:get'); await refresh();
  mc.on('task', taskUpdate);
  mc.on('log', ({ key, line }) => { if (S.con && S.con.key === key) { S.con.lines.push(line); const p = $('#log'); if (p) { const b = p.scrollTop + p.clientHeight >= p.scrollHeight - 30; p.append(line + '\n'); if (b) p.scrollTop = p.scrollHeight; } } });
  mc.on('game-state', ({ key, running }) => { if (running) S.running[key] = 1; else delete S.running[key]; if (S.con && S.con.key === key) S.con.running = !!running; syncPause(); if (['home', 'versions', 'inst'].includes(S.page)) { S.fresh = false; render(); } });
  mc.on('game-exit', async r => {
    S.lastRes[r.key] = r; await refresh();
    if (r.test || !r.ok) openConsole(r.key, r); else if (S.page === 'home') render();
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeMenu(); if (S.modal === 'con') closeModal(); } });
  render();
}

/* ---------- shell ---------- */
function head(a, sz) {
  if (a.skin) return `<span class="head" style="--s:${sz}px;--sk:url(&quot;${esc(a.skin)}&quot;)"></span>`;
  if (a.type === 'ms') return `<img class="head img" style="--s:${sz}px" src="https://mc-heads.net/avatar/${esc(a.uuid)}/${sz * 2}" alt="">`;
  return `<img class="head img" style="--s:${sz}px" src="../assets/icon.png" alt="">`;
}
function syncPause() { const p = document.hidden || Object.keys(S.running).length > 0 || !(S.cfg && S.cfg.anim); document.body.classList.toggle('paused', p); if (window.FX) FX.pause(p); }
function render() {
  const c = S.cfg, root = document.documentElement;
  if (!['default', 'dark', 'light', 'cyber'].includes(c.theme)) { c.theme = 'default'; setCfg({ theme: 'default' }); }
  document.body.dataset.theme = c.theme; document.body.classList.toggle('noanim', !c.anim); root.style.setProperty('--acc', c.accent); document.body.classList.toggle('lite', !!c.superOpt); applyBg();
  document.documentElement.lang = c.lang;
  const a = c.account, nav = [['home', 'home', 'Главная'], ['versions', 'layers', 'Версии'], ['settings', 'gear', 'Настройки']];
  $('#app').innerHTML = `<aside id="side"><div class="brand"><img src="../assets/icon.png" alt=""><div><b>MineCore</b><span>Minecraft Java Launcher</span></div></div>
  <nav class="nav">${nav.map(([p, i, l]) => `<button class="${(S.page === p || (p === 'home' && ['create', 'inst', 'packs'].includes(S.page))) ? 'on' : ''}" data-act="go" data-p="${p}">${ic(i)}${t(l)}</button>`).join('')}</nav><div class="sp"></div>
  ${a ? `<div class="me" data-act="accMenu" title="${t('Аккаунты')}">${head(a, 40)}<div><b>${esc(a.name)}</b><small>${a.type === 'ms' ? 'Microsoft' : t('Офлайн')}</small></div><span class="ic-btn">${ic('swap')}</span></div>` : ''}</aside>
  <div id="main"><div id="bar"><button data-act="wmin">${ic('min')}</button><button data-act="wmax">${ic('max')}</button><button class="x" data-act="wclose">${ic('x')}</button></div>
  <div id="view" class="${S.fresh ? 'page' : ''}">${a ? view() : ''}</div></div>`;
  S.fresh = false; S.swap = false; syncPause();
  document.querySelectorAll('img.head').forEach(i => { i.onerror = () => { i.onerror = null; i.src = '../assets/icon.png'; }; });
  if (!a && S.modal !== 'welcome') { S.modal = 'welcome'; drawModal(); }
}
function view() { return ({ home, versions, settings, create, inst, packs })[S.page](); }
const TK = {};
function taskUpdate(d) {
  const box = $('#tasks'); let k = TK[d.id];
  if (d.done) { if (k) { k.fill.style.width = '100%'; k.pctEl.textContent = '100%'; k.el.classList.add('fin'); delete TK[d.id]; setTimeout(() => { k.el.classList.add('out'); setTimeout(() => k.el.remove(), 320); }, 700); } return; }
  if (!k) {
    const el = document.createElement('div'); el.className = 'task';
    el.innerHTML = '<div class="rowh"><b></b><span class="muted"></span></div><small class="muted"></small><div class="bar"><i style="width:0"></i></div>'; box.append(el);
    k = TK[d.id] = { el, fill: el.querySelector('i'), pctEl: el.querySelector('span'), sub: el.querySelector('small'), max: 0 }; el.querySelector('b').textContent = d.label;
  }
  k.max = Math.max(k.max, d.pct); const w = k.max; requestAnimationFrame(() => { k.fill.style.width = w + '%'; }); k.pctEl.textContent = w + '%'; if (d.sub) k.sub.textContent = d.sub;
}
const drawTasks = () => {};

/* ---------- home ---------- */
const TAGS = ['Выживание', 'Приключения', 'Техно', 'Магия', 'PvP', 'Оптимизация', 'Мини-игры', 'Креатив'];
const COVERS = {
  grass: ['Равнины', 'linear-gradient(180deg,#8fd0f7 0%,#cdebfb 46%,#62b043 46.4%,#3f8a2a 60%,#7a5636 60.4%,#4e3521 100%)'],
  nether: ['Незер', 'linear-gradient(180deg,#2a0a0d 0%,#7c1d19 58%,#d9561f 100%)'],
  end: ['Энд', 'radial-gradient(circle at 50% 38%,#7b59c9 0%,#2b1b4f 45%,#0f0a1f 80%)'],
  ice: ['Лёд', 'linear-gradient(180deg,#bfe9ff 0%,#6fb8e8 55%,#e8f6ff 55.4%,#cfe9f7 100%)'],
  desert: ['Пустыня', 'linear-gradient(180deg,#ffd58a 0%,#f4a259 50%,#d9a45b 50.4%,#b9803c 100%)']
};
function coverCss(i) {
  const cu = (S.cfg.bgs || []).find(b => b.id === i.cover);
  if (cu) return `url("${cu.url}") center/cover no-repeat`;
  if (COVERS[i.cover]) return COVERS[i.cover][1];
  if (BG[i.cover] && i.cover !== 'none') return BG[i.cover][1];
  const h = hue(i.name); return `linear-gradient(160deg,hsl(${h} 55% 38%),hsl(${h + 40} 50% 16%))`;
}
const fmtTime = ms => { const m = Math.round(ms / 60000); return m < 60 ? m + ' ' + t('мин') : (m / 60).toFixed(m < 600 ? 1 : 0) + ' ' + t('ч'); };
const selName = () => S.sel && S.insts.some(i => i.name === S.sel) ? S.sel : (S.insts.some(i => i.name === S.cfg.last) ? S.cfg.last : (S.insts[0] && S.insts[0].name));
function status(i) {
  if (!i.tested) return `<span class="chip cl" data-act="test" data-id="${esc(i.name)}">${t('Не проверена')} · ${t('проверить')}</span>`;
  return i.tested.ok ? `<span class="chip ok cl" data-act="test" data-id="${esc(i.name)}">${ic('check')} ${t('Проверена')} · ${Math.round(i.tested.ms / 1000)} ${t('с')}</span>` : `<span class="chip bad cl" data-act="test" data-id="${esc(i.name)}">${t('Ошибка проверки')}</span>`;
}
function playBtn(kind, id, big) {
  const key = kind + ':' + id;
  if (S.running[key]) return `<button class="btn danger ${big ? 'big' : ''}" data-act="stop" data-key="${esc(key)}">${ic('stop')} ${t('Остановить')}</button>`;
  if (kind === 'ver' && !S.installed.includes(id)) return `<button class="btn ghost sm ${S.busy[key] ? 'busy' : ''}" data-act="verInstall" data-id="${esc(id)}">${ic('down')} ${t('Установить')}</button>`;
  return `<button class="btn ${big ? 'big' : ''} ${S.busy[key] ? 'busy' : ''}" data-act="play" data-kind="${kind}" data-id="${esc(id)}">${ic('play')} ${S.busy[key] ? t('Подготовка…') : t('Играть')}</button>`;
}
function filteredInsts() {
  const f = S.hf, q = f.q.toLowerCase();
  return S.insts.filter(i => (!q || i.name.toLowerCase().includes(q)) && (!f.ver || i.mc === f.ver) && (!f.loader || i.loader === f.loader) && (!f.tag || (i.tags || []).includes(f.tag)) && (!f.fav || i.fav)
    && (!f.st || (f.st === 'ok' ? i.tested && i.tested.ok : f.st === 'no' ? !i.tested : i.tested && !i.tested.ok))).sort((a, b) => (b.fav ? 1 : 0) - (a.fav ? 1 : 0));
}
function instCard(i) {
  const key = 'inst:' + i.name, sel = selName() === i.name;
  return `<div class="card inst ${sel ? 'sel' : ''}" data-inst="${esc(i.name)}" data-act="select" data-id="${esc(i.name)}"><div class="thumb" style="background:${esc(coverCss(i))}"><button class="star ${i.fav ? 'on' : ''}" data-act="fav" data-id="${esc(i.name)}" title="${t('Избранное')}">${ic('star')}</button>${S.running[key] ? `<span class="live">${t('Запущена')}</span>` : ''}<button class="icon mini" data-act="menu" data-id="${esc(i.name)}">${ic('dots')}</button></div>
  <div class="body"><b>${esc(i.name)}</b><span class="muted">${esc(i.mc)} · ${LN[i.loader]}${i.loader !== 'vanilla' ? ' · ' + i.modCount + ' ' + t('модов') : ''}</span><div>${status(i)}${(i.tags || []).slice(0, 2).map(tg => `<span class="chip">${esc(tg)}</span>`).join('')}</div></div></div>`;
}
function hero() {
  const a = S.cfg.account, sel = S.insts.find(i => i.name === selName());
  if (!sel) return `<section id="hero" class="hero"><div class="hero-bg" style="background:linear-gradient(120deg,#1f8f7a,#3b2a5c)"></div><div class="hero-in"><h1>${t('Привет')}, ${esc(a.name)}!</h1><p>${t('У вас пока нет сборок. Создайте первую — это займёт пару минут.')}</p><div class="row"><button class="btn big" data-act="go" data-p="create">${ic('plus')} ${t('Создать сборку')}</button><button class="btn big ghost" data-act="go" data-p="packs">${ic('box')} ${t('Сборки Modrinth')}</button></div></div></section>`;
  return `<section id="hero" class="hero"><div class="hero-bg" style="background:${esc(coverCss(sel))}"></div><div class="hero-in"><small class="muted">${t('Привет')}, ${esc(a.name)}! ${t('Выбрана сборка')}:</small><h1>${esc(sel.name)}</h1>
  <div class="chips"><span class="chip g">${esc(sel.mc)}</span><span class="chip g">${LN[sel.loader]}</span>${sel.loader !== 'vanilla' ? `<span class="chip g">${sel.modCount} ${t('модов')}</span>` : ''}${sel.playMs ? `<span class="chip g">${ic('play')} ${fmtTime(sel.playMs)}</span>` : ''}${status(sel)}</div>
  <div class="row" style="margin-top:16px">${playBtn('inst', sel.name, true)}<button class="btn big ghost" data-act="test" data-id="${esc(sel.name)}">${ic('check')} ${t('Проверить')}</button><button class="icon big" data-act="openInst" data-id="${esc(sel.name)}" title="${t('Моды и настройки')}">${ic('gear')}</button><button class="icon big" data-act="menu" data-id="${esc(sel.name)}">${ic('dots')}</button></div></div></section>`;
}
function fsel(obj, key, opts) { return `<select data-flt="${obj}.${key}">${opts.map(([v, l]) => `<option value="${esc(v)}" ${S[obj][key] === v ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`; }
function toolbar() {
  const f = S.hf, vers = [...new Set(S.insts.map(i => i.mc))], lds = [...new Set(S.insts.map(i => i.loader))], tags = [...new Set(S.insts.flatMap(i => i.tags || []))];
  return `<div class="toolbar"><div class="srch">${ic('search')}<input type="search" placeholder="${t('Поиск сборок…')}" value="${esc(f.q)}" data-flt="hf.q"></div>
  ${fsel('hf', 'ver', [['', t('Все версии')], ...vers.map(v => [v, v])])}${fsel('hf', 'loader', [['', t('Все загрузчики')], ...lds.map(v => [v, LN[v]])])}${fsel('hf', 'st', [['', t('Любое состояние')], ['ok', t('Проверена')], ['no', t('Не проверена')], ['bad', t('С ошибкой')]])}
  <button class="chip cl ${f.fav ? 'ok' : ''}" data-act="hfFav">${ic('star')} ${t('Избранное')}</button>${tags.map(tg => `<button class="chip cl ${f.tag === tg ? 'ok' : ''}" data-act="hfTag" data-v="${esc(tg)}">${esc(tg)}</button>`).join('')}</div>`;
}
function gridHtml() {
  const l = filteredInsts(), f = S.hf, flt = f.q || f.ver || f.loader || f.tag || f.fav || f.st;
  return l.map(instCard).join('') + (flt ? (l.length ? '' : `<p class="muted">${t('Ничего не найдено')}</p>`) : `<button class="card new" data-act="go" data-p="create">${ic('plus')}<span>${t('Новая сборка')}</span></button>`);
}
const updGrid = () => { const g = $('#igrid'); if (g) g.innerHTML = gridHtml(); };
function home() {
  return `${hero()}<div class="actions"><button class="btn ghost sm" data-act="go" data-p="create">${ic('plus')} ${t('Создать сборку')}</button><button class="btn ghost sm" data-act="go" data-p="packs">${ic('box')} ${t('Сборки Modrinth')}</button><button class="btn ghost sm" data-act="go" data-p="versions">${ic('layers')} ${t('Версии игры')}</button></div>
  ${S.insts.length ? toolbar() : ''}<div class="grid" id="igrid">${gridHtml()}</div>`;
}

/* ---------- versions ---------- */
async function loadVers() { if (!S.vers) { try { S.vers = await call('mc:versions'); } catch { S.vers = { versions: [] }; } } }
function versions() {
  if (!S.vers) return `<h1>${t('Версии')}</h1><p class="muted">${t('Загрузка…')}</p>`;
  const f = S.vf, q = S.vq.toLowerCase();
  let list = S.vers.versions.filter(v => (f === 'release' ? v.type === 'release' : f === 'snapshot' ? v.type === 'snapshot' : f === 'old' ? /^old_/.test(v.type) : S.installed.includes(v.id)) && v.id.toLowerCase().includes(q));
  const more = list.length > S.vlim; list = list.slice(0, S.vlim);
  return `<h1>${t('Версии')}</h1><p class="muted">${t('Скачайте версию и играйте — без модов')}</p>
  <div class="row" style="margin:16px 0"><div class="tabs" style="margin:0">${[['release', 'Релизы'], ['snapshot', 'Снапшоты'], ['old', 'Старые (Beta/Alpha)'], ['inst', 'Установленные']].map(([k, l]) => `<button class="${f === k ? 'on' : ''}" data-act="vf" data-v="${k}">${t(l)}</button>`).join('')}</div>
  <input type="search" placeholder="${t('Поиск версии…')}" value="${esc(S.vq)}" data-bind="vq" style="width:220px"></div><p class="muted" style="margin:-6px 0 12px">${t('Здесь все версии, включая старые: 1.0–1.7.10, Beta и Alpha.')}</p>
  <div class="list" id="vlist">${list.map(v => `<div class="item" data-ver="${esc(v.id)}"><div class="t"><b>${esc(v.id)}</b><small>${v.type} · ${(v.date || '').slice(0, 10)}</small></div>${S.installed.includes(v.id) ? `<span class="chip ok">${t('Установлена')}</span>` : ''}${playBtn('ver', v.id)}<button class="icon" data-act="menuVer" data-id="${esc(v.id)}">${ic('dots')}</button></div>`).join('') || `<p class="muted">${t('Ничего не найдено')}</p>`}</div>${more ? `<div class="row" style="margin-top:12px"><button class="btn ghost" data-act="vmore">${t('Показать ещё')}</button></div>` : ''}`;
}

/* ---------- create ---------- */
async function initCreate() {
  if (!S.vers) { try { S.vers = await call('mc:versions'); } catch { return; } }
  const c = S.cr; c.name = ''; if (!c.mc) c.mc = S.vers.latest.release;
  await loadLV();
}
async function loadLV() {
  const c = S.cr; c.lvs = []; c.lv = '';
  if (c.loader !== 'vanilla') { try { c.lvs = await mc.call('loader:versions', { mc: c.mc, loader: c.loader }); } catch (e) { c.lvs = []; } c.lv = c.lvs[0] || ''; }
}
function create() {
  const c = S.cr; if (!S.vers) return `<p class="muted">${t('Загрузка…')}</p>`;
  const vs = S.vers.versions.filter(v => c.snap || v.type === 'release');
  const busy = S.busy.create;
  return `<button class="back" data-act="go" data-p="home">${ic('back')} ${t('Назад')}</button><h1>${t('Создать сборку')}</h1><p class="muted">${t('Всё скачается автоматически')}</p>
  <div class="panel" style="margin-top:18px;max-width:640px">
  <div class="field"><label>${t('Название')}</label><input type="text" id="crname" maxlength="40" placeholder="${t('Моя сборка')}" value="${esc(c.name)}" data-bind="cr.name"></div>
  <div class="field"><label>${t('Версия Minecraft')}</label><div class="fr"><select data-bind="cr.mc">${vs.map(v => `<option ${v.id === c.mc ? 'selected' : ''}>${v.id}</option>`).join('')}</select>
  <label class="row" style="flex:none;color:var(--muted)"><span class="sw"><input type="checkbox" data-bind="cr.snap" ${c.snap ? 'checked' : ''}><i></i></span>${t('Снапшоты и старые')}</label></div></div>
  <div class="field"><label>${t('Загрузчик')}</label><div class="loaders">${Object.entries(LN).map(([k, l]) => `<button class="${c.loader === k ? 'on' : ''}" data-act="loader" data-v="${k}">${l}</button>`).join('')}</div></div>
  ${c.loader !== 'vanilla' ? `<div class="field"><label>${t('Версия загрузчика')}</label>${c.lvs.length ? `<select data-bind="cr.lv">${c.lvs.slice(0, 60).map(v => `<option value="${esc(v)}" ${v === c.lv ? 'selected' : ''}>${esc(v.replace(c.mc + '-', ''))}</option>`).join('')}</select>` : `<p class="muted">${t('Для этой версии игры загрузчик недоступен — выберите другую версию или загрузчик')}</p>`}</div>` : ''}
  <button class="btn big ${busy ? 'busy' : ''}" data-act="doCreate" ${busy ? 'disabled' : ''}>${ic('check')} ${busy ? t('Создаём…') : t('Создать и скачать')}</button></div>`;
}

/* ---------- instance editor ---------- */
async function openInst(name) { S.it = 'installed'; S.mres = []; S.mq = ''; S.mv = {}; S.mof = 0; S.upd = null; S.mf = { cat: '', env: '', sort: '', mcv: '' }; if (!S.vers) mc.call('mc:versions').then(v => { S.vers = v; }).catch(() => {}); await loadMods(); }
async function loadMods() { try { S.mods = await mc.call('mod:list', S.arg); } catch { S.mods = []; } }
function curInst() { return S.insts.find(i => i.name === S.arg); }
const TN = { mod: 'Моды', resourcepack: 'Ресурспаки', shader: 'Шейдеры' };
function inst() {
  const i = curInst(); if (!i) return `<button class="back" data-act="go" data-p="home">${ic('back')} ${t('Назад')}</button>`;
  const types = i.loader === 'vanilla' ? ['resourcepack', 'shader'] : ['mod', 'resourcepack', 'shader'];
  if (!types.includes(S.ft)) S.ft = types[0];
  return `<button class="back" data-act="go" data-p="home">${ic('back')} ${t('Назад')}</button>
  <div class="rowh"><div><h1>${esc(i.name)}</h1><span class="muted">${esc(i.mc)} · ${LN[i.loader]} ${esc((i.loaderVer || '').replace(i.mc + '-', ''))}</span> ${status(i)}</div>
  <div class="row">${playBtn('inst', i.name, true)}<button class="btn ghost" data-act="test" data-id="${esc(i.name)}">${ic('check')} ${t('Проверить')}</button><button class="icon" data-act="console" data-key="inst:${esc(i.name)}" title="${t('Консоль')}">${ic('term')}</button><button class="icon" data-act="menu" data-id="${esc(i.name)}">${ic('dots')}</button></div></div>
  <div class="tabs"><button class="${S.it === 'installed' ? 'on' : ''}" data-act="itab" data-v="installed">${t('Установленные')} (${S.mods.length})</button><button class="${S.it === 'find' ? 'on' : ''}" data-act="itab" data-v="find">${t('Найти')}</button><button class="${S.it === 'settings' ? 'on' : ''}" data-act="itab" data-v="settings">${t('Настройки сборки')}</button></div>
  <div class="${S.swap ? 'swap' : ''}">${S.it === 'installed' ? installedMods(i) : S.it === 'find' ? findMods(types) : instSettings(i)}</div>`;
}
function installedMods(i) {
  if (!S.mods.length) return `<div class="panel muted">${t('Пока ничего не установлено. Откройте вкладку «Найти».')}</div>`;
  const row = m => `<div class="item">${m.icon ? `<img class="mi" src="${esc(m.icon)}">` : `<div class="mi">${esc((m.name[0] || '?').toUpperCase())}</div>`}<div class="t"><b>${esc(m.name)}</b><small>${esc(m.ver || m.file)}</small></div>
  ${m.type === 'mod' ? `<label class="sw"><input type="checkbox" ${m.enabled ? 'checked' : ''} data-act="modToggle" data-file="${esc(m.file)}"><i></i></label>` : ''}<button class="icon" data-act="modDel" data-file="${esc(m.file)}" data-type="${m.type}">${ic('trash')}</button></div>`;
  return Object.keys(TN).map(ty => { const l = S.mods.filter(m => m.type === ty); return l.length ? `<h3 style="margin:16px 0 8px">${t(TN[ty])} (${l.length})</h3><div class="list">${l.map(row).join('')}</div>` : ''; }).join('')
    + `<div class="row" style="margin-top:14px"><button class="btn ghost sm" data-act="folder" data-id="${esc(S.arg)}" data-sub="">${ic('folder')} ${t('Папка сборки')}</button></div>`;
}
const CATRU = { adventure: 'Приключения', cursed: 'Проклятые', decoration: 'Декор', economy: 'Экономика', equipment: 'Снаряжение', food: 'Еда', 'game-mechanics': 'Механики', library: 'Библиотеки', magic: 'Магия', management: 'Управление', minigame: 'Мини-игры', mobs: 'Мобы', optimization: 'Оптимизация', social: 'Социальные', storage: 'Хранение', technology: 'Технологии', transportation: 'Транспорт', utility: 'Утилиты', worldgen: 'Генерация мира', combat: 'Бой', realistic: 'Реализм', simplistic: 'Простые', themed: 'Тематические', tweaks: 'Правки', 'vanilla-like': 'Как ваниль', fonts: 'Шрифты', gui: 'Интерфейс', items: 'Предметы', locale: 'Локализация', modded: 'Для модов', models: 'Модели', audio: 'Звук', environment: 'Окружение', blocks: 'Блоки', entities: 'Существа', 'core-shaders': 'Шейдеры ядра', cartoon: 'Мультяшные', cinematic: 'Кинематографичные', fantasy: 'Фэнтези', potato: 'Для слабых ПК', low: 'Низкие', medium: 'Средние', high: 'Высокие', ultra: 'Ультра', 'semi-realistic': 'Полуреализм', colored: 'Цветные', 'path-tracing': 'Трассировка', reflections: 'Отражения', challenging: 'Сложные', 'kitchen-sink': 'Всё и сразу', lightweight: 'Лёгкие', multiplayer: 'Мультиплеер', quests: 'Квесты' };
const catName = c => S.cfg.lang === 'en' ? c.replace(/-/g, ' ').replace(/^./, x => x.toUpperCase()) : (CATRU[c] || c.replace(/-/g, ' ').replace(/^./, x => x.toUpperCase()));
const SORTS = [['', 'По умолчанию'], ['relevance', 'Релевантные'], ['downloads', 'Популярные'], ['follows', 'Любимые'], ['newest', 'Новые'], ['updated', 'Недавно обновлённые']];
function loadCats(type) {
  if (S.cats[type]) return; S.cats[type] = [];
  mc.call('mod:cats', type).then(r => { S.cats[type] = r; if ((S.page === 'inst' && S.it === 'find' && S.ft === type) || (S.page === 'packs' && type === 'modpack')) rerender(); }).catch(() => { delete S.cats[type]; });
}
const relVers = () => (S.vers ? S.vers.versions.filter(v => v.type === 'release').map(v => v.id) : []);
function findMods(types) {
  const i = curInst(), isMod = S.ft === 'mod', f = S.mf;
  return `<div class="row" style="margin-bottom:10px"><div class="seg">${types.map(k => `<button class="${S.ft === k ? 'on' : ''}" data-act="ftype" data-v="${k}">${t(TN[k])}</button>`).join('')}</div>
  <input type="search" placeholder="${t('Поиск…')}" value="${esc(S.mq)}" data-bind="mq" style="flex:1;min-width:200px"></div>
  <div class="row flt">${fsel('mf', 'cat', [['', t('Все категории')], ...(S.cats[S.ft] || []).map(c => [c, catName(c)])])}${isMod ? fsel('mf', 'env', [['', t('Любая среда')], ['client', t('Клиентские')], ['server', t('Серверные')]]) : fsel('mf', 'mcv', [['', t('Версия сборки') + ' (' + i.mc + ')'], ...relVers().map(v => [v, v])])}${fsel('mf', 'sort', SORTS.map(([v, l]) => [v, t(l)]))}${isMod ? `<span class="chip" style="margin:0">${t('Версия')}: ${esc(i.mc)} · ${LN[i.loader]}</span>` : ''}</div>
  ${S.ft === 'shader' ? `<div class="box warn" style="margin:12px 0">${t('Шейдерам нужен мод Iris (Fabric/Quilt) или Oculus + Embeddium (Forge/NeoForge). Сначала установите его во вкладке «Моды». Включаются шейдеры в настройках игры.')}</div>` : ''}<div class="list" id="mres" style="margin-top:12px">${resHtml(true)}</div>`;
}
const iramLabel = v => v < 1024 ? t('Как в настройках') + ' (' + (S.cfg.ram / 1024).toFixed(1) + ' ' + t('ГБ') + ')' : (v / 1024).toFixed(1) + ' ' + t('ГБ');
function instSettings(i) {
  const max = Math.max(2048, Math.floor(((S.sys || { totalMem: 8192 }).totalMem) / 512) * 512), ram = i.ram || 0, custom = (i.tags || []).filter(x => !TAGS.includes(x)), u = S.upd;
  return `<div class="panel"><h3>${t('Оформление')}</h3><div class="row"><div class="cprev" style="background:${esc(coverCss(i))}"></div><button class="btn ghost" data-act="coverOpen" data-id="${esc(i.name)}">${ic('img')} ${t('Изменить фон сборки')}</button><button class="btn ghost" data-act="fav" data-id="${esc(i.name)}">${ic('star')} ${i.fav ? t('В избранном') : t('В избранное')}</button></div></div>
  <div class="panel"><h3>${t('Метки')}</h3><p class="muted" style="margin-bottom:8px">${t('Цели сборки: по меткам удобно фильтровать список на главной')}</p><div class="row">${[...TAGS, ...custom].map(tg => `<button class="chip cl ${(i.tags || []).includes(tg) ? 'ok' : ''}" style="margin:0" data-act="tagToggle" data-v="${esc(tg)}" data-id="${esc(i.name)}">${esc(tg)}</button>`).join('')}</div>
  <div class="row" style="margin-top:12px"><input type="text" id="tagin" maxlength="20" placeholder="${t('Своя метка')}"><button class="btn ghost sm" data-act="tagAdd" data-id="${esc(i.name)}">${ic('plus')} ${t('Добавить')}</button></div></div>
  <div class="panel"><h3>${t('Память для этой сборки')}</h3><input type="range" min="0" max="${max}" step="512" value="${ram}" style="--p:${ram / max * 100}%" data-iram="1"><b id="v_iram">${iramLabel(ram)}</b></div>
  <div class="panel"><h3>${t('Статистика')}</h3><div class="set"><span>${t('Время в игре')}</span><b>${i.playMs ? fmtTime(i.playMs) : '—'}</b></div><div class="set"><span>${t('Последний запуск')}</span><b>${i.lastPlayed ? new Date(i.lastPlayed).toLocaleString() : '—'}</b></div><div class="set"><span>${t('Создана')}</span><b>${new Date(i.created).toLocaleDateString()}</b></div></div>
  <div class="panel"><h3>${t('Обновления')}</h3><p class="muted" style="margin-bottom:10px">${t('Проверяет моды, ресурспаки и шейдеры сборки на Modrinth')}</p>
  ${!u ? `<button class="btn ghost" data-act="updCheck">${ic('down')} ${t('Проверить обновления')}</button>` : u.busy ? `<button class="btn ghost" disabled><span class="spin"></span> ${t('Проверяем…')}</button>` : u.list.length ? `<div class="list" style="margin-bottom:12px">${u.list.map(x => `<div class="item"><div class="t"><b>${esc(x.name)}</b><small>${t(TN[x.type])} → ${esc(x.to)}</small></div></div>`).join('')}</div><button class="btn ${u.applying ? 'busy' : ''}" data-act="updApply" ${u.applying ? 'disabled' : ''}>${ic('check')} ${u.applying ? t('Обновляем…') : t('Обновить всё') + ' (' + u.list.length + ')'}</button>` : `<div class="chip ok" style="margin:0">${ic('check')} ${t('Всё актуально')}</div> <button class="btn ghost sm" data-act="updCheck">${t('Проверить снова')}</button>`}</div>`;
}
function modRow(m, anim) {
  const done = S.mods.some(x => x.pid === m.id && x.type === S.ft), busy = S.busy['m' + m.id];
  return `<div class="item ${anim ? 'in' : ''}" data-mid="${esc(m.id)}" style="flex-wrap:wrap">${m.icon ? `<img class="mi" src="${esc(m.icon)}">` : `<div class="mi">${esc(m.title[0])}</div>`}<div class="t"><b>${esc(m.title)}</b><small>${esc(m.author || '')} · ${fmtN(m.dl || 0)} ${t('загрузок')} — ${esc(m.desc)}</small></div>
  ${done ? `<span class="chip ok ${S.tick === m.id ? 'tick' : ''}" style="margin:0">${ic('check')} ${t('Скачано')}</span>` : busy ? `<button class="btn sm" disabled><span class="spin"></span> ${t('Скачивание')}</button>` : `<button class="btn sm" data-act="modInstall" data-id="${esc(m.id)}">${t('Установить')}</button><button class="btn ghost sm" data-act="modVers" data-id="${esc(m.id)}">${t('Версии')} ▾</button>`}
  ${S.mv[m.id] && !done ? `<div style="width:100%;padding-left:54px" class="list">${S.mv[m.id].length ? S.mv[m.id].slice(0, 12).map(v => `<div class="row"><span style="flex:1">${esc(v.name)} <span class="chip ${v.type === 'release' ? 'ok' : 'warn'}">${v.type}</span> <small class="muted">${(v.date || '').slice(0, 10)}</small></span><button class="btn sm ghost" data-act="modInstall" data-id="${esc(m.id)}" data-vid="${esc(v.id)}">${t('Установить')}</button></div>`).join('') : `<span class="muted">${t('Нет версий для этой сборки')}</span>`}</div>` : ''}</div>`;
}
function resHtml(anim) {
  if (S.busy.search) return `<p class="muted">${t('Поиск…')}</p>`;
  return S.mres.map(m => modRow(m, anim)).join('') + (S.mres.length >= 20 ? `<button class="btn ghost" data-act="moreMods">${t('Показать ещё')}</button>` : '') || `<p class="muted">${t('Ничего не найдено')}</p>`;
}
function updRow(id) { const m = S.mres.find(x => x.id === id), el = document.querySelector(`[data-mid="${CSS.escape(id)}"]`); if (m && el) el.outerHTML = modRow(m, false); }
let sTimer;
async function searchMods(append) {
  const i = curInst(); if (!i) return;
  S.busy.search = !append; if (!append) { S.mof = 0; $('#mres') && ($('#mres').innerHTML = resHtml()); }
  try { const r = await mc.call('mod:search', { q: S.mq, mc: i.mc, loader: i.loader, off: S.mof, type: S.ft, cat: S.mf.cat, env: S.ft === 'mod' ? S.mf.env : '', sort: S.mf.sort, mcv: S.ft === 'mod' ? '' : S.mf.mcv }); S.mres = append ? S.mres.concat(r) : r; }
  catch (e) { toast(String(e.message).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'err'); S.mres = append ? S.mres : []; }
  S.busy.search = false; $('#mres') && ($('#mres').innerHTML = resHtml(true));
}

/* ---------- modpacks ---------- */
function initPacks() { S.pf = { cat: '', sort: '', mcv: '', loader: '' }; loadCats('modpack'); if (!S.vers) mc.call('mc:versions').then(v => { S.vers = v; if (S.page === 'packs') rerender(); }).catch(() => {}); S.pq = ''; S.pres = []; S.pv = {}; S.busy.psearch = 1; searchPacks(); }
function packs() {
  return `<button class="back" data-act="go" data-p="home">${ic('back')} ${t('Назад')}</button><h1>${t('Сборки Modrinth')}</h1><p class="muted">${t('Готовые сборки скачаются сразу вместе с версией игры, загрузчиком и модами')}</p>
  <div class="row" style="margin:16px 0 8px"><input type="search" placeholder="${t('Поиск сборок…')}" value="${esc(S.pq)}" data-bind="pq" style="flex:1"></div>
  <div class="row flt" style="margin-bottom:14px">${fsel('pf', 'mcv', [['', t('Любая версия игры')], ...relVers().map(v => [v, v])])}${fsel('pf', 'loader', [['', t('Любой загрузчик')], ['fabric', 'Fabric'], ['forge', 'Forge'], ['neoforge', 'NeoForge'], ['quilt', 'Quilt']])}${fsel('pf', 'cat', [['', t('Все категории')], ...(S.cats.modpack || []).filter(c => !['fabric', 'forge', 'neoforge', 'quilt'].includes(c)).map(c => [c, catName(c)])])}${fsel('pf', 'sort', SORTS.map(([v, l]) => [v, t(l)]))}</div><div class="list" id="pres">${packHtml(true)}</div>`;
}
function packRow(m, anim) {
  const busy = S.busy['p' + m.id];
  return `<div class="item ${anim ? 'in' : ''}" data-pid="${esc(m.id)}" style="flex-wrap:wrap">${m.icon ? `<img class="mi" src="${esc(m.icon)}">` : `<div class="mi">${esc(m.title[0])}</div>`}<div class="t"><b>${esc(m.title)}</b><small>${esc(m.author || '')} · ${fmtN(m.dl || 0)} ${t('загрузок')} — ${esc(m.desc)}</small></div>
  ${busy ? `<button class="btn sm" disabled><span class="spin"></span> ${t('Установка…')}</button>` : `<button class="btn sm" data-act="packInstall" data-id="${esc(m.id)}">${t('Установить')}</button><button class="btn ghost sm" data-act="packVers" data-id="${esc(m.id)}">${t('Версии')} ▾</button>`}
  ${S.pv[m.id] && !busy ? `<div style="width:100%;padding-left:54px" class="list">${S.pv[m.id].slice(0, 15).map(v => `<div class="row"><span style="flex:1">${esc(v.name)} <span class="chip">${esc(v.mc)}</span> <small class="muted">${esc(v.loaders)}</small></span><button class="btn sm ghost" data-act="packInstall" data-id="${esc(m.id)}" data-vid="${esc(v.id)}">${t('Установить')}</button></div>`).join('')}</div>` : ''}</div>`;
}
function packHtml(anim) {
  if (S.busy.psearch) return `<p class="muted">${t('Поиск…')}</p>`;
  return S.pres.map(m => packRow(m, anim)).join('') + (S.pres.length >= 20 ? `<button class="btn ghost" data-act="morePacks">${t('Показать ещё')}</button>` : '') || `<p class="muted">${t('Ничего не найдено')}</p>`;
}
function updPack(id) { const m = S.pres.find(x => x.id === id), el = document.querySelector(`[data-pid="${CSS.escape(id)}"]`); if (m && el) el.outerHTML = packRow(m, false); }
async function searchPacks(append) {
  if (!append) { S.pof = 0; S.busy.psearch = 1; if ($('#pres')) $('#pres').innerHTML = packHtml(); }
  try { const r = await mc.call('pack:search', { q: S.pq, off: S.pof, mc: S.pf.mcv, loader: S.pf.loader, cat: S.pf.cat, sort: S.pf.sort }); S.pres = append ? S.pres.concat(r) : r; }
  catch (e) { toast(String(e.message).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'err'); if (!append) S.pres = []; }
  S.busy.psearch = 0; if ($('#pres')) $('#pres').innerHTML = packHtml(true);
}

/* ---------- settings ---------- */
async function loadSettings() { S.sys = await mc.call('sys:info'); if (S.setTab === 'java') loadJava(); }
async function loadJava() { try { S.javas = (await mc.call('java:list')).sort((a, b) => javaMajor(b.ver) - javaMajor(a.ver)); } catch { S.javas = []; } const el = $('#javalist'); if (el && S.page === 'settings' && S.setTab === 'java') el.innerHTML = javaList(); }
function tog(k, title, sub) { return `<div class="set"><div>${t(title)}${sub ? `<small>${t(sub)}</small>` : ''}</div><label class="sw"><input type="checkbox" data-cfg="${k}" ${S.cfg[k] ? 'checked' : ''}><i></i></label></div>`; }
const THEMES = [['default', 'По умолчанию', '#0b1113,#2ecc9a', 0], ['dark', 'Тёмная', '#0d0d0f,#8d8d99', 0], ['light', 'Светлая', '#eef3f3,#5d7273', 0], ['cyber', 'Cyberpunk', '#0e0a1a,#b46cff', 0]];
const OPT = [
  ['Умная сборка мусора и память Java', 'Тонкая настройка G1 GC: меньше фризов и рывков, быстрее подгрузка чанков'],
  ['Авто-подбор ОЗУ под число модов', 'Не больше 60% памяти ПК, чтобы система не тормозила'],
  ['Высокий приоритет игры', 'Windows отдаёт Minecraft больше процессорного времени'],
  ['Дискретная видеокарта для Java', 'На ноутбуках игра не уйдёт на встроенную графику'],
  ['Быстрый запуск', 'Пропускает повторную проверку уже проверенных файлов игры'],
  ['Лаунчер «засыпает» на время игры', 'Низкий приоритет, пауза анимаций, очистка кэша'],
  ['Облегчённый лаунчер', 'Без размытия панелей, живые фоны в 20 кадров/с'],
  ['Автоочистка старых логов', 'Только логи и отчёты о крэшах, миры и сохранения не затрагиваются']
];
function optPanel() {
  const on = !!S.cfg.superOpt;
  return `<div class="panel opt ${on ? 'on' : ''}"><div class="rowh"><div><h3 style="margin:0">⚡ ${t('Супер-оптимизация')}</h3><p class="muted" style="margin-top:4px">${t('Максимальная скорость игры и лаунчера. Механики, моды и ваши настройки не меняются.')}</p></div><label class="sw big"><input type="checkbox" data-opt="1" ${on ? 'checked' : ''}><i></i></label></div>
  <div class="optlist">${OPT.map(([n, d]) => `<div class="oi ${on ? 'on' : ''}">${ic('check')}<div><b>${t(n)}</b><small>${t(d)}</small></div></div>`).join('')}</div></div>`;
}
function javaList() { return S.javas ? S.javas.map(j => `<div class="set"><div>Java ${javaMajor(j.ver)} <small>${esc(j.comp)} · ${esc(j.ver)}</small></div>${j.installed ? `<div class="row"><span class="chip ok">${t('Установлена')}</span><button class="icon" data-act="javaDel" data-v="${esc(j.comp)}">${ic('trash')}</button></div>` : `<button class="btn sm" data-act="javaGet" data-v="${esc(j.comp)}">${ic('down')} ${t('Скачать')}</button>`}</div>`).join('') : `<p class="muted">${t('Загрузка…')}</p>`; }
function settings() {
  const c = S.cfg, tab = S.setTab, sys = S.sys || { totalMem: 8192, root: c.root };
  const max = Math.max(2048, Math.floor(sys.totalMem / 512) * 512), rec = sys.totalMem >= 16000 ? '6–8' : sys.totalMem >= 8000 ? '4–6' : '2–3';
  let body = '';
  if (tab === 'game') body = `<div class="panel"><h3>${t('Оперативная память (ОЗУ)')}</h3><input type="range" min="1024" max="${max}" step="512" value="${Math.min(c.ram, max)}" style="--p:${(Math.min(c.ram, max) - 1024) / (max - 1024) * 100}%" data-cfg="ram" data-live="ramv"><div class="rowh"><b id="ramv">${(c.ram / 1024).toFixed(1)} ${t('ГБ')}</b><span class="muted">${t('Рекомендуется')}: ${rec} ${t('ГБ')} · ${t('всего в ПК')}: ${(sys.totalMem / 1024).toFixed(0)} ${t('ГБ')}</span></div></div>
  <div class="panel"><h3>${t('Оптимизация')}</h3>${tog('g1', 'Оптимизированные параметры Java', 'Флаги G1GC — меньше фризов и рывков')}${tog('hideOnPlay', 'Сворачивать лаунчер при запуске', 'Уйдёт в панель задач за 5 секунд до старта игры и вернётся, когда игра закроется')}${tog('fullscreen', 'Полноэкранный режим')}</div>
  <div class="panel"><h3>${t('Дополнительные аргументы JVM')}</h3><input type="text" style="width:100%" value="${esc(c.jvm)}" data-cfg="jvm" placeholder="-Dfile.encoding=UTF-8"></div>`;
  if (tab === 'java') {
    const javas = javaList();
    const dirs = [['', 'Корневая папка', 'Всё хранится здесь'], ['instances', 'Сборки', 'У каждой сборки своя папка: моды, миры, скриншоты'], ['versions', 'Версии игры', 'Скачанные версии Minecraft'], ['vanilla', 'Обычные версии', 'Миры и настройки игры без сборок'], ['runtime', 'Java', 'Скачанные версии Java'], ['logs', 'Журналы', 'Логи запусков']];
    body = `${optPanel()}<div class="panel"><h3>Java</h3><p class="muted" style="margin-bottom:8px">${t('Нужная Java скачивается автоматически при запуске. Здесь можно скачать её заранее.')}</p><div id="javalist">${javas}</div>
    <div class="set"><div>${t('Своя Java')}<small>${esc(c.javaPath || t('Не выбрана — используется автоматическая'))}</small></div><div class="row"><button class="btn ghost sm" data-act="javaPick">${t('Выбрать')}</button>${c.javaPath ? `<button class="icon" data-act="javaClear">${ic('x')}</button>` : ''}</div></div></div>
    <div class="panel"><h3>${t('Лаунчер и папки')}</h3><div class="set"><div>${t('Корневая папка')}<small>${esc(c.root)}</small></div><button class="btn ghost sm" data-act="rootPick">${t('Изменить')}</button></div>
    <p class="muted" style="margin:6px 0">${t('При смене папки старые данные не переносятся автоматически.')}</p>
    ${dirs.map(([k, n, d]) => `<div class="set"><div>${t(n)}<small>${t(d)}</small></div><button class="icon" data-act="openRoot" data-v="${k}">${ic('folder')}</button></div>`).join('')}
</div>`;
  }
  if (tab === 'look') body = `<div class="panel"><h3>${t('Язык')}</h3><div class="seg"><button class="${c.lang === 'ru' ? 'on' : ''}" data-act="lang" data-v="ru">Русский</button><button class="${c.lang === 'en' ? 'on' : ''}" data-act="lang" data-v="en">English</button></div></div>
  <div class="panel"><h3>${t('Тема')}</h3><div class="themes">${THEMES.map(([k, n, cl, live]) => `<div class="th ${c.theme === k ? 'on' : ''} ${live ? 'live' : ''}" data-act="theme" data-v="${k}">${live ? `<em class="badge"><b></b>${t('Анимированная')}</em>` : ''}<i style="background:linear-gradient(135deg,${cl.split(',')[0]} 55%,${cl.split(',')[1]})"></i>${t(n)}</div>`).join('')}</div></div>
  <div class="panel"><h3>${t('Цвет акцента')}</h3><div class="sw-c">${['#2ecc9a', '#27b5f0', '#5b7cfa', '#a56cff', '#ee5fa7', '#f5a345', '#ef6a4c'].map(x => `<b style="background:${x}" class="${c.accent === x ? 'on' : ''}" data-act="accent" data-v="${x}"></b>`).join('')}</div></div>
  ${bgPanel()}<div class="panel">${tog('anim', 'Анимации интерфейса')}</div>`;
  if (tab === 'acc') body = `<div class="panel"><div class="rowh" style="margin-bottom:6px"><h3 style="margin:0">${t('Аккаунты')}</h3><button class="btn sm" data-act="accAdd">${ic('plus')} ${t('Добавить аккаунт')}</button></div>${c.accounts.map(a => `<div class="set">${head(a, 44)}<div style="flex:1;margin-left:4px"><b>${esc(a.name)}</b>${c.account && a.id === c.account.id ? `<span class="chip ok" style="margin:0 0 0 8px">${t('Активный')}</span>` : ''}<small>${a.type === 'ms' ? 'Microsoft' : t('Офлайн')}</small></div><div class="row">${c.account && a.id !== c.account.id ? `<button class="btn ghost sm" data-act="accSwitch" data-id="${esc(a.id)}">${t('Выбрать')}</button>` : ''}<button class="btn ghost sm" data-act="skinOpen" data-id="${esc(a.id)}">${ic('user')} ${t('Скин')}</button><button class="icon" data-act="accDel" data-id="${esc(a.id)}">${ic('trash')}</button></div></div>`).join('')}</div>`;
  return `<h1>${t('Настройки')}</h1><div class="tabs">${[['game', 'Игра'], ['java', 'Java и лаунчер'], ['look', 'Внешний вид'], ['acc', 'Аккаунт']].map(([k, l]) => `<button class="${tab === k ? 'on' : ''}" data-act="stab" data-v="${k}">${t(l)}</button>`).join('')}</div><div style="max-width:720px" class="${S.swap ? 'swap' : ''}">${body}</div>`;
}

/* ---------- backgrounds ---------- */
const BG = {
  aurora: ['Аврора', 'radial-gradient(70% 60% at 15% 10%,#1f8f7a66,transparent 60%),radial-gradient(60% 60% at 90% 20%,#6a4fd855,transparent 60%),radial-gradient(80% 70% at 50% 115%,#2ecc9a40,transparent 60%),#0a1416'],
  sunset: ['Закат', 'linear-gradient(180deg,#2a1b3d 0%,#7a3b6b 34%,#e0755a 60%,#f2b36b 76%,#1b1a2b 76.3%,#10121f 100%)'],
  ocean: ['Океан', 'radial-gradient(60% 50% at 70% 0%,#2f9fd455,transparent 60%),radial-gradient(70% 60% at 10% 100%,#1b4f9c66,transparent 60%),linear-gradient(180deg,#0b1d33,#08121f)'],
  forest: ['Лес', 'radial-gradient(60% 50% at 20% 0%,#4caf6a48,transparent 60%),radial-gradient(70% 60% at 90% 100%,#1f6b4a66,transparent 60%),linear-gradient(180deg,#0e1f17,#09130f)'],
  dusk: ['Сумерки', 'radial-gradient(60% 50% at 80% 10%,#b46cff44,transparent 60%),radial-gradient(60% 60% at 10% 90%,#ee5fa744,transparent 60%),linear-gradient(180deg,#171028,#0c0818)'],
  ember: ['Угли', 'radial-gradient(60% 50% at 50% 115%,#ff7a3d55,transparent 60%),radial-gradient(40% 40% at 10% 0%,#a83a5a44,transparent 60%),linear-gradient(180deg,#1a1114,#100a0c)'],
  none: ['Без фона', 'none']
};
const FXBG = {
  'fx-aurora': ['Северное сияние', 'linear-gradient(160deg,#04101a,#0d3b3a 50%,#3a2a7a)'],
  'fx-space': ['Космос', 'radial-gradient(circle at 70% 30%,#5b4bff88,transparent 55%),radial-gradient(circle at 20% 80%,#c23ac955,transparent 50%),#05060f'],
  'fx-waves': ['Закат над морем', 'linear-gradient(180deg,#1a2b52,#e08a6a 50%,#2a5a86 52%,#06172b)'],
  'fx-embers': ['Огонь', 'linear-gradient(0deg,#7a2a0c,#1d0b0a 70%,#080406)'],
  'fx-synth': ['Синтвейв', 'linear-gradient(180deg,#090218,#5a1a6a 55%,#ff4fa0 56%,#12062a 57%,#05010f)']
};
function applyBg() {
  const c = S.cfg, el = $('#bg'), cv = $('#fxc'); if (!el) return;
  const fx = String(c.bg || '').startsWith('fx-') && FXBG[c.bg];
  if (fx && window.FX) {
    el.style.background = 'none'; el.style.filter = 'none'; el.style.transform = 'none';
    cv.style.opacity = c.bgOpacity / 100; cv.style.filter = `brightness(${c.bgBright}%)`;
    FX.quality(c.superOpt ? 'low' : 'normal'); FX.set(c.bg.slice(3)); return;
  }
  if (window.FX) FX.set(null);
  const cu = (c.bgs || []).find(b => b.id === c.bg), pre = BG[c.bg];
  el.style.background = cu ? `url("${cu.url}") center/cover no-repeat` : pre ? pre[1] : 'none';
  el.style.filter = `blur(${c.bgBlur}px) brightness(${c.bgBright}%)`; el.style.opacity = c.bgOpacity / 100; el.style.transform = c.bgBlur ? 'scale(1.08)' : 'none';
}
function rng(k, label, min, max, val, unit, attr) {
  return `<div class="field" style="margin-bottom:12px"><div class="rowh"><label>${t(label)}</label><b id="v_${k}">${val}${unit}</b></div><input type="range" min="${min}" max="${max}" value="${val}" style="--p:${(val - min) / (max - min) * 100}%" ${attr}="${k}" data-unit="${unit}"></div>`;
}
function bgPanel() {
  const c = S.cfg, cur = c.bg, tile = (id, name, css, del) => `<div class="bgt ${cur === id ? 'on' : ''}" data-act="bgSet" data-v="${esc(id)}" style="background:${css}"><span>${esc(name)}</span>${del ? `<button class="bgx" data-act="bgDel" data-v="${esc(id)}">${ic('x')}</button>` : ''}</div>`;
  return `<div class="panel"><h3>${t('Фон лаунчера')}</h3><div class="bgs">${Object.entries(BG).map(([id, [n, css]]) => tile(id, t(n), css === 'none' ? 'var(--panel2)' : css)).join('')}${(c.bgs || []).map(b => tile(b.id, b.name || t('Свой фон'), `url("${b.url}") center/cover`, true)).join('')}<div class="bgt add" data-act="bgAdd">${ic('plus')}<span>${t('Добавить свой')}</span></div></div>
  <h3 style="margin:20px 0 10px">${t('Анимированные фоны')}</h3><div class="bgs">${Object.entries(FXBG).map(([id, [n, css]]) => `<div class="bgt fxt ${cur === id ? 'on' : ''}" data-act="bgSet" data-v="${id}" style="background:${css}"><em class="badge"><b></b>${t('Анимированный')}</em><span>${t(n)}</span></div>`).join('')}</div>
  ${cur !== 'none' ? `<div style="margin-top:16px">${String(cur).startsWith('fx-') ? '' : rng('bgBlur', 'Размытие', 0, 24, c.bgBlur, ' px', 'data-bgk')}${rng('bgBright', 'Яркость', 30, 130, c.bgBright, '%', 'data-bgk')}${rng('bgOpacity', 'Прозрачность', 10, 100, c.bgOpacity, '%', 'data-bgk')}</div>` : ''}</div>`;
}
function bgaStyle() { const a = S.bga; return `background:url("${a.data}") center/cover;filter:blur(${a.blur}px) brightness(${a.bright}%);opacity:${a.opacity / 100};transform:${a.blur ? 'scale(1.08)' : 'none'}`; }
function skFile(f) {
  if (!f) return; if (f.type !== 'image/png') return toast(t('Нужен PNG-файл'), 'err'); if (f.size > 1024 * 1024) return toast(t('Файл слишком большой'), 'err');
  const r = new FileReader(); r.onload = () => { const im = new Image(); im.onload = () => { if (im.naturalWidth !== 64 || ![32, 64].includes(im.naturalHeight)) return toast(t('Скин должен быть 64×64 или 64×32'), 'err'); S.sk.data = r.result; drawModal(); }; im.src = r.result; }; r.readAsDataURL(f);
}
function fltChanged(obj, text) { if (obj === 'hf') return updGrid(); clearTimeout(sTimer); const run = () => obj === 'mf' ? searchMods() : searchPacks(); if (text) sTimer = setTimeout(run, 450); else run(); }
function bgaFile(f) {
  if (!f) return; if (!/^image\/(png|jpeg|webp|gif)$/.test(f.type)) return toast(t('Нужна картинка PNG, JPG или WebP'), 'err');
  if (f.size > 25 * 1024 * 1024) return toast(t('Файл больше 25 МБ'), 'err');
  const r = new FileReader(); r.onload = () => { S.bga.data = r.result; S.bga.name = f.name.replace(/\.[^.]+$/, ''); drawModal(); }; r.readAsDataURL(f);
}

/* ---------- modals ---------- */
function closeModal() { S.modal = null; S.mk = null; if (S.con) { mc.call('console:detach'); S.con = null; } const m = $('#modal'), el = m.firstElementChild; if (el) { el.classList.add('out'); setTimeout(() => { if (el.parentNode === m) el.remove(); }, 180); } }
function drawModal() {
  const m = $('#modal'), same = S.mk === S.modal; S.mk = S.modal;
  if (S.modal === 'welcome') {
    const ms = S.wtab === 'ms', add = !!S.cfg.account;
    m.innerHTML = `<div class="modal"><div class="dlg wide">${add ? `<button class="icon" style="position:absolute;right:14px;top:14px" data-act="closeModal">${ic('x')}</button>` : ''}<div class="row" style="margin-bottom:12px"><img src="../assets/icon.png" width="46" height="46" style="border-radius:12px"><div><h2>${add ? t('Добавить аккаунт') : t('Добро пожаловать в MineCore')}</h2><span class="muted">${add ? t('Можно добавить любое количество аккаунтов') : t('Создайте аккаунт — это нужно только один раз')}</span></div></div>
    <div class="seg" style="margin:10px 0 16px"><button class="${!ms ? 'on' : ''}" data-act="wtab" data-v="off">${t('Офлайн')}</button><button class="${ms ? 'on' : ''}" data-act="wtab" data-v="ms">Microsoft</button></div>
    ${ms ? `<p class="muted" style="margin-bottom:16px">${t('Войдите в аккаунт Microsoft с купленным Minecraft Java Edition.')}</p><button class="btn big" data-act="msLogin" style="width:100%">${t('Войти через Microsoft')}</button>`
      : `<div class="field"><label>${t('Ник в игре')}</label><input type="text" id="nick" maxlength="16" placeholder="Player123" style="user-select:text"><small class="muted">${t('3–16 символов: латиница, цифры, _')}</small></div><button class="btn big" data-act="offLogin" style="width:100%">${t('Продолжить')}</button>`}</div></div>`;
  } else if (S.modal === 'con') {
    const c = S.con;
    m.innerHTML = `<div class="modal"><div class="dlg con"><div class="ch"><b>${t('Консоль')} · ${esc(c.title)}</b><span class="chip ${c.running ? 'ok' : ''}" style="margin:0">${c.running ? t('Работает') : t('Остановлена')}</span><span class="sp"></span><button class="icon" data-act="conCopy" title="${t('Копировать')}">${ic('copy')}</button>${c.running ? `<button class="btn sm danger" data-act="stop" data-key="${esc(c.key)}">${t('Остановить')}</button>` : ''}<button class="icon" data-act="closeModal">${ic('x')}</button></div>${ana(c.res)}<pre id="log">${esc(c.lines.join('\n'))}</pre></div></div>`;
    const p = $('#log'); if (p) p.scrollTop = p.scrollHeight;
  } else if (S.modal === 'ask') {
    const a = S.ask;
    m.innerHTML = `<div class="modal"><div class="dlg"><h2>${esc(a.title)}</h2>${a.input !== undefined ? `<input type="text" id="askin" value="${esc(a.input)}" maxlength="40" style="width:100%;margin:12px 0;user-select:text">` : `<p class="muted" style="margin:10px 0 14px">${esc(a.text || '')}</p>`}<div class="row" style="justify-content:flex-end"><button class="btn ghost" data-act="askNo">${t('Отмена')}</button><button class="btn ${a.danger ? 'danger' : ''}" data-act="askYes">${t('Ок')}</button></div></div></div>`;
    const i = $('#askin'); if (i) { i.focus(); i.select(); i.onkeydown = e => { if (e.key === 'Enter') acts.askYes(); }; }
  } else if (S.modal === 'skin') {
    const k = S.sk, a = S.cfg.accounts.find(x => x.id === k.id); if (!a) return closeModal();
    m.innerHTML = `<div class="modal"><div class="dlg bgm"><h2>${t('Скин')}: ${esc(a.name)}</h2>
    <p class="muted" style="margin-bottom:14px">${a.type === 'ms' ? t('Скин обновится на серверах Minecraft и будет виден везде.') : t('Офлайн-аккаунт: скин сохраняется в лаунчере и подставляется в сборки через мод CustomSkinLoader — установите его во вкладке «Моды».')}</p>
    <div class="row" style="align-items:flex-start;gap:18px">${head({ ...a, skin: k.data || a.skin }, 96)}<div style="flex:1"><div class="drop" id="drop" data-act="skPick" style="height:110px;margin-bottom:12px"><span>${k.data ? t('Файл выбран') : t('Перетащите PNG сюда или нажмите')}</span><small class="muted">64×64 ${t('или')} 64×32</small></div><input type="file" id="skfile" accept="image/png" hidden>
    <div class="seg"><button class="${k.model === 'classic' ? 'on' : ''}" data-act="skModel" data-v="classic">${t('Классический')}</button><button class="${k.model === 'slim' ? 'on' : ''}" data-act="skModel" data-v="slim">${t('Тонкий (Alex)')}</button></div></div></div>
    <div class="row" style="justify-content:flex-end;margin-top:18px">${a.skin ? `<button class="btn ghost" data-act="skReset">${t('Сбросить скин')}</button>` : ''}<button class="btn ghost" data-act="closeModal">${t('Отмена')}</button><button class="btn" data-act="skApply" ${k.data ? '' : 'disabled'}>${t('Применить')}</button></div></div></div>`;
  } else if (S.modal === 'cover') {
    const i = S.insts.find(x => x.name === S.coverFor); if (!i) return closeModal();
    const tile = (id, name, css, del) => `<div class="bgt ${i.cover === id ? 'on' : ''}" data-act="coverSet" data-v="${esc(id)}" style="background:${esc(css)}"><span>${esc(name)}</span></div>`;
    m.innerHTML = `<div class="modal"><div class="dlg bgm" style="width:min(640px,94vw)"><h2>${t('Фон сборки')}: ${esc(i.name)}</h2><div class="bgs scr" style="max-height:52vh;overflow:auto;margin:14px 0;padding:2px">${tile('', t('Авто'), coverCss({ name: i.name }))}${Object.entries(COVERS).map(([id, [n, css]]) => tile(id, t(n), css)).join('')}${Object.entries(BG).filter(([id]) => id !== 'none').map(([id, [n, css]]) => tile(id, t(n), css)).join('')}${(S.cfg.bgs || []).map(b => tile(b.id, b.name || t('Свой фон'), `url("${b.url}") center/cover`)).join('')}<div class="bgt add" data-act="coverAdd">${ic('plus')}<span>${t('Добавить свой')}</span></div></div>
    <div class="row" style="justify-content:flex-end"><button class="btn" data-act="closeModal">${t('Готово')}</button></div></div></div>`;
  } else if (S.modal === 'bgadd') {
    const a = S.bga;
    m.innerHTML = `<div class="modal"><div class="dlg bgm"><h2>${t('Свой фон')}</h2><p class="muted" style="margin-bottom:12px">${t('Перетащите картинку в окно или нажмите на область ниже')}</p>
    <div class="drop" id="drop" data-act="bgPick">${a.data ? `<div id="bgprev" style="${bgaStyle()}"></div>` : `${ic('down')}<span>${t('Перетащите файл сюда')}</span><small class="muted">PNG, JPG, WebP · ${t('до 25 МБ')}</small>`}</div><input type="file" id="bgfile" accept="image/png,image/jpeg,image/webp" hidden>
    ${a.target === 'cover' ? '' : rng('blur', 'Размытие', 0, 24, a.blur, ' px', 'data-bga') + rng('bright', 'Яркость', 30, 130, a.bright, '%', 'data-bga') + rng('opacity', 'Прозрачность', 10, 100, a.opacity, '%', 'data-bga')}
    <div class="row" style="justify-content:flex-end;margin-top:6px"><button class="btn ghost" data-act="closeModal">${t('Отмена')}</button><button class="btn" data-act="bgApply" ${a.data ? '' : 'disabled'}>${t('Применить')}</button></div></div></div>`;
  } else m.innerHTML = '';
  if (same) { const mm = m.firstElementChild; if (mm) mm.classList.add('static'); }
}
function ask(title, o = {}) { return new Promise(res => { S.ask = { title, ...o, res }; S.modal = 'ask'; drawModal(); }); }
function ana(r) {
  if (!r) return '';
  let h = '';
  if (r.test && r.ok) h += `<div class="box ok"><b>✓ ${t('Сборка работает!')}</b><br><span class="muted">${t('Игра дошла до главного меню за')} ${Math.round(r.ms / 1000)} ${t('с')}.</span></div>`;
  else if (r.ok) return '';
  for (const w of r.warns || []) h += `<div class="box warn">⚠ ${esc(w)}</div>`;
  const a = r.analysis;
  if (a) {
    h += `<div class="box err"><b>${t('Что пошло не так')}</b></div>`;
    for (const it of a.items) h += `<div class="box err"><b>${esc(it.title)}</b><p>${esc(it.text)}</p>${it.fixes.length ? `<div class="muted" style="margin-top:6px">${t('Как починить')}:</div><ul>${it.fixes.map(f => `<li>${esc(f)}</li>`).join('')}</ul>` : ''}${it.details ? `<pre class="d">${esc(it.details)}</pre>` : ''}${it.hint ? `<div class="row" style="margin-top:8px"><button class="btn sm" data-act="goSet">${t('Открыть настройки')}</button></div>` : ''}</div>`;
    if (a.suspects.length) h += `<div class="box warn"><b>${t('Подозрительные моды')}</b>${a.suspects.map(f => `<div class="row" style="margin-top:6px"><span style="flex:1">${esc(f)}</span><button class="btn sm danger" data-act="susDel" data-file="${esc(f)}" data-key="${esc(r.key)}">${t('Удалить')}</button></div>`).join('')}</div>`;
    if (a.crash) h += `<div class="row" style="margin-bottom:8px"><button class="btn ghost sm" data-act="crash" data-f="${esc(a.crash)}">${t('Открыть отчёт о крэше')}</button></div>`;
  }
  return `<div class="ana scr">${h}</div>`;
}
async function openConsole(key, res) {
  const r = await mc.call('console:get', key); await mc.call('console:attach', key);
  const title = key.slice(key.indexOf(':') + 1);
  S.con = { key, title, lines: r.lines, running: r.running, res: res || r.result || null }; S.modal = 'con'; drawModal();
}

/* ---------- actions ---------- */
function showMenu(x, y, items) {
  closeMenu(); const m = document.createElement('div'); m.id = 'ctx';
  m.innerHTML = items.map(i => i === '-' ? '<hr>' : `<button class="${i.cls || ''}" data-act="${i.act}" ${Object.entries(i.d || {}).map(([k, v]) => `data-${k}="${esc(v)}"`).join(' ')}>${ic(i.ic)}${t(i.l)}</button>`).join('');
  document.body.append(m); const r = m.getBoundingClientRect();
  m.style.left = Math.min(x, innerWidth - r.width - 8) + 'px'; m.style.top = Math.min(y, innerHeight - r.height - 8) + 'px';
}
const closeMenu = () => { const m = $('#ctx'); if (m) m.remove(); };
function instMenu(name, x, y) {
  const key = 'inst:' + name;
  showMenu(x, y, [S.running[key] ? { l: 'Остановить', act: 'stop', ic: 'stop', d: { key } } : { l: 'Играть', act: 'play', ic: 'play', d: { kind: 'inst', id: name } }, { l: 'Проверить сборку', act: 'test', ic: 'check', d: { id: name } }, { l: 'Консоль', act: 'console', ic: 'term', d: { key } }, { l: 'Моды и настройки', act: 'openInst', ic: 'box', d: { id: name } }, '-',
    { l: 'Папка сборки', act: 'folder', ic: 'folder', d: { id: name, sub: '' } }, { l: 'Папка модов', act: 'folder', ic: 'folder', d: { id: name, sub: 'mods' } }, { l: 'Переименовать', act: 'rename', ic: 'edit', d: { id: name } }, { l: 'Дублировать', act: 'dup', ic: 'copy', d: { id: name } }, '-', { l: 'Удалить', act: 'delInst', ic: 'trash', cls: 'danger', d: { id: name } }]);
}
function verMenu(id, x, y) { showMenu(x, y, [{ l: 'Консоль', act: 'console', ic: 'term', d: { key: 'ver:' + id } }, { l: 'Открыть папку', act: 'folderVer', ic: 'folder', d: { id } }, ...(S.installed.includes(id) ? ['-', { l: 'Удалить версию', act: 'delVer', ic: 'trash', cls: 'danger', d: { id } }] : [])]); }
async function run(key, fn) { S.busy[key] = 1; rerender(); try { await fn(); } finally { delete S.busy[key]; await refresh(); rerender(); } }
function rerender() { S.fresh = false; const sc = $('#view') ? $('#view').scrollTop : 0; render(); if ($('#view')) $('#view').scrollTop = sc; }
const setCfg = async p => { S.cfg = await mc.call('cfg:set', p); };

const acts = {
  go: d => go(d.p), wmin: () => mc.call('win:min'), wmax: () => mc.call('win:max'), wclose: () => mc.call('win:close'),
  accMenu: (d, e) => { const r = e.target.closest('[data-act]').getBoundingClientRect(); showMenu(r.left, r.top - 8 - 44 * (S.cfg.accounts.length + 3), [...S.cfg.accounts.map(a => ({ l: a.name, act: 'accSwitch', ic: S.cfg.account && a.id === S.cfg.account.id ? 'check' : 'user', d: { id: a.id } })), '-', { l: 'Управление аккаунтами', act: 'accManage', ic: 'gear' }, { l: 'Добавить аккаунт', act: 'accAdd', ic: 'plus' }]); },
  accSwitch: async d => { S.cfg = await call('acct:switch', d.id); rerender(); },
  accManage: () => { S.setTab = 'acc'; go('settings'); },
  accAdd: () => { S.wtab = 'off'; S.modal = 'welcome'; S.mk = null; drawModal(); },
  accDel: async d => { const a = S.cfg.accounts.find(x => x.id === d.id); if (await ask(t('Удалить аккаунт?'), { text: a.name + ' — ' + t('аккаунт и его скин будут удалены из лаунчера.'), danger: true })) { S.cfg = await call('acct:delete', d.id); S.fresh = false; render(); } },
  skinOpen: d => { const a = S.cfg.accounts.find(x => x.id === d.id); S.sk = { id: d.id, data: '', model: a.model || 'classic' }; S.modal = 'skin'; S.mk = null; drawModal(); },
  skPick: () => { const i = $('#skfile'); if (i) i.click(); },
  skModel: d => { S.sk.model = d.v; drawModal(); },
  skApply: async () => { try { S.cfg = await call('acct:skin', { id: S.sk.id, data: S.sk.data, model: S.sk.model }); closeModal(); rerender(); toast(t('Скин сохранён')); } catch {} },
  skReset: async () => { try { S.cfg = await call('acct:skinReset', S.sk.id); closeModal(); rerender(); } catch {} },
  select: d => { S.sel = d.id; setCfg({ last: d.id }); document.querySelectorAll('.card.inst').forEach(c => c.classList.toggle('sel', c.dataset.inst === d.id)); const h = $('#hero'); if (h) h.outerHTML = hero(); },
  fav: async d => { const i = S.insts.find(x => x.name === d.id); await call('inst:set', { name: d.id, patch: { fav: !i.fav } }); await refresh(); rerender(); },
  hfFav: () => { S.hf.fav = !S.hf.fav; rerender(); },
  hfTag: d => { S.hf.tag = S.hf.tag === d.v ? '' : d.v; rerender(); },
  coverOpen: d => { S.coverFor = d.id; S.modal = 'cover'; S.mk = null; drawModal(); },
  coverSet: async d => { await call('inst:set', { name: S.coverFor, patch: { cover: d.v } }); await refresh(); drawModal(); rerender(); },
  coverAdd: () => { S.bga = { data: '', name: '', blur: 0, bright: 100, opacity: 100, target: 'cover' }; S.modal = 'bgadd'; S.mk = null; drawModal(); },
  tagToggle: async d => { const i = S.insts.find(x => x.name === d.id), tags = i.tags || []; await call('inst:set', { name: d.id, patch: { tags: tags.includes(d.v) ? tags.filter(x => x !== d.v) : [...tags, d.v] } }); await refresh(); rerender(); },
  tagAdd: async d => { const v = ($('#tagin').value || '').trim(); if (!v) return; const i = S.insts.find(x => x.name === d.id), tags = i.tags || []; if (!tags.includes(v)) await call('inst:set', { name: d.id, patch: { tags: [...tags, v] } }); await refresh(); rerender(); },
  updCheck: async () => { S.upd = { busy: true }; rerender(); try { S.upd = { list: await call('mod:updates', S.arg) }; } catch { S.upd = null; } rerender(); },
  updApply: async () => { const u = S.upd; u.applying = true; rerender(); try { const done = await call('mod:updateAll', { name: S.arg, list: u.list }); toast(t('Обновлено') + ': ' + done.length); await loadMods(); await refresh(); S.upd = { list: [] }; } catch { u.applying = false; } rerender(); },
  wtab: d => { S.wtab = d.v; drawModal(); },
  offLogin: async () => { try { S.cfg = await call('acct:offline', $('#nick').value); closeModal(); S.fresh = false; render(); } catch {} },
  msLogin: async () => { try { toast(t('Откроется окно входа Microsoft…')); S.cfg = await call('acct:ms'); closeModal(); S.fresh = false; render(); } catch {} },
  play: d => { const key = d.kind + ':' + d.id; run(key, () => call('game:play', { kind: d.kind, id: d.id }).catch(() => {})); },
  test: d => { const key = 'inst:' + d.id; run(key, async () => { toast(t('Запускаем проверку — игра откроется и закроется сама')); await call('game:play', { kind: 'inst', id: d.id, test: true }).catch(() => {}); }); },
  stop: d => mc.call('game:stop', d.key),
  verInstall: d => run('ver:' + d.id, () => call('ver:install', d.id).then(() => toast(t('Версия установлена'))).catch(() => {})),
  menu: (d, e) => { const r = e.target.closest('[data-act]').getBoundingClientRect(); instMenu(d.id, r.left, r.bottom + 4); },
  menuVer: (d, e) => { const r = e.target.closest('[data-act]').getBoundingClientRect(); verMenu(d.id, r.left - 150, r.bottom + 4); },
  console: d => openConsole(d.key, S.lastRes[d.key]),
  openInst: d => go('inst', d.id),
  folder: d => mc.call('folder:open', { kind: 'inst', id: d.id, sub: d.sub }),
  folderVer: d => mc.call('folder:open', { kind: 'ver', id: d.id }),
  openRoot: d => mc.call('folder:open', { kind: 'root', sub: d.v }),
  rename: async d => { const to = await ask(t('Новое название'), { input: d.id }); if (to && to !== d.id) { try { const n = await call('inst:rename', { name: d.id, to }); if (S.page === 'inst') S.arg = n; await refresh(); S.cfg = await mc.call('cfg:get'); rerender(); } catch {} } },
  dup: async d => { try { await call('inst:dup', { name: d.id }); await refresh(); rerender(); toast(t('Сборка скопирована')); } catch {} },
  delInst: async d => { if (await ask(t('Удалить сборку?'), { text: d.id + ' — ' + t('все её моды и миры будут удалены.'), danger: true })) { try { await call('inst:delete', d.id); if (S.page === 'inst') S.page = 'home'; await refresh(); rerender(); } catch {} } },
  delVer: async d => { if (await ask(t('Удалить версию?'), { text: d.id, danger: true })) { await call('ver:delete', d.id); await refresh(); rerender(); } },
  vf: d => { S.vf = d.v; S.vlim = 60; rerender(); },
  vmore: () => { S.vlim += 80; rerender(); },
  bgSet: async d => { await setCfg({ bg: d.v }); S.swap = false; rerender(); },
  bgDel: async d => { S.cfg = await call('bg:del', d.v); rerender(); },
  bgAdd: () => { S.bga = { data: '', name: '', blur: 0, bright: 100, opacity: 100 }; S.modal = 'bgadd'; drawModal(); },
  bgPick: () => { const i = $('#bgfile'); if (i) i.click(); },
  bgApply: async () => { const a = S.bga; try { if (a.target === 'cover') { const r = await call('bg:upload', { name: a.name, data: a.data }); S.cfg = r.cfg; await call('inst:set', { name: S.coverFor, patch: { cover: r.id } }); await refresh(); S.bga = null; S.modal = 'cover'; drawModal(); rerender(); return; } S.cfg = await call('bg:add', { name: a.name, data: a.data, blur: a.blur, bright: a.bright, opacity: a.opacity }); closeModal(); rerender(); } catch {} },
  loader: async d => { S.cr.loader = d.v; await loadLV(); rerender(); },
  doCreate: () => { const c = S.cr; run('create', async () => { try { const n = await call('inst:create', { name: c.name || t('Моя сборка'), mc: c.mc, loader: c.loader, lv: c.lv }); await refresh(); S.cr.name = ''; go('inst', n); toast(t('Сборка создана')); } catch {} }); },
  morePacks: () => { S.pof += 20; searchPacks(true); },
  packVers: async d => { if (S.pv[d.id]) delete S.pv[d.id]; else { try { S.pv[d.id] = await call('pack:versions', { id: d.id }); } catch {} } updPack(d.id); },
  packInstall: async d => {
    const key = 'p' + d.id; if (S.busy[key]) return; S.busy[key] = 1; updPack(d.id);
    try {
      let vid = d.vid; if (!vid) { const vs = S.pv[d.id] || await call('pack:versions', { id: d.id }); if (!vs.length) { toast(t('У сборки нет версий'), 'err'); return; } vid = vs[0].id; }
      const m = S.pres.find(x => x.id === d.id); const n = await call('pack:install', { pid: d.id, vid, title: m && m.title });
      await refresh(); toast(t('Сборка установлена') + ': ' + n); await go('inst', n);
    } catch {} finally { delete S.busy[key]; delete S.pv[d.id]; updPack(d.id); }
  },
  ftype: d => { S.ft = d.v; S.mres = []; S.mv = {}; S.mq = ''; S.mf = { cat: '', env: '', sort: '', mcv: '' }; loadCats(d.v); rerender(); searchMods(); },
  itab: d => { S.it = d.v; S.swap = true; rerender(); if (d.v === 'find') { loadCats(S.ft); if (!S.mres.length) searchMods(); } },
  moreMods: () => { S.mof += 20; searchMods(true); },
  modVers: async d => { if (S.mv[d.id]) { delete S.mv[d.id]; } else { const i = curInst(); try { S.mv[d.id] = await call('mod:versions', { id: d.id, mc: S.ft === 'mod' ? i.mc : (S.mf.mcv || i.mc), loader: i.loader, type: S.ft }); } catch {} } updRow(d.id); },
  modInstall: async d => {
    const i = curInst(); let vid = d.vid; if (S.busy['m' + d.id]) return;
    S.busy['m' + d.id] = 1; updRow(d.id);
    try {
      if (!vid) { const vs = S.mv[d.id] || await call('mod:versions', { id: d.id, mc: S.ft === 'mod' ? i.mc : (S.mf.mcv || i.mc), loader: i.loader, type: S.ft }); if (!vs.length) { toast(t('Нет версии для этой сборки'), 'err'); return; } vid = vs[0].id; }
      const m = S.mres.find(x => x.id === d.id);
      await call('mod:install', { name: i.name, pid: d.id, vid, title: m && m.title, icon: m && m.icon, type: S.ft });
      await loadMods(); await refresh(); S.tick = d.id;
      const tb = document.querySelector('[data-act="itab"][data-v="installed"]'); if (tb) tb.textContent = t('Установленные') + ' (' + S.mods.length + ')';
    } catch {} finally { delete S.busy['m' + d.id]; delete S.mv[d.id]; updRow(d.id); S.tick = null; }
  },
  modToggle: async d => { try { await call('mod:toggle', { name: S.arg, file: d.file }); await loadMods(); await refresh(); rerender(); } catch {} },
  modDel: async d => { await call('mod:remove', { name: S.arg, file: d.file, type: d.type }); await loadMods(); await refresh(); rerender(); },
  susDel: async d => { const n = d.key.slice(5); await call('mod:remove', { name: n, file: d.file }); toast(t('Мод удалён. Запустите проверку снова.')); await refresh(); closeModal(); },
  crash: d => mc.call('path:open', d.f),
  goSet: () => { closeModal(); S.setTab = 'game'; go('settings'); },
  conCopy: () => { navigator.clipboard.writeText(S.con.lines.join('\n')).then(() => toast(t('Скопировано'))); },
  closeModal, askYes: () => { const a = S.ask, v = a.input !== undefined ? $('#askin').value.trim() : true; closeModal(); a.res(v); }, askNo: () => { const a = S.ask; closeModal(); a.res(null); },
  stab: d => { S.setTab = d.v; S.swap = true; rerender(); if (d.v === 'java') loadJava(); },
  lang: async d => { await setCfg({ lang: d.v }); rerender(); }, theme: async d => { await setCfg({ theme: d.v }); rerender(); }, accent: async d => { await setCfg({ accent: d.v }); rerender(); },
  javaGet: d => run('j' + d.v, async () => { await call('java:install', d.v).catch(() => {}); await loadJava(); }),
  javaDel: async d => { await call('java:delete', d.v); loadJava(); },
  javaPick: async () => { S.cfg = await mc.call('sys:pickJava'); rerender(); }, javaClear: async () => { await setCfg({ javaPath: '' }); rerender(); },
  rootPick: async () => { S.cfg = await mc.call('sys:setRoot'); await refresh(); S.sys = await mc.call('sys:info'); rerender(); }
};
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  closeMenu();
  if (el && el.tagName === 'INPUT') return;
  if (el) { e.stopPropagation(); acts[el.dataset.act] && acts[el.dataset.act](el.dataset, e); }
});
document.addEventListener('contextmenu', e => {
  const c = e.target.closest('[data-inst]'), v = e.target.closest('[data-ver]');
  if (c) { e.preventDefault(); instMenu(c.dataset.inst, e.clientX, e.clientY); } else if (v) { e.preventDefault(); verMenu(v.dataset.ver, e.clientX, e.clientY); }
});
document.addEventListener('change', async e => {
  const el = e.target;
  if (el.id === 'bgfile') return bgaFile(el.files[0]);
  if (el.id === 'skfile') return skFile(el.files[0]);
  if (el.dataset.opt) { try { S.cfg = await call('opt:apply', el.checked); } catch {} rerender(); return; }
  if (el.dataset.flt && el.tagName === 'SELECT') { const [o, k] = el.dataset.flt.split('.'); S[o][k] = el.value; return fltChanged(o, false); }
  if (el.dataset.iram) { const v = +el.value < 1024 ? 0 : +el.value; await call('inst:set', { name: S.arg, patch: { ram: v } }); await refresh(); return; }
  if (el.dataset.bgk) return setCfg({ [el.dataset.bgk]: +el.value });
  if (el.dataset.act === 'modToggle') return acts.modToggle(el.dataset);
  if (el.dataset.cfg) { const k = el.dataset.cfg; let v = el.type === 'checkbox' ? el.checked : el.type === 'range' ? +el.value : el.value; await setCfg({ [k]: v }); if (k === 'anim') rerender(); }
  if (el.dataset.bind) {
    const b = el.dataset.bind;
    if (b === 'cr.mc') { S.cr.mc = el.value; await loadLV(); rerender(); }
    else if (b === 'cr.snap') { S.cr.snap = el.checked; rerender(); }
    else if (b === 'cr.lv') S.cr.lv = el.value;
  }
});
document.addEventListener('input', e => {
  const el = e.target;
  if (el.dataset.flt && el.tagName !== 'SELECT') { const [o, k] = el.dataset.flt.split('.'); S[o][k] = el.value; fltChanged(o, true); }
  if (el.dataset.iram) { const lab = $('#v_iram'); if (lab) lab.textContent = iramLabel(+el.value < 1024 ? 0 : +el.value); }
  if (el.type === 'range') {
    el.style.setProperty('--p', (el.value - el.min) / (el.max - el.min) * 100 + '%');
    const lab = $('#v_' + (el.dataset.bgk || el.dataset.bga)); if (lab) lab.textContent = el.value + el.dataset.unit;
    if (el.dataset.bgk) { S.cfg[el.dataset.bgk] = +el.value; applyBg(); }
    if (el.dataset.bga) { S.bga[el.dataset.bga] = +el.value; const p = $('#bgprev'); if (p) p.setAttribute('style', bgaStyle()); }
  }
  if (el.dataset.live) { $('#' + el.dataset.live).textContent = (el.value / 1024).toFixed(1) + ' ' + t('ГБ'); }
  const b = el.dataset.bind; if (!b) return;
  if (b === 'cr.name') S.cr.name = el.value;
  if (b === 'pq') { S.pq = el.value; clearTimeout(sTimer); sTimer = setTimeout(() => searchPacks(), 450); }
  if (b === 'mq') { S.mq = el.value; clearTimeout(sTimer); sTimer = setTimeout(() => searchMods(), 450); }
  if (b === 'vq') { S.vq = el.value; const p = el.selectionStart; rerender(); const n = $('[data-bind=vq]'); if (n) { n.focus(); n.setSelectionRange(p, p); } }
});
window.addEventListener('blur', closeMenu);
document.addEventListener('dragover', e => e.preventDefault());
document.addEventListener('drop', e => { e.preventDefault(); if (S.modal === 'bgadd') bgaFile(e.dataTransfer.files[0]); else if (S.modal === 'skin') skFile(e.dataTransfer.files[0]); });
document.addEventListener('dblclick', e => { const c = e.target.closest('.card[data-inst]'); if (c && !e.target.closest('button,.chip')) acts.play({ kind: 'inst', id: c.dataset.inst }); });
document.addEventListener('visibilitychange', syncPause);
document.addEventListener('dragenter', e => { const d = $('#drop'); if (d && e.target.closest('#drop')) d.classList.add('over'); });
document.addEventListener('dragleave', e => { const d = $('#drop'); if (d && !e.relatedTarget) d.classList.remove('over'); });

const EN = { 'Анимированные фоны': 'Animated backgrounds', 'Анимированный': 'Animated', 'Закат над морем': 'Sunset sea', 'Огонь': 'Fire', 'Супер-оптимизация': 'Super optimization', 'Максимальная скорость игры и лаунчера. Механики, моды и ваши настройки не меняются.': 'Maximum game and launcher speed. Mechanics, mods and your settings stay untouched.', 'Умная сборка мусора и память Java': 'Smart garbage collection & Java memory', 'Тонкая настройка G1 GC: меньше фризов и рывков, быстрее подгрузка чанков': 'Tuned G1 GC: fewer stutters, faster chunk loading', 'Авто-подбор ОЗУ под число модов': 'Auto RAM by mod count', 'Не больше 60% памяти ПК, чтобы система не тормозила': 'Up to 60% of PC memory so the system stays responsive', 'Высокий приоритет игры': 'High game priority', 'Windows отдаёт Minecraft больше процессорного времени': 'Windows gives Minecraft more CPU time', 'Дискретная видеокарта для Java': 'Discrete GPU for Java', 'На ноутбуках игра не уйдёт на встроенную графику': 'Laptops will not fall back to integrated graphics', 'Быстрый запуск': 'Fast start', 'Пропускает повторную проверку уже проверенных файлов игры': 'Skips re-checking already verified game files', 'Лаунчер «засыпает» на время игры': 'Launcher sleeps while you play', 'Низкий приоритет, пауза анимаций, очистка кэша': 'Low priority, paused animations, cache cleanup', 'Облегчённый лаунчер': 'Lightweight launcher', 'Без размытия панелей, живые фоны в 20 кадров/с': 'No panel blur, live backgrounds at 20 fps', 'Автоочистка старых логов': 'Old log cleanup', 'Только логи и отчёты о крэшах, миры и сохранения не затрагиваются': 'Only logs and crash reports; worlds and saves are untouched', 'Выбрана сборка': 'Selected pack', 'У вас пока нет сборок. Создайте первую — это займёт пару минут.': 'You have no packs yet. Create your first one — it takes a couple of minutes.', 'Версии игры': 'Game versions', 'Избранное': 'Favorites', 'Запущена': 'Running', 'Все версии': 'All versions', 'Все загрузчики': 'All loaders', 'Любое состояние': 'Any state', 'С ошибкой': 'Has errors', 'мин': 'min', 'ч': 'h', 'Аккаунты': 'Accounts', 'Управление аккаунтами': 'Manage accounts', 'Добавить аккаунт': 'Add account', 'Можно добавить любое количество аккаунтов': 'You can add any number of accounts', 'Активный': 'Active', 'Выбрать': 'Select', 'Скин': 'Skin', 'Удалить аккаунт?': 'Delete account?', 'аккаунт и его скин будут удалены из лаунчера.': 'the account and its skin will be removed from the launcher.', 'Скин обновится на серверах Minecraft и будет виден везде.': 'The skin is updated on Minecraft servers and visible everywhere.', 'Офлайн-аккаунт: скин сохраняется в лаунчере и подставляется в сборки через мод CustomSkinLoader — установите его во вкладке «Моды».': 'Offline account: the skin is stored in the launcher and passed to packs via the CustomSkinLoader mod — install it in the Mods tab.', 'Файл выбран': 'File selected', 'Перетащите PNG сюда или нажмите': 'Drop a PNG here or click', 'или': 'or', 'Классический': 'Classic', 'Тонкий (Alex)': 'Slim (Alex)', 'Сбросить скин': 'Reset skin', 'Скин сохранён': 'Skin saved', 'Нужен PNG-файл': 'PNG file required', 'Файл слишком большой': 'File is too large', 'Скин должен быть 64×64 или 64×32': 'Skin must be 64×64 or 64×32', 'Фон сборки': 'Pack background', 'Авто': 'Auto', 'Готово': 'Done', 'Равнины': 'Plains', 'Незер': 'Nether', 'Энд': 'End', 'Лёд': 'Ice', 'Пустыня': 'Desert', 'Изменить фон сборки': 'Change pack background', 'В избранном': 'In favorites', 'В избранное': 'Add to favorites', 'Настройки сборки': 'Pack settings', 'Оформление': 'Appearance', 'Метки': 'Tags', 'Цели сборки: по меткам удобно фильтровать список на главной': 'Pack goals: filter the home list by tags', 'Своя метка': 'Custom tag', 'Добавить': 'Add', 'Память для этой сборки': 'Memory for this pack', 'Как в настройках': 'Same as settings', 'Статистика': 'Statistics', 'Время в игре': 'Play time', 'Последний запуск': 'Last played', 'Создана': 'Created', 'Обновления': 'Updates', 'Проверяет моды, ресурспаки и шейдеры сборки на Modrinth': 'Checks mods, resource packs and shaders on Modrinth', 'Проверить обновления': 'Check for updates', 'Проверяем…': 'Checking…', 'Обновить всё': 'Update all', 'Обновляем…': 'Updating…', 'Всё актуально': 'Everything is up to date', 'Проверить снова': 'Check again', 'Обновлено': 'Updated', 'Выживание': 'Survival', 'Приключения': 'Adventure', 'Техно': 'Tech', 'Магия': 'Magic', 'Оптимизация': 'Optimization', 'Мини-игры': 'Minigames', 'Креатив': 'Creative', 'Все категории': 'All categories', 'Любая среда': 'Any environment', 'Клиентские': 'Client-side', 'Серверные': 'Server-side', 'Версия сборки': 'Pack version', 'Версия': 'Version', 'Любая версия игры': 'Any game version', 'Любой загрузчик': 'Any loader', 'По умолчанию': 'Default', 'Релевантные': 'Relevant', 'Популярные': 'Popular', 'Любимые': 'Most followed', 'Новые': 'Newest', 'Недавно обновлённые': 'Recently updated', 'Анимированная': 'Animated', 'Северное сияние': 'Aurora', 'Космос': 'Space', 'Синтвейв': 'Synthwave', 'Сборки Modrinth': 'Modrinth packs', 'Готовые сборки в один клик': 'Ready-made packs in one click', 'Готовые сборки скачаются сразу вместе с версией игры, загрузчиком и модами': 'Packs download together with the game version, loader and mods', 'Поиск сборок…': 'Search packs…', 'Установка…': 'Installing…', 'Моды': 'Mods', 'Ресурспаки': 'Resource packs', 'Шейдеры': 'Shaders', 'Найти': 'Find', 'Поиск…': 'Searching…', 'Пока ничего не установлено. Откройте вкладку «Найти».': 'Nothing installed yet. Open the "Find" tab.', 'Шейдерам нужен мод Iris (Fabric/Quilt) или Oculus + Embeddium (Forge/NeoForge). Сначала установите его во вкладке «Моды». Включаются шейдеры в настройках игры.': 'Shaders need the Iris mod (Fabric/Quilt) or Oculus + Embeddium (Forge/NeoForge). Install it in the Mods tab first. Enable shaders in game settings.', 'Сборка установлена': 'Pack installed', 'У сборки нет версий': 'The pack has no versions', 'Главная': 'Home', 'Версии': 'Versions', 'Настройки': 'Settings', 'Офлайн': 'Offline', 'Сменить аккаунт': 'Switch account', 'Не проверена': 'Not tested', 'проверить': 'test', 'Проверена': 'Tested', 'с': 's', 'Ошибка проверки': 'Test failed', 'модов': 'mods', 'Остановить': 'Stop', 'Установить': 'Install', 'Подготовка…': 'Preparing…', 'Играть': 'Play', 'Привет': 'Hello', 'Готов к новым приключениям?': 'Ready for new adventures?', 'Создать сборку': 'Create pack', 'Версия, загрузчик и моды из Modrinth': 'Version, loader and mods from Modrinth', 'Выбор версии': 'Choose version', 'Играть в обычный Minecraft без модов': 'Play vanilla Minecraft', 'Мои сборки': 'My packs', 'Новая сборка': 'New pack', 'Установленные версии': 'Installed versions', 'Загрузка…': 'Loading…', 'Скачайте версию и играйте — без модов': 'Download a version and play — no mods', 'Релизы': 'Releases', 'Снапшоты': 'Snapshots', 'Установленные': 'Installed', 'Поиск версии…': 'Search version…', 'Установлена': 'Installed', 'Ничего не найдено': 'Nothing found', 'Показаны первые 60 — уточните поиск': 'First 60 shown — refine your search', 'Всё скачается автоматически': 'Everything downloads automatically', 'Название': 'Name', 'Моя сборка': 'My pack', 'Версия Minecraft': 'Minecraft version', 'Загрузчик': 'Loader', 'Версия загрузчика': 'Loader version', 'Для этой версии игры загрузчик недоступен — выберите другую версию или загрузчик': 'No loader for this game version — pick another version or loader', 'Создаём…': 'Creating…', 'Создать и скачать': 'Create & download', 'Назад': 'Back', 'Проверить': 'Test', 'Консоль': 'Console', 'Это чистая сборка без загрузчика — моды недоступны. Создайте сборку с Fabric, Forge, Quilt или NeoForge, чтобы ставить моды.': 'Vanilla pack — no mods. Create a pack with Fabric, Forge, Quilt or NeoForge to use mods.', 'Найти моды': 'Find mods', 'Модов пока нет. Откройте вкладку «Найти моды».': 'No mods yet. Open "Find mods".', 'Папка модов': 'Mods folder', 'Поиск модов…': 'Search mods…', 'Поиск…': 'Searching…', 'загрузок': 'downloads', 'Установлен': 'Installed', 'Версии': 'Versions', 'Нет версий для этой сборки': 'No versions for this pack', 'Показать ещё': 'Show more', 'Оперативная память (ОЗУ)': 'Memory (RAM)', 'ГБ': 'GB', 'Рекомендуется': 'Recommended', 'всего в ПК': 'total in PC', 'Оптимизация': 'Optimization', 'Оптимизированные параметры Java': 'Optimized Java flags', 'Флаги G1GC — меньше фризов и рывков': 'G1GC flags — fewer stutters', 'Сворачивать лаунчер при запуске': 'Minimize launcher on play', 'Окно вернётся, когда игра закроется': 'Returns when the game closes', 'Полноэкранный режим': 'Fullscreen', 'Дополнительные аргументы JVM': 'Extra JVM arguments', 'Нужная Java скачивается автоматически при запуске. Здесь можно скачать её заранее.': 'The right Java downloads automatically on launch. You can pre-download it here.', 'Скачать': 'Download', 'Своя Java': 'Custom Java', 'Не выбрана — используется автоматическая': 'Not set — automatic', 'Выбрать': 'Choose', 'Лаунчер и папки': 'Launcher & folders', 'Корневая папка': 'Root folder', 'Изменить': 'Change', 'При смене папки старые данные не переносятся автоматически.': 'Old data is not moved automatically when changing the folder.', 'Всё хранится здесь': 'Everything is stored here', 'Сборки': 'Packs', 'У каждой сборки своя папка: моды, миры, скриншоты': 'Each pack has its own folder: mods, worlds, screenshots', 'Версии игры': 'Game versions', 'Скачанные версии Minecraft': 'Downloaded Minecraft versions', 'Обычные версии': 'Vanilla data', 'Миры и настройки игры без сборок': 'Worlds and settings of plain versions', 'Скачанные версии Java': 'Downloaded Java runtimes', 'Журналы': 'Logs', 'Логи запусков': 'Launch logs', 'Фон лаунчера': 'Launcher background', 'Свой фон': 'Custom background', 'Добавить свой': 'Add your own', 'Аврора': 'Aurora', 'Закат': 'Sunset', 'Океан': 'Ocean', 'Лес': 'Forest', 'Сумерки': 'Dusk', 'Угли': 'Embers', 'Без фона': 'No background', 'Размытие': 'Blur', 'Яркость': 'Brightness', 'Прозрачность': 'Opacity', 'Применить': 'Apply', 'Перетащите картинку в окно или нажмите на область ниже': 'Drop an image into the window or click the area below', 'Перетащите файл сюда': 'Drop a file here', 'до 25 МБ': 'up to 25 MB', 'Нужна картинка PNG, JPG или WebP': 'PNG, JPG or WebP image required', 'Файл больше 25 МБ': 'File is larger than 25 MB', 'Скачано': 'Downloaded', 'Скачивание': 'Downloading', 'Старые (Beta/Alpha)': 'Old (Beta/Alpha)', 'Снапшоты и старые': 'Snapshots & old', 'Здесь все версии, включая старые: 1.0–1.7.10, Beta и Alpha.': 'All versions incl. old ones: 1.0–1.7.10, Beta and Alpha.', 'Уйдёт в панель задач за 5 секунд до старта игры и вернётся, когда игра закроется': 'Goes to the taskbar 5 seconds before the game starts and returns when it closes', 'Язык': 'Language', 'Тема': 'Theme', 'По умолчанию': 'Default', 'Тёмная': 'Dark', 'Светлая': 'Light', 'Цвет акцента': 'Accent color', 'Анимации интерфейса': 'UI animations', 'Аккаунт': 'Account', 'Игра': 'Game', 'Java и лаунчер': 'Java & launcher', 'Внешний вид': 'Appearance', 'Добро пожаловать в MineCore': 'Welcome to MineCore', 'Создайте аккаунт — это нужно только один раз': 'Create an account — only once', 'Войдите в аккаунт Microsoft с купленным Minecraft Java Edition.': 'Sign in with a Microsoft account that owns Minecraft Java Edition.', 'Войти через Microsoft': 'Sign in with Microsoft', 'Ник в игре': 'In-game nick', '3–16 символов: латиница, цифры, _': '3–16 chars: letters, digits, _', 'Продолжить': 'Continue', 'Работает': 'Running', 'Остановлена': 'Stopped', 'Копировать': 'Copy', 'Отмена': 'Cancel', 'Ок': 'OK', 'Сборка работает!': 'The pack works!', 'Игра дошла до главного меню за': 'The game reached the main menu in', 'Что пошло не так': 'What went wrong', 'Как починить': 'How to fix', 'Открыть настройки': 'Open settings', 'Подозрительные моды': 'Suspicious mods', 'Удалить': 'Delete', 'Открыть отчёт о крэше': 'Open crash report', 'Папка сборки': 'Pack folder', 'Переименовать': 'Rename', 'Дублировать': 'Duplicate', 'Моды и настройки': 'Mods & settings', 'Проверить сборку': 'Test pack', 'Открыть папку': 'Open folder', 'Удалить версию': 'Delete version', 'Новое название': 'New name', 'Удалить сборку?': 'Delete pack?', 'все её моды и миры будут удалены.': 'all its mods and worlds will be deleted.', 'Удалить версию?': 'Delete version?', 'Версия установлена': 'Version installed', 'Сборка создана': 'Pack created', 'Сборка скопирована': 'Pack copied', 'Установлено': 'Installed', 'Мод удалён. Запустите проверку снова.': 'Mod removed. Run the test again.', 'Скопировано': 'Copied', 'Ключ сохранён': 'Key saved', 'Откроется окно входа Microsoft…': 'Microsoft sign-in window opens…', 'Запускаем проверку — игра откроется и закроется сама': 'Starting test — the game opens and closes by itself' };
boot();
