'use strict';
/* MineCore: живые фоны. Рисуются на маленьком canvas (растягивается CSS), 30 FPS (20 в облегчённом режиме),
   полностью останавливаются, когда игра запущена или окно скрыто. */
(function () {
  const TAU = Math.PI * 2, rnd = Math.random, SC = {};

  /* ---- Северное сияние ---- */
  SC.aurora = {
    init(s, w, h) { s.stars = Array.from({ length: Math.round(w * h / 5000) }, () => ({ x: rnd() * w, y: rnd() * h * .75, r: rnd() * 1.1 + .4, p: rnd() * TAU, sp: .6 + rnd() * 1.6 })); },
    draw(c, w, h, t, dt, s) {
      const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#030913'); g.addColorStop(.6, '#07182a'); g.addColorStop(1, '#0b2a30');
      c.fillStyle = g; c.fillRect(0, 0, w, h);
      c.fillStyle = '#fff';
      for (const st of s.stars) { c.globalAlpha = .25 + .75 * Math.abs(Math.sin(t * st.sp + st.p)); c.fillRect(st.x, st.y, st.r, st.r); }
      c.globalAlpha = 1; c.globalCompositeOperation = 'lighter';
      [[.30, '46,230,166', .62, 1], [.38, '53,184,255', .5, .8], [.22, '138,92,255', .45, 1.3], [.46, '46,230,166', .35, .6]].forEach(([base, col, a, sp], i) => {
        const th = h * .34, y0 = h * base, gr = c.createLinearGradient(0, y0 - th * .35, 0, y0 + th);
        gr.addColorStop(0, `rgba(${col},0)`); gr.addColorStop(.4, `rgba(${col},${a})`); gr.addColorStop(1, `rgba(${col},0)`);
        c.fillStyle = gr; c.beginPath();
        const pts = [], stp = Math.max(6, w / 110);
        for (let x = 0; x <= w + stp; x += stp) { const k = x / w; pts.push([x, y0 + Math.sin(k * 6 + t * .7 * sp + i * 1.7) * h * .07 + Math.sin(k * 13 - t * 1.1 * sp + i) * h * .03 + Math.sin(k * 3 + t * .3 + i * 2) * h * .06]); }
        pts.forEach(([x, y], j) => j ? c.lineTo(x, y) : c.moveTo(x, y));
        for (let j = pts.length - 1; j >= 0; j--) { const [x, y] = pts[j]; c.lineTo(x, y + th * (.7 + .3 * Math.sin(x / w * 8 + t * .8 + i))); }
        c.closePath(); c.fill();
      });
      c.globalCompositeOperation = 'source-over';
      c.fillStyle = '#02070c'; c.beginPath(); c.moveTo(0, h);
      for (let x = 0; x <= w; x += 8) c.lineTo(x, h * .9 - Math.abs(Math.sin(x / w * 5 + 1)) * h * .07 - Math.sin(x / w * 17) * h * .012);
      c.lineTo(w, h); c.closePath(); c.fill();
    }
  };

  /* ---- Космос ---- */
  SC.space = {
    init(s, w, h) { s.L = [.02, .05, .1].map((sp, i) => ({ sp, a: Array.from({ length: Math.round(w * h / (i ? 4200 : 2400)) }, () => ({ x: rnd() * w, y: rnd() * h, r: .6 + i * .5 + rnd() * .5, p: rnd() * TAU })) })); s.m = []; s.n = 1.2; },
    draw(c, w, h, t, dt, s) {
      c.fillStyle = '#03040c'; c.fillRect(0, 0, w, h); c.globalCompositeOperation = 'lighter';
      [[.25, .3, .55, '91,75,255', .26, .06], [.78, .7, .6, '194,58,201', .2, .05], [.55, .12, .45, '31,107,255', .18, .07]].forEach(([x, y, r, col, a, sp], i) => {
        const cx = (x + Math.sin(t * sp + i) * .1) * w, cy = (y + Math.cos(t * sp * 1.3 + i) * .08) * h, rr = r * Math.max(w, h), g = c.createRadialGradient(cx, cy, 0, cx, cy, rr);
        g.addColorStop(0, `rgba(${col},${a})`); g.addColorStop(1, `rgba(${col},0)`); c.fillStyle = g; c.fillRect(0, 0, w, h);
      });
      c.globalCompositeOperation = 'source-over'; c.fillStyle = '#fff';
      for (const L of s.L) for (const st of L.a) { st.x -= L.sp * w * dt * .7; if (st.x < 0) st.x += w; c.globalAlpha = .35 + .65 * Math.abs(Math.sin(t * 1.3 + st.p)); c.fillRect(st.x, st.y, st.r, st.r); }
      c.globalAlpha = 1; s.n -= dt;
      if (s.n <= 0) { s.n = 1.8 + rnd() * 3.5; s.m.push({ x: w * (.2 + rnd() * .8), y: rnd() * h * .45, vx: -(w * .8 + rnd() * w * .3), vy: h * .4 + rnd() * h * .2, l: 0 }); }
      for (let i = s.m.length - 1; i >= 0; i--) {
        const m = s.m[i]; m.l += dt; m.x += m.vx * dt; m.y += m.vy * dt; const a = 1 - m.l / .9; if (a <= 0) { s.m.splice(i, 1); continue; }
        const tx = m.x - m.vx * .1, ty = m.y - m.vy * .1, g = c.createLinearGradient(m.x, m.y, tx, ty);
        g.addColorStop(0, `rgba(255,255,255,${a})`); g.addColorStop(1, 'rgba(255,255,255,0)'); c.strokeStyle = g; c.lineWidth = 1.6; c.beginPath(); c.moveTo(m.x, m.y); c.lineTo(tx, ty); c.stroke();
      }
    }
  };

  /* ---- Закат над морем ---- */
  SC.waves = {
    init() {},
    draw(c, w, h, t) {
      const hz = h * .52, g = c.createLinearGradient(0, 0, 0, hz);
      g.addColorStop(0, '#1a2b52'); g.addColorStop(.55, '#7a4a7a'); g.addColorStop(.85, '#e08a6a'); g.addColorStop(1, '#f7c88e'); c.fillStyle = g; c.fillRect(0, 0, w, hz + 1);
      const sg = c.createRadialGradient(w * .5, hz, 0, w * .5, hz, h * .4); sg.addColorStop(0, 'rgba(255,225,160,.95)'); sg.addColorStop(.15, 'rgba(255,190,120,.5)'); sg.addColorStop(1, 'rgba(255,150,100,0)'); c.fillStyle = sg; c.fillRect(0, 0, w, hz);
      const sea = c.createLinearGradient(0, hz, 0, h); sea.addColorStop(0, '#d98a70'); sea.addColorStop(.25, '#2a5a86'); sea.addColorStop(1, '#06172b'); c.fillStyle = sea; c.fillRect(0, hz, w, h - hz);
      c.fillStyle = 'rgba(255,225,170,.7)';
      for (let i = 0; i < 46; i++) { const k = i / 46, y = hz + 3 + k * (h - hz) * .6, ww = (6 + k * 60) * (.5 + .5 * Math.sin(t * 2 + i * 1.7)), x = w * .5 + Math.sin(t * .8 + i * 2.1) * (10 + k * 40); c.globalAlpha = (1 - k) * .55; c.fillRect(x - ww / 2, y, ww, 1 + k); }
      c.globalAlpha = 1;
      const cols = ['#2d6a9a', '#245b88', '#1c4a74', '#143a60', '#0d2b4c', '#071d38'];
      for (let i = 0; i < 6; i++) {
        const base = hz + (i + .6) * (h - hz) / 6.4, amp = h * (.008 + i * .006), f = 2.2 + i * .35, sp = (i % 2 ? 1 : -1) * (.5 + i * .12);
        c.fillStyle = cols[i]; c.globalAlpha = .93; c.beginPath(); c.moveTo(0, h);
        for (let x = 0; x <= w; x += 6) { const k = x / w * TAU; c.lineTo(x, base + Math.sin(k * f + t * sp + i * 2) * amp + Math.sin(k * f * 2.3 - t * sp * 1.4) * amp * .5); }
        c.lineTo(w, h); c.closePath(); c.fill();
        c.globalAlpha = .2; c.strokeStyle = '#fff'; c.lineWidth = 1; c.beginPath();
        for (let x = 0; x <= w; x += 6) { const k = x / w * TAU, y = base + Math.sin(k * f + t * sp + i * 2) * amp + Math.sin(k * f * 2.3 - t * sp * 1.4) * amp * .5; x ? c.lineTo(x, y) : c.moveTo(x, y); }
        c.stroke();
      }
      c.globalAlpha = 1;
    }
  };

  /* ---- Огонь и искры ---- */
  const mk = (w, h, first) => ({ x: rnd() * w, y: first ? rnd() * h : h + 8, vy: (22 + rnd() * 60) * h / 540, r: .8 + rnd() * 2.2, ph: rnd() * TAU, f: .6 + rnd() * 1.8 });
  SC.embers = {
    init(s, w, h) {
      s.p = Array.from({ length: Math.round(w * h / 5200) }, () => mk(w, h, true));
      const sp = document.createElement('canvas'); sp.width = sp.height = 32; const x = sp.getContext('2d'), g = x.createRadialGradient(16, 16, 0, 16, 16, 16);
      g.addColorStop(0, 'rgba(255,230,160,1)'); g.addColorStop(.3, 'rgba(255,140,50,.55)'); g.addColorStop(1, 'rgba(255,80,20,0)'); x.fillStyle = g; x.fillRect(0, 0, 32, 32); s.sp = sp;
    },
    draw(c, w, h, t, dt, s) {
      const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#080406'); g.addColorStop(.65, '#1d0b0a'); g.addColorStop(1, '#4a1408'); c.fillStyle = g; c.fillRect(0, 0, w, h);
      c.globalCompositeOperation = 'lighter';
      const pulse = .42 + .14 * Math.sin(t * 2.3) + .08 * Math.sin(t * 5.1), rg = c.createRadialGradient(w / 2, h * 1.05, 0, w / 2, h * 1.05, w * .75);
      rg.addColorStop(0, `rgba(255,110,30,${pulse})`); rg.addColorStop(1, 'rgba(255,60,10,0)'); c.fillStyle = rg; c.fillRect(0, 0, w, h);
      for (let i = 0; i < s.p.length; i++) {
        const p = s.p[i]; p.y -= p.vy * dt; p.x += Math.sin(t * p.f + p.ph) * 14 * dt;
        const a = Math.min(1, Math.max(0, p.y / h * 1.4));
        if (p.y < -10 || a <= .02) { s.p[i] = mk(w, h, false); continue; }
        const r = p.r * (2.6 + 1.4 * Math.sin(t * 6 + p.ph) * .3);
        c.globalAlpha = a * (.65 + .35 * Math.sin(t * 8 + p.ph)); c.drawImage(s.sp, p.x - r * 2, p.y - r * 2, r * 4, r * 4);
      }
      c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
    }
  };

  /* ---- Синтвейв ---- */
  SC.synth = {
    init(s, w, h) { s.st = Array.from({ length: 50 }, () => ({ x: rnd() * w, y: rnd() * h * .5, p: rnd() * TAU })); },
    draw(c, w, h, t, dt, s) {
      const hz = h * .56, g = c.createLinearGradient(0, 0, 0, hz); g.addColorStop(0, '#090218'); g.addColorStop(.65, '#3b0a5e'); g.addColorStop(1, '#ff4fa0'); c.fillStyle = g; c.fillRect(0, 0, w, hz + 1);
      c.fillStyle = '#fff'; for (const q of s.st) { c.globalAlpha = .2 + .8 * Math.abs(Math.sin(t * 1.4 + q.p)); c.fillRect(q.x, q.y, 1.2, 1.2); } c.globalAlpha = 1;
      const R = h * .21, cy = hz - R * .35, sg = c.createLinearGradient(0, cy - R, 0, cy + R); sg.addColorStop(0, '#ffe66d'); sg.addColorStop(.55, '#ff7b8a'); sg.addColorStop(1, '#ff2e93');
      c.save(); c.beginPath(); c.arc(w / 2, cy, R, 0, TAU); c.clip(); c.fillStyle = sg; c.fillRect(w / 2 - R, cy - R, R * 2, R * 2);
      c.fillStyle = 'rgba(58,10,94,.92)'; const gap = R * .22, off = (t * 6) % gap;
      for (let k = 0; k < 8; k++) { const y = cy + k * gap - off + R * .05; c.fillRect(w / 2 - R, y, R * 2, 1.5 + k * .9); }
      c.restore();
      const fg = c.createLinearGradient(0, hz, 0, h); fg.addColorStop(0, '#2a0a4a'); fg.addColorStop(.25, '#12062a'); fg.addColorStop(1, '#05010f'); c.fillStyle = fg; c.fillRect(0, hz, w, h - hz);
      c.lineCap = 'round';
      const N = 14, ph = (t * .55) % 1;
      for (let i = 0; i <= N; i++) { const z = (i + ph) / (N + 1), y = hz + (h - hz) * z * z; c.strokeStyle = `rgba(255,62,165,${.12 + .85 * z})`; c.lineWidth = .8 + z * 1.8; c.beginPath(); c.moveTo(0, y); c.lineTo(w, y); c.stroke(); }
      c.strokeStyle = 'rgba(122,107,255,.55)'; c.lineWidth = 1;
      for (let k = -18; k <= 18; k++) { c.beginPath(); c.moveTo(w / 2 + k * w * .012, hz); c.lineTo(w / 2 + k * w * .17, h); c.stroke(); }
      const hg = c.createLinearGradient(0, hz - 4, 0, hz + 10); hg.addColorStop(0, 'rgba(255,80,170,0)'); hg.addColorStop(.5, 'rgba(255,80,170,.65)'); hg.addColorStop(1, 'rgba(255,80,170,0)'); c.fillStyle = hg; c.fillRect(0, hz - 4, w, 14);
    }
  };

  /* ---- движок ---- */
  const E = { cv: null, ctx: null, sc: null, name: null, st: {}, raf: 0, last: 0, paused: false, low: false, w: 0, h: 0, t0: 0 };
  function frame(dt) { if (E.sc) E.sc.draw(E.ctx, E.w, E.h, (performance.now() - E.t0) / 1000, dt, E.st); }
  function size() {
    const k = E.low ? .35 : .5; E.w = Math.max(2, Math.ceil(innerWidth * k)); E.h = Math.max(2, Math.ceil(innerHeight * k)); E.cv.width = E.w; E.cv.height = E.h;
    if (E.sc) { if (E.sc.init) E.sc.init(E.st, E.w, E.h); frame(0); }
  }
  function loop(ts) { E.raf = requestAnimationFrame(loop); if (ts - E.last < 1000 / (E.low ? 20 : 30) - 3) return; const dt = Math.min(.1, (ts - E.last) / 1000); E.last = ts; frame(dt); }
  const run = () => { if (!E.raf && E.sc && !E.paused && !document.hidden) { E.last = 0; E.raf = requestAnimationFrame(loop); } };
  const halt = () => { cancelAnimationFrame(E.raf); E.raf = 0; };
  function mount() { E.cv = document.getElementById('fxc'); if (!E.cv) return false; E.ctx = E.cv.getContext('2d'); E.t0 = performance.now(); let rt; addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(() => E.sc && size(), 200); }); return true; }
  window.FX = {
    set(name) { if (name === E.name) return; E.name = name; halt(); if (!E.cv && !mount()) return; E.sc = name ? SC[name] : null; E.st = {}; E.cv.style.display = E.sc ? 'block' : 'none'; if (E.sc) { size(); run(); } },
    pause(p) { if (p === E.paused) return; E.paused = p; if (p) halt(); else run(); },
    quality(q) { const l = q === 'low'; if (l === E.low) return; E.low = l; if (E.sc) size(); }
  };
})();
