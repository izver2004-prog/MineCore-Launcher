const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('mc', {
  call: (c, ...a) => ipcRenderer.invoke(c, ...a),
  on: (c, f) => ipcRenderer.on(c, (_, d) => f(d))
});
