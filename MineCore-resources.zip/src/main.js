'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell, safeStorage, Menu } = require('electron');
const path = require('path'), fs = require('fs'), os = require('os'), crypto = require('crypto');
const { spawn, execFile } = require('child_process');
const { Readable } = require('stream'), { pipeline } = require('stream/promises');
const AdmZip = require('adm-zip');

const UA = 'MineCore/1.0 (wwwakizashi)';
let SECRETS = {}; try { SECRETS = require('./secrets.json'); } catch {}
if (!app.requestSingleInstanceLock()) app.quit();
app.setAppUserModelId('com.wwwakizashi.minecore');
process.on('uncaughtException', e => console.error(e));
process.on('unhandledRejection', e => console.error(e));

/* ---------- config ---------- */
let cfg, win;
const cfgPath = () => path.join(app.getPath('userData'), 'config.json');
function loadCfg() {
  const d = { root: path.join(app.getPath('appData'), '.minecore'), ram: 4096, lang: 'ru', theme: 'default', accent: '#2ecc9a', anim: true, jvm: '', javaPath: '', fullscreen: false, hideOnPlay: true, g1: true, cfKey: '', account: null, last: null };
  try { cfg = { ...d, ...JSON.parse(fs.readFileSync(cfgPath(), 'utf8')) }; } catch { cfg = d; }
}
const saveCfg = () => { fs.mkdirSync(path.dirname(cfgPath()), { recursive: true }); fs.writeFileSync(cfgPath(), JSON.stringify(cfg, null, 2)); };
const L = (ru, en) => (cfg && cfg.lang === 'en' ? en : ru);
const cfKey = () => cfg.cfKey || SECRETS.cfKey || '';
const pub = () => ({ ...cfg, cfKey: '', hasCfKey: !!cfKey(), account: cfg.account && { type: cfg.account.type, name: cfg.account.name, uuid: cfg.account.uuid } });
const P = () => { const r = cfg.root; return { root: r, versions: path.join(r, 'versions'), libs: path.join(r, 'libraries'), assets: path.join(r, 'assets'), runtime: path.join(r, 'runtime'), instances: path.join(r, 'instances'), vanilla: path.join(r, 'vanilla'), logs: path.join(r, 'logs'), cache: path.join(r, 'cache') }; };
function ensureDirs() { const p = P(); for (const k of Object.keys(p)) fs.mkdirSync(p[k], { recursive: true }); }
const enc = s => { try { return safeStorage.isEncryptionAvailable() ? 'e:' + safeStorage.encryptString(s).toString('base64') : 'p:' + s; } catch { return 'p:' + s; } };
const dec = s => s.startsWith('e:') ? safeStorage.decryptString(Buffer.from(s.slice(2), 'base64')) : s.slice(2);

/* ---------- events / tasks ---------- */
const send = (ch, d) => { if (win && !win.isDestroyed()) win.webContents.send(ch, d); };
let tseq = 0;
function Task(label) {
  const id = ++tseq; let last = 0;
  const t = { id,
    set(pct, sub) { const n = Date.now(); if (n - last < 120 && pct < 100) return; last = n; send('task', { id, label, pct: Math.min(100, Math.round(pct)), sub }); },
    done() { send('task', { id, done: true }); } };
  last = 0; t.set(0); return t;
}

/* ---------- net ---------- */
async function getJSON(url, opt = {}) {
  const r = await fetch(url, { ...opt, headers: { 'User-Agent': UA, ...(opt.headers || {}) } });
  if (!r.ok) throw new Error(`HTTP ${r.status} (${url})`);
  return r.json();
}
const sha1f = f => crypto.createHash('sha1').update(fs.readFileSync(f)).digest('hex');
async function download(url, dest, sha1) {
  if (fs.existsSync(dest) && fs.statSync(dest).size > 0) return;
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  let err;
  for (let i = 0; i < 3; i++) {
    try {
      const r = await fetch(url, { headers: { 'User-Agent': UA } });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const tmp = dest + '.part';
      await pipeline(Readable.fromWeb(r.body), fs.createWriteStream(tmp));
      if (sha1 && sha1f(tmp) !== sha1) throw new Error('sha1 mismatch');
      fs.renameSync(tmp, dest); return;
    } catch (e) { err = e; }
  }
  throw new Error(L('Не удалось скачать ', 'Download failed: ') + url + ' — ' + err.message);
}
async function pool(items, n, fn) {
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => { while (i < items.length) await fn(items[i++]); }));
}

/* ---------- version json ---------- */
let manCache;
async function manifest() {
  if (manCache) return manCache;
  const f = path.join(P().cache, 'manifest.json');
  try { manCache = await getJSON('https://launchermeta.mojang.com/mc/game/version_manifest_v2.json'); fs.mkdirSync(P().cache, { recursive: true }); fs.writeFileSync(f, JSON.stringify(manCache)); }
  catch (e) { if (fs.existsSync(f)) manCache = JSON.parse(fs.readFileSync(f, 'utf8')); else throw e; }
  return manCache;
}
const readVer = id => JSON.parse(fs.readFileSync(path.join(P().versions, id, id + '.json'), 'utf8'));
const libKey = n => { const [g, a, , c] = n.split(':'); return g + ':' + a + ':' + (c || ''); };
function loadVersion(id) {
  const c = readVer(id);
  if (!c.inheritsFrom) { c._jarId = c.jar || id; return c; }
  const p = loadVersion(c.inheritsFrom);
  const m = { ...p, ...c };
  const seen = new Set();
  m.libraries = [...(c.libraries || []), ...(p.libraries || [])].filter(l => { const k = libKey(l.name); if (seen.has(k)) return false; seen.add(k); return true; });
  if (c.arguments && p.arguments) m.arguments = { game: [...(p.arguments.game || []), ...(c.arguments.game || [])], jvm: [...(p.arguments.jvm || []), ...(c.arguments.jvm || [])] };
  m._jarId = c.jar || p._jarId; m.id = c.id; m.downloads = p.downloads; m.assetIndex = c.assetIndex || p.assetIndex; m.javaVersion = c.javaVersion || p.javaVersion;
  return m;
}
const osVer = os.release();
function allowed(rules) {
  if (!rules) return true;
  let ok = false;
  for (const r of rules) {
    let m = true;
    if (r.os) {
      if (r.os.name && r.os.name !== 'windows') m = false;
      if (r.os.arch && !(r.os.arch === 'x86' ? process.arch === 'ia32' : process.arch === r.os.arch)) m = false;
      if (r.os.version && !new RegExp(r.os.version).test(osVer)) m = false;
    }
    if (r.features) m = false;
    if (m) ok = r.action === 'allow';
  }
  return ok;
}
function mvn(n) { let ext = 'jar'; if (n.includes('@')) [n, ext] = n.split('@'); const [g, a, v, c] = n.split(':'); return `${g.replace(/\./g, '/')}/${a}/${v}/${a}-${v}${c ? '-' + c : ''}.${ext}`; }
function libEntries(v) {
  const out = [];
  for (const l of v.libraries) {
    if (!allowed(l.rules)) continue;
    const d = l.downloads; let art = d && d.artifact;
    if (!art && !l.natives) { const p = mvn(l.name); art = { path: p, url: (l.url || 'https://libraries.minecraft.net/') + p, soft: true }; }
    if (art) out.push({ name: l.name, path: art.path || mvn(l.name), url: art.url, sha1: art.sha1, soft: art.soft, native: /natives-windows/.test(l.name) });
    if (l.natives && l.natives.windows) {
      const k = l.natives.windows.replace('${arch}', '64'); const c = d && d.classifiers && d.classifiers[k];
      if (c) out.push({ name: l.name + ':' + k, path: c.path, url: c.url, sha1: c.sha1, native: true, nativeOnly: true });
    }
  }
  return out;
}
function extractNatives(entries, dir) {
  fs.mkdirSync(dir, { recursive: true });
  for (const e of entries.filter(x => x.native)) {
    const f = path.join(P().libs, e.path); if (!fs.existsSync(f)) continue;
    try { for (const z of new AdmZip(f).getEntries()) { if (z.isDirectory || !/\.dll$/i.test(z.entryName) || z.entryName.startsWith('META-INF')) continue; const d = path.join(dir, path.basename(z.entryName)); if (!fs.existsSync(d)) fs.writeFileSync(d, z.getData()); } } catch {}
  }
}

/* ---------- install ---------- */
async function ensureFiles(id, t) {
  const v = loadVersion(id), p = P();
  const jar = path.join(p.versions, v._jarId, v._jarId + '.jar');
  if (!fs.existsSync(jar)) { const c = v.downloads && v.downloads.client; if (!c) throw new Error('client.jar not found'); t && t.set(2, 'Minecraft'); await download(c.url, jar, c.sha1); }
  const libs = libEntries(v).filter(l => l.url); let n = 0;
  await pool(libs, 8, async l => { try { await download(l.url, path.join(p.libs, l.path), l.sha1); } catch (e) { if (!l.soft) throw e; } t && t.set(5 + (++n / libs.length) * 35, L('Библиотеки', 'Libraries')); });
  const ai = v.assetIndex, idx = path.join(p.assets, 'indexes', ai.id + '.json');
  if (!fs.existsSync(idx)) await download(ai.url, idx, ai.sha1);
  const hashes = [...new Set(Object.values(JSON.parse(fs.readFileSync(idx, 'utf8')).objects).map(o => o.hash))];
  let k = 0;
  await pool(hashes, 16, async h => { const s = h.slice(0, 2); await download(`https://resources.download.minecraft.net/${s}/${h}`, path.join(p.assets, 'objects', s, h), h); if (++k % 20 === 0) t && t.set(40 + (k / hashes.length) * 55, L('Ресурсы игры', 'Game assets')); });
}
async function installVanilla(id, t) {
  const jf = path.join(P().versions, id, id + '.json');
  if (!fs.existsSync(jf)) {
    const v = (await manifest()).versions.find(x => x.id === id); if (!v) throw new Error(L('Версия не найдена: ', 'Version not found: ') + id);
    const j = await getJSON(v.url); fs.mkdirSync(path.dirname(jf), { recursive: true }); fs.writeFileSync(jf, JSON.stringify(j));
  }
  await ensureFiles(id, t);
}
const RT_URL = 'https://launchermeta.mojang.com/v1/products/java-runtime/2ec0cc96c44e5a76b9c8b7c39df7210883d12871/all.json';
const rtArch = () => process.arch === 'arm64' ? 'windows-arm64' : process.arch === 'ia32' ? 'windows-x86' : 'windows-x64';
async function ensureJava(comp, t) {
  const dir = path.join(P().runtime, comp), exe = path.join(dir, 'bin', 'java.exe');
  if (fs.existsSync(path.join(dir, '.ok')) && fs.existsSync(exe)) return exe;
  const all = await getJSON(RT_URL); const e = all[rtArch()] && all[rtArch()][comp] && all[rtArch()][comp][0];
  if (!e) throw new Error(L('Java недоступна для этой системы: ', 'Java unavailable: ') + comp);
  const man = await getJSON(e.manifest.url);
  const files = Object.entries(man.files).filter(([, f]) => f.type === 'file'); let n = 0;
  await pool(files, 8, async ([rel, f]) => { await download(f.downloads.raw.url, path.join(dir, rel), f.downloads.raw.sha1); t && t.set((++n / files.length) * 100, 'Java'); });
  fs.writeFileSync(path.join(dir, '.ok'), e.version.name);
  return exe;
}
async function installLoader(mc, loader, lv, t) {
  await installVanilla(mc, t);
  if (loader === 'vanilla') return mc;
  if (loader === 'fabric' || loader === 'quilt') {
    const b = loader === 'fabric' ? 'https://meta.fabricmc.net/v2' : 'https://meta.quiltmc.org/v3';
    const j = await getJSON(`${b}/versions/loader/${mc}/${lv}/profile/json`);
    const f = path.join(P().versions, j.id, j.id + '.json'); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, JSON.stringify(j));
    await ensureFiles(j.id, t); return j.id;
  }
  const short = loader === 'forge' ? lv.split('-')[1] || lv : lv;
  const find = () => fs.readdirSync(P().versions).find(d => d.includes(short) && fs.existsSync(path.join(P().versions, d, d + '.json')) && (loader === 'forge' ? /forge/i.test(d) : /neoforge/i.test(d)));
  let vid = find();
  if (!vid) {
    const url = loader === 'forge' ? `https://maven.minecraftforge.net/net/minecraftforge/forge/${lv}/forge-${lv}-installer.jar` : `https://maven.neoforged.net/releases/net/neoforged/neoforge/${lv}/neoforge-${lv}-installer.jar`;
    const inst = path.join(P().cache, `${loader}-${lv}-installer.jar`);
    t && t.set(55, L('Скачивание установщика ', 'Installer ') + loader); await download(url, inst);
    const java = await ensureJava((loadVersion(mc).javaVersion || {}).component || 'jre-legacy', t);
    const lp = path.join(P().root, 'launcher_profiles.json'); if (!fs.existsSync(lp)) fs.writeFileSync(lp, '{"profiles":{},"version":3}');
    t && t.set(70, L('Установка ', 'Installing ') + loader + '…');
    await new Promise((res, rej) => {
      let out = ''; const pr = spawn(java, ['-jar', inst, '--installClient', P().root], { windowsHide: true, cwd: P().root });
      pr.stdout.on('data', d => out += d); pr.stderr.on('data', d => out += d);
      pr.on('error', rej); pr.on('close', c => c === 0 ? res() : rej(new Error(L('Ошибка установщика ', 'Installer error ') + loader + ':\n' + out.split('\n').slice(-12).join('\n'))));
    });
    vid = find(); if (!vid) throw new Error(L('Установщик не создал версию', 'Installer produced no version'));
  }
  await ensureFiles(vid, t); return vid;
}

/* ---------- accounts ---------- */
const offUuid = n => { const h = crypto.createHash('md5').update('OfflinePlayer:' + n).digest(); h[6] = (h[6] & 0x0f) | 0x30; h[8] = (h[8] & 0x3f) | 0x80; return h.toString('hex'); };
const CID = '00000000402b5328', REDIR = 'https://login.live.com/oauth20_desktop.srf';
async function form(url, o) { const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(o) }); const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error_description || j.error || 'HTTP ' + r.status); return j; }
async function pj(url, body) { const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(body) }); const j = await r.json().catch(() => ({})); if (!r.ok) { const e = new Error(j.errorMessage || j.error || 'HTTP ' + r.status); e.xerr = j.XErr; throw e; } return j; }
function msCode() {
  return new Promise((res, rej) => {
    const w = new BrowserWindow({ width: 520, height: 680, parent: win, modal: true, autoHideMenuBar: true, title: 'Microsoft', webPreferences: { partition: 'ms-' + Date.now() } });
    let done = false;
    const chk = u => { if (done || !u.startsWith(REDIR)) return; done = true; const q = new URL(u).searchParams; w.destroy(); q.get('code') ? res(q.get('code')) : rej(new Error(q.get('error_description') || 'Cancelled')); };
    w.webContents.on('will-redirect', (e, u) => { if (u.startsWith(REDIR)) { e.preventDefault(); chk(u); } });
    w.webContents.on('did-navigate', (e, u) => chk(u));
    w.on('closed', () => { if (!done) { done = true; rej(new Error(L('Вход отменён', 'Sign-in cancelled'))); } });
    w.loadURL(`https://login.live.com/oauth20_authorize.srf?client_id=${CID}&response_type=code&redirect_uri=${encodeURIComponent(REDIR)}&scope=${encodeURIComponent('service::user.auth.xboxlive.com::MBI_SSL')}&prompt=select_account`);
  });
}
async function msChain(tok) {
  try {
    const xbl = await pj('https://user.auth.xboxlive.com/user/authenticate', { Properties: { AuthMethod: 'RPS', SiteName: 'user.auth.xboxlive.com', RpsTicket: tok.access_token }, RelyingParty: 'http://auth.xboxlive.com', TokenType: 'JWT' });
    const xs = await pj('https://xsts.auth.xboxlive.com/xsts/authorize', { Properties: { SandboxId: 'RETAIL', UserTokens: [xbl.Token] }, RelyingParty: 'rp://api.minecraftservices.com/', TokenType: 'JWT' });
    const mcT = await pj('https://api.minecraftservices.com/authentication/login_with_xbox', { identityToken: `XBL3.0 x=${xs.DisplayClaims.xui[0].uhs};${xs.Token}` });
    const pr = await fetch('https://api.minecraftservices.com/minecraft/profile', { headers: { Authorization: 'Bearer ' + mcT.access_token } });
    if (!pr.ok) throw new Error(L('На этом аккаунте Microsoft нет купленного Minecraft Java Edition', 'This Microsoft account does not own Minecraft Java Edition'));
    const prof = await pr.json();
    return { type: 'ms', name: prof.name, uuid: prof.id, token: enc(mcT.access_token), exp: Date.now() + mcT.expires_in * 1000, refresh: enc(tok.refresh_token) };
  } catch (e) {
    if (e.xerr === 2148916233) throw new Error(L('У аккаунта нет профиля Xbox — создайте его на xbox.com', 'No Xbox profile on this account'));
    if (e.xerr === 2148916238) throw new Error(L('Детский аккаунт: добавьте его в семью Microsoft', 'Child account: add it to a Microsoft family'));
    throw e;
  }
}
async function getAccount() {
  const a = cfg.account; if (!a) throw new Error(L('Сначала создайте аккаунт', 'Create an account first'));
  if (a.type === 'ms' && Date.now() > a.exp - 60000) {
    const tok = await form('https://login.live.com/oauth20_token.srf', { client_id: CID, refresh_token: dec(a.refresh), grant_type: 'refresh_token', redirect_uri: REDIR, scope: 'service::user.auth.xboxlive.com::MBI_SSL' });
    cfg.account = await msChain(tok); saveCfg();
  }
  return cfg.account;
}

/* ---------- instances ---------- */
const safeName = n => String(n || '').replace(/[<>:"/\\|?*\x00-\x1f]/g, '').trim().slice(0, 40);
const instDir = n => path.join(P().instances, n);
const readInst = n => JSON.parse(fs.readFileSync(path.join(instDir(n), 'instance.json'), 'utf8'));
const writeInst = (n, o) => fs.writeFileSync(path.join(instDir(n), 'instance.json'), JSON.stringify(o, null, 2));
const modFiles = n => { try { return fs.readdirSync(path.join(instDir(n), 'mods')).filter(f => /\.jar(\.disabled)?$/i.test(f)); } catch { return []; } };
function listInsts() {
  try {
    return fs.readdirSync(P().instances, { withFileTypes: true }).filter(d => d.isDirectory() && fs.existsSync(path.join(P().instances, d.name, 'instance.json')))
      .map(d => { const i = readInst(d.name); i.name = d.name; i.modCount = modFiles(d.name).filter(f => !f.endsWith('.disabled')).length; return i; })
      .sort((a, b) => (b.lastPlayed || b.created || 0) - (a.lastPlayed || a.created || 0));
  } catch { return []; }
}
function jarInfo(file) {
  try {
    const z = new AdmZip(file); let id = null, kind = null;
    const fj = z.getEntry('fabric.mod.json'), qj = z.getEntry('quilt.mod.json');
    if (fj || qj) { kind = qj ? 'quilt' : 'fabric'; try { id = JSON.parse(z.readAsText(fj || qj).replace(/^\uFEFF/, '')).id || (JSON.parse(z.readAsText(qj)).quilt_loader || {}).id; } catch {} }
    const nt = z.getEntry('META-INF/neoforge.mods.toml'), ft = z.getEntry('META-INF/mods.toml'), mi = z.getEntry('mcmod.info');
    if (nt || ft || mi) { const e = nt || ft; kind = kind ? kind : (nt ? 'neoforge' : 'forge'); if (e) { const m = z.readAsText(e).match(/modId\s*=\s*["']([^"']+)/); if (m) id = id || m[1]; } }
    return { kind, id };
  } catch { return { kind: null, id: null }; }
}
function precheck(inst) {
  const w = [], tot = os.totalmem() / 1048576, free = os.freemem() / 1048576, ram = inst.ram || cfg.ram, files = modFiles(inst.name).filter(f => !f.endsWith('.disabled'));
  if (ram > tot * 0.75) w.push(L(`Выделено ${ram} МБ из ${Math.round(tot)} МБ ОЗУ — системе может не хватить памяти. Уменьшите до ${Math.floor(tot * 0.5 / 512) * 512} МБ в настройках.`, `${ram} MB allocated of ${Math.round(tot)} MB RAM — the system may run out of memory. Lower it in Settings.`));
  const need = 2048 + files.length * 40;
  if (files.length && ram < need) w.push(L(`Для ${files.length} модов лучше минимум ${need} МБ ОЗУ, сейчас ${ram} МБ.`, `${files.length} mods need about ${need} MB RAM, you have ${ram} MB.`));
  if (free < Math.min(ram, 3072) * 0.6) w.push(L('Сейчас мало свободной ОЗУ — закройте браузер и другие программы.', 'Free RAM is low — close other programs.'));
  const ids = {}, ok = { fabric: ['fabric', 'quilt'], quilt: ['quilt', 'fabric'], forge: ['forge'], neoforge: ['neoforge', 'forge'] }[inst.loader] || [];
  for (const f of files) {
    const i = jarInfo(path.join(instDir(inst.name), 'mods', f));
    if (inst.loader !== 'vanilla' && i.kind && !ok.includes(i.kind)) w.push(L(`Мод «${f}» сделан для ${i.kind}, а сборка на ${inst.loader}. Удалите его.`, `Mod "${f}" is for ${i.kind}, but the pack uses ${inst.loader}. Remove it.`));
    if (i.id) { if (ids[i.id]) w.push(L(`Дубликат мода «${i.id}»: ${ids[i.id]} и ${f}. Оставьте один.`, `Duplicate mod "${i.id}": ${ids[i.id]} and ${f}. Keep one.`)); else ids[i.id] = f; }
  }
  return w;
}

/* ---------- mods ---------- */
const MR = 'https://api.modrinth.com/v2', CF = 'https://api.curseforge.com/v1', CFL = { forge: 1, fabric: 4, quilt: 5, neoforge: 6 };
const lq = a => encodeURIComponent(JSON.stringify(a));
const mrLoaders = l => l === 'quilt' ? ['quilt', 'fabric'] : [l];
const mrGet = p => getJSON(MR + p);
const cfGet = p => { if (!cfKey()) throw new Error(L('Нужен ключ CurseForge: Настройки → Java и лаунчер (бесплатно на console.curseforge.com)', 'CurseForge key needed: Settings → Java & launcher (free at console.curseforge.com)')); return getJSON(CF + p, { headers: { 'x-api-key': cfKey(), Accept: 'application/json' } }); };
async function latestFor(src, pid, inst) {
  if (src === 'modrinth') { const r = await mrGet(`/project/${pid}/version?game_versions=${lq([inst.mc])}&loaders=${lq(mrLoaders(inst.loader))}`); return r[0] && r[0].id; }
  const r = await cfGet(`/mods/${pid}/files?gameVersion=${inst.mc}&modLoaderType=${CFL[inst.loader]}&pageSize=1`); return r.data[0] && String(r.data[0].id);
}
async function installMod(name, src, pid, vid, info, depth, done) {
  let inst = readInst(name); const dir = path.join(instDir(name), 'mods'); fs.mkdirSync(dir, { recursive: true });
  let file, url, deps = [], ver = '';
  if (src === 'modrinth') {
    const v = await mrGet('/version/' + vid), f = v.files.find(x => x.primary) || v.files[0];
    file = f.filename; url = f.url; ver = v.version_number;
    deps = v.dependencies.filter(d => d.dependency_type === 'required' && d.project_id).map(d => ({ pid: d.project_id, vid: d.version_id }));
    if (!info.title) { const p = await mrGet('/project/' + pid); info = { title: p.title, icon: p.icon_url }; }
  } else {
    const f = (await cfGet(`/mods/${pid}/files/${vid}`)).data; file = f.fileName; ver = f.displayName;
    url = f.downloadUrl || `https://edge.forgecdn.net/files/${Math.floor(f.id / 1000)}/${f.id % 1000}/${encodeURIComponent(f.fileName)}`;
    deps = (f.dependencies || []).filter(d => d.relationType === 3).map(d => ({ pid: String(d.modId) }));
    if (!info.title) { const m = (await cfGet('/mods/' + pid)).data; info = { title: m.name, icon: m.logo && m.logo.thumbnailUrl }; }
  }
  await download(url, path.join(dir, file));
  inst = readInst(name);
  for (const o of inst.mods.filter(m => m.pid === pid && m.src === src && m.file !== file)) { try { fs.unlinkSync(path.join(dir, o.file)); } catch {} }
  inst.mods = inst.mods.filter(m => !(m.pid === pid && m.src === src));
  inst.mods.push({ file, src, pid, vid, name: info.title, icon: info.icon, ver }); writeInst(name, inst);
  done.push(info.title + (depth ? L(' (зависимость)', ' (dependency)') : ''));
  if (depth < 3) for (const d of deps) {
    if (readInst(name).mods.some(m => m.pid === d.pid && m.src === src)) continue;
    try { const v = d.vid || await latestFor(src, d.pid, inst); if (v) await installMod(name, src, d.pid, v, {}, depth + 1, done); } catch (e) { console.error(e); }
  }
}

/* ---------- running games ---------- */
const games = new Map(), finished = new Map();
const MARK = /Sound engine started|OpenAL initialized|Created: \d+x\d+.*atlas|SoundSystem started|Narrator library/i;
const killTree = g => { g.stopped = true; try { execFile('taskkill', ['/pid', String(g.proc.pid), '/t', '/f'], { windowsHide: true }, () => {}); } catch { try { g.proc.kill(); } catch {} } };
function analyze(g, code, inst) {
  const lines = g.logs.slice(-2500), txt = lines.join('\n'), R = [];
  const errTxt = lines.filter(l => /error|exception|caused by|fail|mixin|require|missing|crash/i.test(l)).join('\n');
  const suspects = inst ? modFiles(inst.name).filter(f => errTxt.includes(f.replace(/\.disabled$/, ''))) : [];
  const block = re => { const i = lines.findIndex(l => re.test(l)); return i < 0 ? '' : lines.slice(i, i + 12).map(s => s.replace(/^\[[^\]]*\]\s*(\[[^\]]*\]:?\s*)?/, '').trim()).join('\n'); };
  const add = (title, text, fixes, extra = {}) => R.push({ title, text, fixes, ...extra });
  let m;
  if (/UnsupportedClassVersionError/.test(txt)) { m = txt.match(/class file version (\d+)/); const j = m ? +m[1] - 44 : '?';
    add(L('Не подходит версия Java', 'Wrong Java version'), L(`Игре или одному из модов нужна Java ${j}, а запущена более старая.`, `The game or a mod needs Java ${j}, but an older one is running.`),
      [L(`Настройки → Java и лаунчер → скачайте Java ${j}`, `Settings → Java & launcher → install Java ${j}`), L('Уберите свой путь к Java в настройках — лаунчер подберёт нужную сам', 'Clear the custom Java path — the launcher picks the right one'), L(`Если Java ${j} не подходит для этой версии игры — удалите мод, который её требует`, 'If this Java does not fit the game version, remove the mod that needs it')], { hint: 'java' }); }
  if (/OutOfMemoryError/.test(txt)) add(L('Не хватило оперативной памяти', 'Out of memory'), L('Игра израсходовала всю выделенную ОЗУ.', 'The game used all allocated RAM.'), [L('Настройки → Игра → увеличьте ОЗУ (для сборок с модами 6–8 ГБ)', 'Settings → Game → raise RAM (6–8 GB for modpacks)'), L('Закройте браузер и другие тяжёлые программы', 'Close the browser and heavy apps'), L('Уберите самые тяжёлые моды или шейдеры', 'Remove heavy mods or shaders')], { hint: 'ram' });
  if (/Could not reserve enough space|Invalid maximum heap size|Error occurred during initialization of VM/.test(txt)) add(L('Слишком много памяти выделено', 'Too much RAM allocated'), L('Система не смогла выдать столько ОЗУ.', 'The system could not provide that much RAM.'), [L('Настройки → Игра → уменьшите ОЗУ (не больше половины от всей памяти)', 'Settings → Game → lower RAM (max half of total)')], { hint: 'ram' });
  if (/Incompatible mod set|Mod resolution failed|Could not find required mod|requires (?:version|any version)/i.test(txt)) {
    const b = block(/Incompatible mod set|Mod resolution failed|Could not find required mod|requires (?:version|any)/i);
    add(L('Не хватает мода или версии не совпадают', 'Missing mod or version mismatch'), L('Один из модов требует другой мод (или другую его версию).', 'A mod requires another mod (or another version of it).'),
      [L('Прочитайте подробности ниже: там написано, какой мод нужен', 'See details below for the required mod'), L('Установите недостающий мод во вкладке «Найти моды» (часто это Fabric API)', 'Install the missing mod in "Find mods" (often Fabric API)'), L('Или удалите мод, который его требует', 'Or remove the mod that needs it')], { details: b }); }
  if (/Missing or unsupported mandatory dependencies|Mod File .* needs to be made available/.test(txt)) add(L('Не хватает зависимостей мода (Forge)', 'Missing mod dependencies (Forge)'), L('Какому-то моду нужен другой мод или более новая версия Forge.', 'A mod needs another mod or a newer Forge.'), [L('Подробности ниже: «Mod ID … Requested by …»', 'See details below'), L('Установите недостающий мод или удалите тот, что его требует', 'Install the missing mod or remove the one requiring it')], { details: block(/Missing or unsupported mandatory dependencies/) });
  if (/Duplicate mods? found|Found duplicate mods|duplicate (?:ID|mod)/i.test(txt)) add(L('Один и тот же мод установлен дважды', 'Duplicate mods'), L('В папке модов лежит несколько версий одного мода.', 'Several versions of the same mod are in the mods folder.'), [L('Откройте «Установленные моды» и удалите лишнюю копию', 'Open "Installed mods" and delete the extra copy')], { details: block(/uplicate/) });
  if (/Mixin (?:apply|transformation).*failed|MixinApplyError|InvalidMixinException|Critical injection failure|Mixin.*Error/i.test(txt)) { m = txt.match(/mod ([\w.-]+) failed|\[([\w.-]+?)\.mixins?\.json/); add(L('Конфликт модов (Mixin)', 'Mod conflict (Mixin)'), L(`Моды изменяют один и тот же код игры и мешают друг другу${m ? ' (виновник: ' + (m[1] || m[2]) + ')' : ''}.`, 'Mods patch the same game code and conflict.'), [L('Удалите или обновите мод, который вы добавили последним', 'Remove or update the mod you added last'), L('Если указан мод ниже — удалите его и попробуйте снова', 'If a mod is listed below, remove it and retry')]); }
  if (/NoSuchMethodError|NoSuchFieldError|NoClassDefFoundError|ClassNotFoundException|AbstractMethodError|IncompatibleClassChangeError/.test(txt)) add(L('Мод несовместим с версией игры или другим модом', 'Mod is incompatible'), L('Мод обращается к коду, которого нет в этой версии игры или в другом моде.', 'A mod calls code that does not exist here.'), [L('Проверьте, что все моды для той же версии игры и того же загрузчика', 'Make sure all mods match the game version and loader'), L('Обновите мод до последней версии или удалите его', 'Update or remove the mod'), L('Часто виноват мод, добавленный последним', 'Usually the last added mod is the cause')]);
  if (/InvalidModFileException|Invalid mod file|Missing mods\.toml|not a valid mod|Mod file .* is not/i.test(txt)) add(L('Файл не является модом для этого загрузчика', 'Not a valid mod for this loader'), L('В папке модов лежит файл, который не подходит (например, мод для Fabric в сборке Forge).', 'A file in mods is invalid for this loader.'), [L('Удалите указанный файл из модов', 'Remove the listed file')], { details: block(/InvalidModFileException|Invalid mod file|Missing mods\.toml/) });
  if (/GLFW error|Pixel format not accepted|org\.lwjgl\.LWJGLException|Failed to create window|WGL/i.test(txt)) add(L('Проблема с видеокартой', 'Graphics problem'), L('Игра не смогла создать окно OpenGL.', 'The game could not create an OpenGL window.'), [L('Обновите драйвер видеокарты (NVIDIA / AMD / Intel)', 'Update your GPU driver'), L('На ноутбуке запустите лаунчер на дискретной видеокарте', 'On laptops, run on the discrete GPU')]);
  if (!R.length && code !== 0) add(L('Игра закрылась с ошибкой', 'The game exited with an error'), L(`Код выхода: ${code}. Точная причина не определена.`, `Exit code: ${code}. The exact cause is unknown.`), [L('Откройте журнал ниже и найдите последние строки с ERROR', 'Check the log below for ERROR lines'), L('Попробуйте отключить недавно добавленные моды', 'Try disabling recently added mods'), L('Проверьте сборку ещё раз после изменений', 'Re-test after changes')]);
  const cm = txt.match(/Crash report saved to:?\s*(?:#@!@#\s*)?(.+?\.txt)/);
  return { items: R, suspects, crash: cm ? cm[1].trim() : null };
}
async function launch({ kind, id, test }) {
  const key = kind + ':' + id;
  if (games.has(key)) throw new Error(L('Уже запущено', 'Already running'));
  const t = Task(test ? L('Проверка: ', 'Testing: ') + id : L('Запуск: ', 'Launching: ') + id);
  let g;
  try {
    const p = P(); let verId, gameDir, ram = cfg.ram, inst = null, warns = [];
    const acc = await getAccount();
    if (kind === 'inst') {
      inst = readInst(id); verId = inst.versionId; gameDir = instDir(id); ram = inst.ram || cfg.ram;
      if (!fs.existsSync(path.join(p.versions, verId, verId + '.json'))) inst.versionId = verId = await installLoader(inst.mc, inst.loader, inst.loaderVer, t);
      else await ensureFiles(verId, t);
      if (test) warns = precheck(inst);
    } else { verId = id; gameDir = path.join(p.vanilla, id); fs.mkdirSync(gameDir, { recursive: true }); await installVanilla(id, t); }
    const v = loadVersion(verId);
    const java = cfg.javaPath && fs.existsSync(cfg.javaPath) ? cfg.javaPath : await ensureJava((v.javaVersion || {}).component || 'jre-legacy', t);
    t.set(97, L('Подготовка', 'Preparing'));
    const ents = libEntries(v), natives = path.join(p.versions, verId, 'natives'); extractNatives(ents, natives);
    const jar = path.join(p.versions, v._jarId, v._jarId + '.jar');
    const cp = [...new Set([...ents.filter(e => !e.nativeOnly).map(e => path.join(p.libs, e.path)).filter(f => fs.existsSync(f)), jar])].join(';');
    let gameAssets = p.assets;
    const idxJ = JSON.parse(fs.readFileSync(path.join(p.assets, 'indexes', v.assetIndex.id + '.json'), 'utf8'));
    if (idxJ.virtual || idxJ.map_to_resources) {
      const vd = idxJ.map_to_resources ? path.join(gameDir, 'resources') : path.join(p.assets, 'virtual', 'legacy');
      for (const [n, o] of Object.entries(idxJ.objects)) { const d = path.join(vd, n); if (!fs.existsSync(d)) { fs.mkdirSync(path.dirname(d), { recursive: true }); fs.copyFileSync(path.join(p.assets, 'objects', o.hash.slice(0, 2), o.hash), d); } }
      gameAssets = vd;
    }
    const vars = { auth_player_name: acc.name, version_name: v.id, game_directory: gameDir, assets_root: p.assets, assets_index_name: v.assetIndex.id, auth_uuid: acc.uuid, auth_access_token: acc.type === 'ms' ? dec(acc.token) : '0', clientid: '', auth_xuid: '', user_type: acc.type === 'ms' ? 'msa' : 'legacy', version_type: v.type || 'release', user_properties: '{}', natives_directory: natives, launcher_name: 'MineCore', launcher_version: app.getVersion(), classpath: cp, library_directory: p.libs, classpath_separator: ';', game_assets: gameAssets, auth_session: 'token:' + (acc.type === 'ms' ? dec(acc.token) : '0') + ':' + acc.uuid, profile_name: acc.name };
    const rep = s => s.replace(/\$\{(\w+)\}/g, (m, k) => k in vars ? vars[k] : m);
    const flat = a => { const o = []; for (const x of a || []) { if (typeof x === 'string') o.push(x); else if (allowed(x.rules)) o.push(...[].concat(x.value)); } return o; };
    let jvm, game;
    if (v.arguments) { jvm = flat(v.arguments.jvm); game = flat(v.arguments.game); } else { jvm = ['-Djava.library.path=${natives_directory}', '-cp', '${classpath}']; game = (v.minecraftArguments || '').split(' ').filter(Boolean); }
    const clean = a => { const o = []; for (let s of a) { s = rep(s); if (s.includes('${')) { if (o.length && o[o.length - 1].startsWith('--')) o.pop(); continue; } o.push(s); } return o; };
    if (cfg.fullscreen) game.push('--fullscreen');
    const opt = cfg.g1 ? '-XX:+UseG1GC -XX:+UnlockExperimentalVMOptions -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40 -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 -XX:InitiatingHeapOccupancyPercent=15 -XX:+DisableExplicitGC'.split(' ') : [];
    const args = [`-Xmx${ram}M`, `-Xms${Math.min(ram, 1024)}M`, ...opt, ...(cfg.jvm || '').split(/\s+/).filter(Boolean), ...clean(jvm), v.mainClass, ...clean(game)];
    const proc = spawn(java, args, { cwd: gameDir, windowsHide: true });
    g = { proc, logs: [], start: Date.now(), test, key, live: false, ok: false, stopped: false };
    games.set(key, g); finished.delete(key);
    if (kind === 'inst') { inst.lastPlayed = Date.now(); if (!test) { cfg.last = id; saveCfg(); } writeInst(id, inst); }
    send('game-state', { key, running: true }); t.done();
    if (cfg.hideOnPlay && !test && win) win.minimize();
    const timer = test ? setTimeout(() => { if (!g.ok) { g.timeout = true; killTree(g); } }, 300000) : null;
    const onData = b => { for (const line of b.toString('utf8').split(/\r?\n/)) { if (!line) continue; g.logs.push(line); if (g.logs.length > 6000) g.logs.splice(0, 1000); if (g.live) send('log', { key, line }); if (test && !g.ok && MARK.test(line)) { g.ok = true; killTree(g); } } };
    proc.stdout.on('data', onData); proc.stderr.on('data', onData);
    proc.on('error', e => { g.logs.push(String(e)); });
    proc.on('close', code => {
      clearTimeout(timer); games.delete(key); finished.set(key, g);
      const ms = Date.now() - g.start; let res = { key, code, test: !!test, ms, warns, ok: g.ok || (!test && (code === 0 || g.stopped)) };
      if (!res.ok) { res.analysis = analyze(g, code, inst); if (g.timeout) res.analysis.items.unshift({ title: L('Игра не загрузилась за 5 минут', 'The game did not load in 5 minutes'), text: L('Скорее всего, ПК слишком слабый для этой сборки или слишком много модов.', 'The PC is probably too slow for this pack.'), fixes: [L('Уберите часть модов или поставьте профиль для слабого ПК', 'Remove some mods')] }); }
      if (test && g.timeout === undefined && !g.ok && code === 0) res.analysis = { items: [{ title: L('Игра закрыта до конца проверки', 'Game closed before the test finished'), text: L('Запустите проверку ещё раз и не закрывайте окно игры.', 'Run the test again and do not close the game window.'), fixes: [] }], suspects: [] };
      if (inst) { try { const i2 = readInst(id); if (test) i2.tested = { ok: !!g.ok, ms, at: Date.now() }; writeInst(id, i2); } catch {} }
      try { fs.writeFileSync(path.join(P().logs, key.replace(/[:\\/]/g, '_') + '.log'), g.logs.join('\n')); } catch {}
      g.result = res; send('game-state', { key, running: false }); send('game-exit', res);
      if (win && !win.isDestroyed() && win.isMinimized()) win.restore();
    });
    return true;
  } catch (e) { t.done(); throw e; }
}

/* ---------- window ---------- */
function createWindow() {
  Menu.setApplicationMenu(null);
  win = new BrowserWindow({ width: 1280, height: 800, minWidth: 1020, minHeight: 640, frame: false, show: false, backgroundColor: '#0c1214', title: 'MineCore', icon: path.join(__dirname, 'assets', 'icon.png'), webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false } });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.once('ready-to-show', () => win.show());
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', e => e.preventDefault());
}
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.whenReady().then(() => { loadCfg(); ensureDirs(); createWindow(); });
app.on('window-all-closed', () => app.quit());

/* ---------- IPC ---------- */
const H = (c, f) => ipcMain.handle(c, (e, ...a) => f(...a));
const ALLOW = ['ram', 'lang', 'theme', 'accent', 'anim', 'jvm', 'javaPath', 'fullscreen', 'hideOnPlay', 'g1', 'cfKey', 'last'];
H('cfg:get', () => pub());
H('cfg:set', patch => { for (const k of ALLOW) if (k in patch) cfg[k] = patch[k]; saveCfg(); return pub(); });
H('win:min', () => win.minimize());
H('win:max', () => win.isMaximized() ? win.unmaximize() : win.maximize());
H('win:close', () => win.close());
H('acct:offline', nick => { nick = String(nick).trim(); if (!/^[A-Za-z0-9_]{3,16}$/.test(nick)) throw new Error(L('Ник: 3–16 символов, латиница, цифры и _', 'Nick: 3–16 chars, letters, digits and _')); cfg.account = { type: 'offline', name: nick, uuid: offUuid(nick), token: '0' }; saveCfg(); return pub(); });
H('acct:ms', async () => { const code = await msCode(); const tok = await form('https://login.live.com/oauth20_token.srf', { client_id: CID, code, grant_type: 'authorization_code', redirect_uri: REDIR, scope: 'service::user.auth.xboxlive.com::MBI_SSL' }); cfg.account = await msChain(tok); saveCfg(); return pub(); });
H('acct:logout', () => { cfg.account = null; saveCfg(); return pub(); });
H('mc:versions', async () => { const m = await manifest(); return { latest: m.latest, versions: m.versions.map(v => ({ id: v.id, type: v.type, date: v.releaseTime })) }; });
H('mc:installed', () => { try { return fs.readdirSync(P().versions).filter(d => { const f = path.join(P().versions, d, d + '.json'); if (!fs.existsSync(f)) return false; try { const j = JSON.parse(fs.readFileSync(f, 'utf8')); return !j.inheritsFrom && fs.existsSync(path.join(P().versions, d, d + '.jar')); } catch { return false; } }); } catch { return []; } });
H('ver:install', async id => { const t = Task(L('Установка ', 'Installing ') + id); try { await installVanilla(id, t); } finally { t.done(); } return true; });
H('ver:delete', id => { fs.rmSync(path.join(P().versions, id), { recursive: true, force: true }); return true; });
H('inst:list', () => listInsts());
H('loader:versions', async ({ mc, loader }) => {
  if (loader === 'fabric' || loader === 'quilt') { const b = loader === 'fabric' ? 'https://meta.fabricmc.net/v2' : 'https://meta.quiltmc.org/v3'; const r = await getJSON(`${b}/versions/loader/${mc}`); return r.sort((a, c) => (c.loader.stable ? 1 : 0) - (a.loader.stable ? 1 : 0)).map(x => x.loader.version); }
  if (loader === 'forge') { const m = await getJSON('https://files.minecraftforge.net/net/minecraftforge/forge/maven-metadata.json'); return (m[mc] || []).slice().reverse(); }
  if (loader === 'neoforge') { const r = await getJSON('https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge'); const [, mi, pa] = mc.split('.'); const pre = `${mi}.${pa || 0}.`; return r.versions.filter(v => v.startsWith(pre)).reverse(); }
  return [];
});
H('inst:create', async ({ name, mc, loader, lv }) => {
  name = safeName(name); if (!name) throw new Error(L('Введите название', 'Enter a name'));
  if (fs.existsSync(instDir(name))) throw new Error(L('Сборка с таким названием уже есть', 'A pack with this name exists'));
  if (loader !== 'vanilla' && !lv) throw new Error(L('Для этой версии нет выбранного загрузчика', 'No loader version available'));
  const t = Task(L('Создание сборки «', 'Creating "') + name + '»');
  try { const versionId = await installLoader(mc, loader, lv, t); fs.mkdirSync(path.join(instDir(name), 'mods'), { recursive: true }); writeInst(name, { name, mc, loader, loaderVer: lv, versionId, created: Date.now(), mods: [], ram: 0, tested: null }); }
  finally { t.done(); }
  return name;
});
H('inst:rename', ({ name, to }) => { to = safeName(to); if (!to) throw new Error(L('Введите название', 'Enter a name')); if (fs.existsSync(instDir(to))) throw new Error(L('Такое название уже занято', 'Name already used')); fs.renameSync(instDir(name), instDir(to)); const i = readInst(to); i.name = to; writeInst(to, i); if (cfg.last === name) { cfg.last = to; saveCfg(); } return to; });
H('inst:dup', ({ name }) => { let n = name + ' (2)', k = 2; while (fs.existsSync(instDir(n))) n = `${name} (${++k})`; fs.cpSync(instDir(name), instDir(n), { recursive: true }); const i = readInst(n); i.name = n; i.created = Date.now(); i.tested = null; writeInst(n, i); return n; });
H('inst:delete', name => { if (games.has('inst:' + name)) throw new Error(L('Сначала остановите игру', 'Stop the game first')); fs.rmSync(instDir(name), { recursive: true, force: true }); if (cfg.last === name) { cfg.last = null; saveCfg(); } return true; });
H('mod:search', async ({ src, q, mc, loader, off }) => {
  if (src === 'modrinth') {
    const f = [['project_type:mod'], [`versions:${mc}`], mrLoaders(loader).map(x => 'categories:' + x)];
    const r = await mrGet(`/search?query=${encodeURIComponent(q || '')}&facets=${lq(f)}&limit=20&offset=${off || 0}&index=${q ? 'relevance' : 'downloads'}`);
    return r.hits.map(h => ({ id: h.project_id, title: h.title, desc: h.description, icon: h.icon_url, dl: h.downloads, author: h.author }));
  }
  const r = await cfGet(`/mods/search?gameId=432&classId=6&searchFilter=${encodeURIComponent(q || '')}&gameVersion=${mc}&modLoaderType=${CFL[loader]}&sortField=${q ? 1 : 2}&sortOrder=desc&pageSize=20&index=${off || 0}`);
  return r.data.map(m => ({ id: String(m.id), title: m.name, desc: m.summary, icon: m.logo && m.logo.thumbnailUrl, dl: m.downloadCount, author: m.authors && m.authors[0] && m.authors[0].name }));
});
H('mod:versions', async ({ src, id, mc, loader }) => {
  if (src === 'modrinth') { const r = await mrGet(`/project/${id}/version?game_versions=${lq([mc])}&loaders=${lq(mrLoaders(loader))}`); return r.map(v => ({ id: v.id, name: v.version_number || v.name, type: v.version_type, date: v.date_published })); }
  const r = await cfGet(`/mods/${id}/files?gameVersion=${mc}&modLoaderType=${CFL[loader]}&pageSize=30`);
  return r.data.map(f => ({ id: String(f.id), name: f.displayName, type: ['', 'release', 'beta', 'alpha'][f.releaseType] || 'release', date: f.fileDate }));
});
H('mod:install', async ({ name, src, pid, vid, title, icon }) => { const done = []; await installMod(name, src, pid, vid, { title, icon }, 0, done); return done; });
H('mod:list', name => { const inst = readInst(name); return modFiles(name).map(f => { const base = f.replace(/\.disabled$/, ''), m = inst.mods.find(x => x.file === base) || {}; return { file: f, enabled: !f.endsWith('.disabled'), name: m.name || base, ver: m.ver || '', icon: m.icon || '', src: m.src, pid: m.pid }; }); });
H('mod:remove', ({ name, file }) => { try { fs.unlinkSync(path.join(instDir(name), 'mods', file)); } catch {} const i = readInst(name), b = file.replace(/\.disabled$/, ''); i.mods = i.mods.filter(m => m.file !== b); writeInst(name, i); return true; });
H('mod:toggle', ({ name, file }) => { const d = path.join(instDir(name), 'mods'); const to = file.endsWith('.disabled') ? file.slice(0, -9) : file + '.disabled'; fs.renameSync(path.join(d, file), path.join(d, to)); return to; });
H('game:play', a => launch(a));
H('game:stop', key => { const g = games.get(key); if (g) killTree(g); return true; });
H('console:get', key => { const g = games.get(key) || finished.get(key); return { lines: g ? g.logs.slice(-3000) : [], running: games.has(key), result: g && g.result || null }; });
H('console:attach', key => { for (const g of games.values()) g.live = false; const g = games.get(key); if (g) g.live = true; return true; });
H('console:detach', () => { for (const g of games.values()) g.live = false; return true; });
H('java:list', async () => {
  const comps = {};
  try { const all = await getJSON(RT_URL); for (const [k, a] of Object.entries(all[rtArch()] || {})) if (a[0]) comps[k] = a[0].version.name; } catch {}
  const have = fs.existsSync(P().runtime) ? fs.readdirSync(P().runtime).filter(d => fs.existsSync(path.join(P().runtime, d, '.ok'))) : [];
  for (const d of have) comps[d] = comps[d] || fs.readFileSync(path.join(P().runtime, d, '.ok'), 'utf8');
  return Object.entries(comps).map(([comp, ver]) => ({ comp, ver, installed: have.includes(comp) }));
});
H('java:install', async comp => { const t = Task('Java ' + comp); try { await ensureJava(comp, t); } finally { t.done(); } return true; });
H('java:delete', comp => { fs.rmSync(path.join(P().runtime, comp), { recursive: true, force: true }); return true; });
H('sys:info', () => ({ totalMem: Math.round(os.totalmem() / 1048576), freeMem: Math.round(os.freemem() / 1048576), cpus: os.cpus().length, cpu: os.cpus()[0] && os.cpus()[0].model, root: cfg.root }));
H('sys:setRoot', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'] }); if (r.canceled || !r.filePaths[0]) return pub();
  let d = r.filePaths[0]; if (fs.readdirSync(d).length && !fs.existsSync(path.join(d, 'instances'))) d = path.join(d, 'MineCore');
  cfg.root = d; saveCfg(); ensureDirs(); return pub();
});
H('sys:pickJava', async () => { const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'java', extensions: ['exe'] }] }); if (r.canceled) return pub(); cfg.javaPath = r.filePaths[0]; saveCfg(); return pub(); });
H('folder:open', ({ kind, id, sub }) => {
  const p = P(); let d;
  if (kind === 'inst') d = path.join(instDir(id), sub || '');
  else if (kind === 'ver') d = fs.existsSync(path.join(p.vanilla, id)) ? path.join(p.vanilla, id) : path.join(p.versions, id);
  else d = sub && p[sub] ? p[sub] : p.root;
  fs.mkdirSync(d, { recursive: true }); return shell.openPath(d);
});
H('path:open', f => shell.openPath(f));
